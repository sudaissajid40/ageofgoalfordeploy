import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { XCircle, LogOut, Pencil } from "lucide-react";

export const Route = createFileRoute("/rejected")({
  component: RejectedPage,
});

function RejectedPage() {
  const navigate = useNavigate();
  const { user, profile, loading, signOut } = useAuth();

  useEffect(() => {
    if (loading) return;
    if (!user) navigate({ to: "/login" });
    else if (profile?.verification_status === "approved") navigate({ to: "/dashboard" });
    else if (profile?.verification_status === "pending") navigate({ to: "/pending" });
  }, [user, profile, loading, navigate]);

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="w-full max-w-md text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-destructive/15 border border-destructive/30">
          <XCircle className="h-8 w-8 text-destructive" />
        </div>
        <h1 className="mt-6 text-2xl font-bold">Verification rejected</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Your profile was not approved. Read the admin's note below, fix the issue, then re-submit for review.
        </p>
        {profile?.rejection_reason && (
          <div className="mt-6 rounded-xl border border-destructive/30 bg-destructive/5 p-4 text-left text-sm">
            <div className="text-xs uppercase tracking-wide text-muted-foreground">Reason from admin</div>
            <p className="mt-1 text-foreground whitespace-pre-wrap">{profile.rejection_reason}</p>
          </div>
        )}
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Button asChild className="gradient-bg glow-primary">
            <Link to="/complete-profile">
              <Pencil className="mr-2 h-4 w-4" /> Edit profile & re-submit
            </Link>
          </Button>
          <Button onClick={signOut} variant="outline">
            <LogOut className="mr-2 h-4 w-4" /> Sign out
          </Button>
        </div>
      </div>
    </div>
  );
}
