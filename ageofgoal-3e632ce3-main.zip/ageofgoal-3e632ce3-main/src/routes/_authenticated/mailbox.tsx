import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Bell, Check, Mail, Megaphone, Send, X } from "lucide-react";
import { toast } from "sonner";
import type { Database } from "@/integrations/supabase/types";

type Notification = Database["public"]["Tables"] extends { notifications: { Row: infer R } } ? R : any;
type Invite = Database["public"]["Tables"] extends { team_invitations: { Row: infer R } } ? R : any;
type Transfer = Database["public"]["Tables"] extends { team_ownership_transfers: { Row: infer R } } ? R : any;

export const Route = createFileRoute("/_authenticated/mailbox")({ component: MailboxPage });

function MailboxPage() {
  const { user, isAdmin } = useAuth();
  const [items, setItems] = useState<Notification[]>([]);
  const [invites, setInvites] = useState<Invite[]>([]);
  const [transfers, setTransfers] = useState<Transfer[]>([]);
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);

  const load = async () => {
    if (!user) return;
    setLoading(true);
    const [{ data: n }, { data: i }, { data: tr }] = await Promise.all([
      supabase.from("notifications").select("*").order("created_at", { ascending: false }).limit(100),
      supabase.from("team_invitations").select("*").eq("invited_user_id", user.id).eq("status", "pending"),
      supabase.from("team_ownership_transfers").select("*").eq("proposed_owner_id", user.id).eq("status", "pending"),
    ]);
    setItems((n as Notification[]) ?? []);
    setInvites((i as Invite[]) ?? []);
    setTransfers((tr as Transfer[]) ?? []);
    setLoading(false);
  };

  useEffect(() => { void load(); }, [user?.id]);

  const markRead = async (id: string) => {
    const { error } = await supabase.from("notifications").update({ status: "read", read_at: new Date().toISOString() }).eq("id", id);
    if (error) return toast.error(error.message);
    void load();
  };

  const markAllRead = async () => {
    if (!user) return;
    const { error } = await supabase.from("notifications").update({ status: "read", read_at: new Date().toISOString() })
      .eq("recipient_id", user.id).eq("status", "unread");
    if (error) return toast.error(error.message);
    toast.success("All notifications marked as read");
    void load();
  };

  const respondInvite = async (id: string, status: "accepted" | "rejected") => {
    const { error } = await supabase.from("team_invitations").update({ status }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success(status === "accepted" ? "Invitation accepted" : "Invitation rejected");
    void load();
  };

  const respondTransfer = async (id: string, status: "accepted" | "rejected") => {
    const { error } = await supabase.from("team_ownership_transfers").update({ status }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success(status === "accepted" ? "Ownership accepted" : "Ownership rejected");
    void load();
  };

  const broadcast = async () => {
    if (!title.trim() || !message.trim()) return toast.error("Title and message required");
    const { data: users } = await supabase.from("profiles").select("id").eq("verification_status", "approved");
    const rows = (users ?? []).map((p) => ({ recipient_id: p.id, actor_id: user?.id ?? null, type: "admin_broadcast" as const, title: title.trim(), message: message.trim(), action_url: "/mailbox" }));
    const { error } = await supabase.from("notifications").insert(rows);
    if (error) return toast.error(error.message);
    toast.success("Announcement sent");
    setTitle(""); setMessage("");
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-black uppercase tracking-tight">AOG <span className="gradient-text">Mailbox</span></h1>
          <p className="mt-1 text-sm text-muted-foreground">Team invitations, approvals, tournaments, and admin announcements.</p>
        </div>
        <div className="rounded-md border border-primary/30 bg-primary/10 px-3 py-2 text-xs font-bold uppercase tracking-widest text-primary">{items.filter((i) => i.status === "unread").length} unread</div>
      </div>

      {isAdmin && <div className="rounded-xl border border-primary/30 bg-card p-5 card-glow"><h2 className="flex items-center gap-2 font-display font-bold uppercase"><Megaphone className="h-4 w-4 text-primary" /> Admin broadcast</h2><div className="mt-3 grid gap-3"><Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Announcement title" /><Textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Message for all verified players" rows={3} /><Button onClick={broadcast} className="w-fit gradient-bg"><Send className="mr-2 h-4 w-4" /> Send announcement</Button></div></div>}

      {(invites.length > 0 || transfers.length > 0) && <div className="grid gap-3 lg:grid-cols-2">{invites.map((invite) => <ActionCard key={invite.id} title="Team invitation" text="A team owner invited you. Accepting will add you to the team." onAccept={() => respondInvite(invite.id, "accepted")} onReject={() => respondInvite(invite.id, "rejected")} />)}{transfers.map((transfer) => <ActionCard key={transfer.id} title="Ownership transfer" text="A team owner wants to transfer ownership to you." onAccept={() => respondTransfer(transfer.id, "accepted")} onReject={() => respondTransfer(transfer.id, "rejected")} />)}</div>}

      <div className="rounded-xl border border-border bg-card p-5">
        <h2 className="flex items-center gap-2 font-display font-bold uppercase"><Mail className="h-4 w-4 text-primary" /> Inbox</h2>
        {loading ? <p className="mt-4 text-sm text-muted-foreground">Loading mailbox…</p> : items.length === 0 ? <div className="mt-4 rounded-lg border border-dashed border-border p-8 text-center"><Bell className="mx-auto h-8 w-8 text-muted-foreground" /><p className="mt-2 text-sm text-muted-foreground">No messages yet.</p></div> : <ul className="mt-4 space-y-2">{items.map((item) => <li key={item.id} className={`rounded-lg border p-4 ${item.status === "unread" ? "border-primary/40 bg-primary/10" : "border-border bg-background/50"}`}><div className="flex flex-wrap items-start justify-between gap-3"><div><div className="font-display font-bold uppercase">{item.title}</div><p className="mt-1 text-sm text-muted-foreground">{item.message}</p><div className="mt-2 font-mono text-[11px] uppercase text-muted-foreground">{new Date(item.created_at).toLocaleString()} · {String(item.type).replaceAll("_", " ")}</div></div><div className="flex gap-2">{item.action_url && <Button asChild size="sm" variant="outline"><Link to={item.action_url as any}>Open</Link></Button>}{item.status === "unread" && <Button size="sm" onClick={() => markRead(item.id)}>Mark read</Button>}</div></div></li>)}</ul>}
      </div>
    </div>
  );
}

function ActionCard({ title, text, onAccept, onReject }: { title: string; text: string; onAccept: () => void; onReject: () => void }) {
  return <div className="rounded-xl border border-primary/30 bg-card p-4"><h3 className="font-display font-bold uppercase text-primary">{title}</h3><p className="mt-1 text-sm text-muted-foreground">{text}</p><div className="mt-3 flex gap-2"><Button size="sm" onClick={onAccept} className="bg-success text-success-foreground hover:bg-success/90"><Check className="mr-1 h-3 w-3" /> Accept</Button><Button size="sm" variant="destructive" onClick={onReject}><X className="mr-1 h-3 w-3" /> Reject</Button></div></div>;
}
