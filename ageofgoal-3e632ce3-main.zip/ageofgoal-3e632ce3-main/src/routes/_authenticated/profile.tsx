import { createFileRoute, Link } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth-context";
import { StatusBadge } from "@/components/StatusBadge";
import { RankBadge } from "@/components/RankBadge";
import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Trophy, Star, BarChart3, Crosshair, Crown, Users, ArrowRight } from "lucide-react";
import characterFemale from "@/assets/characters/character-female-1.jpg";
import characterMale from "@/assets/characters/character-male-1.jpg";
import { UserAvatar } from "@/components/UserAvatar";
import { getTierProgress } from "@/lib/rank";
import { Button } from "@/components/ui/button";
import { useVisibilityRefresh } from "@/hooks/useVisibilityRefresh";
import { NewTournamentsBanner } from "@/components/NewTournamentsBanner";

export const Route = createFileRoute("/_authenticated/profile")({
  component: ProfilePage,
});

interface RegRow {
  id: string;
  placement: number | null;
  points_awarded: number | null;
  tournaments: { name: string; type: string; starts_at: string } | null;
}

interface MyTeam { id: string; name: string; team_level: number; join_code: string; member_count: number }

function ProfilePage() {
  const { profile, user } = useAuth();
  const [regs, setRegs] = useState<RegRow[]>([]);
  const [team, setTeam] = useState<MyTeam | null>(null);
  const [stats, setStats] = useState({ tournaments: 0, booyahs: 0 });

  const load = useCallback(async () => {
    if (!profile) return;
    const [regResp, tmResp] = await Promise.all([
      supabase
        .from("tournament_registrations")
        .select("id, placement, points_awarded, tournaments(name, type, starts_at)", { count: "exact" })
        .eq("registered_by", profile.id)
        .order("created_at", { ascending: false }),
      supabase
        .from("team_members")
        .select("teams(id, name, team_level, join_code)")
        .eq("user_id", profile.id)
        .limit(1)
        .maybeSingle(),
    ]);
    const rows = (regResp.data as RegRow[] | null) ?? [];
    setRegs(rows);
    setStats({
      tournaments: regResp.count ?? rows.length,
      booyahs: rows.filter((r) => r.placement === 1).length,
    });
    const teamRow = (tmResp.data as { teams: { id: string; name: string; team_level: number; join_code: string } | null } | null)?.teams;
    if (teamRow) {
      const { count } = await supabase
        .from("team_members")
        .select("id", { count: "exact", head: true })
        .eq("team_id", teamRow.id);
      setTeam({ ...teamRow, member_count: count ?? 0 });
    } else {
      setTeam(null);
    }
  }, [profile]);

  useEffect(() => { void load(); }, [load]);
  useVisibilityRefresh(load, [load]);

  if (!profile) return null;

  const progress = getTierProgress(profile.aog_points);
  const uid = profile.id.replace(/-/g, "").slice(0, 9);
  const character = (profile as any).gender === "female" ? characterFemale : characterMale;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <h1 className="font-display text-3xl font-black uppercase tracking-tight sm:text-4xl">
          My <span className="gradient-text">Profile</span>
        </h1>
        <Button asChild variant="outline" size="sm">
          <Link to="/profile/edit">Edit profile</Link>
        </Button>
      </div>

      <NewTournamentsBanner />

      <div className="grid gap-3 sm:grid-cols-3">
        <StatCard label="Tournaments" value={stats.tournaments} icon={<Trophy className="h-6 w-6" />} />
        <StatCard label="Booyahs" value={stats.booyahs} icon={<Crown className="h-6 w-6" />} />
        <StatCard label="AOG Points" value={profile.aog_points} icon={<Star className="h-6 w-6" />} />
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <div className="space-y-6">
          <div className="rounded-xl border border-primary/30 bg-card p-6 card-glow">
            <div className="flex items-start gap-5">
              <UserAvatar username={profile.username} gender={(profile as any).gender} size="xl" />
              <div className="flex-1 min-w-0">
                <h2 className="font-display text-2xl font-black uppercase">
                  <span className="gradient-text">{profile.username}</span>
                </h2>
                <div className="mt-1 font-mono text-sm">
                  <span className="text-muted-foreground">UID:</span>{" "}
                  <span className="font-bold text-primary">{uid}</span>
                </div>
                <div className="mt-3"><StatusBadge status={profile.verification_status} /></div>
              </div>
            </div>

            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              <div className="rounded-lg border border-border bg-background/50 p-5 text-center">
                <Crosshair className="mx-auto h-5 w-5 text-warning" />
                <div className="mt-2 font-display text-xs font-bold uppercase tracking-widest text-muted-foreground">Player Level</div>
                <div className="mt-1 font-display text-3xl font-black gradient-text">{profile.level ?? "?"}</div>
              </div>
              <div className="rounded-lg border border-border bg-background/50 p-5 text-center">
                <BarChart3 className="mx-auto h-5 w-5 text-primary" />
                <div className="mt-2 font-display text-xs font-bold uppercase tracking-widest text-muted-foreground">Region</div>
                <div className="mt-1 font-display text-xl font-black text-foreground">{profile.region ?? "—"}</div>
              </div>
            </div>

            <div className="mt-6 rounded-lg border border-border bg-background/50 p-5">
              <div className="flex items-center justify-between">
                <RankBadge points={profile.aog_points} showPoints={false} />
                {progress.next && (
                  <span className="font-mono text-xs text-muted-foreground">
                    {progress.remaining} pts to <span className="text-primary font-bold">{progress.next.name}</span>
                  </span>
                )}
              </div>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-border">
                <div className="h-full gradient-bg transition-all" style={{ width: `${progress.pct}%` }} />
              </div>
            </div>

            <div className="mt-6 grid gap-2 text-sm sm:grid-cols-2">
              <Row label="Email" value={user?.email ?? "—"} />
              <Row label="City" value={profile.city ?? "—"} />
              <Row label="Age" value={profile.age?.toString() ?? "—"} />
              <Row label="Gender" value={profile.gender ?? "—"} />
              <Row label="Play Style" value={profile.play_style ?? "—"} />
              <Row label="Preferred Mode" value={profile.preferred_mode ?? "—"} />
            </div>
          </div>

          {/* Team area */}
          <div className="rounded-xl border border-border bg-card p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-wide">My Team</h2>
            {team ? (
              <div className="mt-4 rounded-lg border border-primary/30 bg-primary/5 p-4">
                <div className="flex items-center gap-2">
                  <span className="text-xl">🚩</span>
                  <span className="font-display text-lg font-bold text-primary">{team.name}</span>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2 font-mono text-sm">
                  <div><span className="text-muted-foreground">Invite:</span> <span className="font-bold text-primary">{team.join_code}</span></div>
                  <div><span className="text-muted-foreground">Level:</span> <span className="font-bold">{team.team_level}</span></div>
                  <div className="col-span-2"><span className="text-muted-foreground">Members:</span> <span className="font-bold">{team.member_count}/6</span></div>
                </div>
                <Button asChild className="mt-4 w-full gradient-bg glow-primary font-display font-bold uppercase tracking-wider">
                  <Link to="/teams/$teamId" params={{ teamId: team.id }}>
                    <Users className="mr-2 h-4 w-4" /> Open Team Lobby
                  </Link>
                </Button>
              </div>
            ) : (
              <div className="mt-4 rounded-lg border border-dashed border-border p-6 text-center">
                <Users className="mx-auto h-8 w-8 text-muted-foreground" />
                <p className="mt-2 text-sm text-muted-foreground">No team yet — create or join a squad.</p>
                <Button asChild className="mt-4 gradient-bg glow-primary font-display font-bold uppercase tracking-wider">
                  <Link to="/teams">Find a Team <ArrowRight className="ml-2 h-4 w-4" /></Link>
                </Button>
              </div>
            )}
          </div>

          {/* Tournament history */}
          <div className="rounded-xl border border-border bg-card p-6">
            <h3 className="font-display text-lg font-bold uppercase tracking-wide">
              Tournament <span className="gradient-text">History</span>
            </h3>
            {regs.length === 0 ? (
              <p className="mt-3 text-sm text-muted-foreground">No tournaments yet — your legend awaits.</p>
            ) : (
              <ul className="mt-4 space-y-2">
                {regs.map((r) => (
                  <li key={r.id} className="flex items-center justify-between rounded-lg border border-border bg-background/50 p-3">
                    <div>
                      <div className="font-display font-bold">{r.tournaments?.name}</div>
                      <div className="font-mono text-xs uppercase text-muted-foreground">{r.tournaments?.type}</div>
                    </div>
                    <div className="text-right">
                      {r.placement ? (
                        <>
                          <div className="flex items-center gap-1 font-display text-sm font-bold text-primary">
                            <Trophy className="h-3 w-3" /> #{r.placement}
                          </div>
                          <div className="font-mono text-xs text-primary">+{r.points_awarded ?? 0} pts</div>
                        </>
                      ) : (
                        <span className="font-mono text-xs uppercase text-muted-foreground">Pending</span>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        <div className="hidden lg:block">
          <div className="sticky top-8 overflow-hidden rounded-2xl border border-primary/30 bg-gradient-to-b from-card to-background">
            <img src={character} alt="Player character" className="h-auto w-full object-cover object-top" loading="lazy" width={512} height={768} />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background via-background/70 to-transparent p-4">
              <div className="h-1 w-16 bg-warning rounded-full" />
              <div className="mt-2 font-display text-sm font-bold uppercase">Lv. {profile.level ?? 1} Player</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-border/50 bg-background/30 p-2.5">
      <div className="font-display text-[10px] font-bold uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className="text-sm text-foreground">{value}</div>
    </div>
  );
}

function StatCard({ label, value, icon }: { label: string; value: number; icon: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5 text-center card-glow">
      <div className="flex justify-center text-primary">{icon}</div>
      <div className="mt-2 font-display text-xs font-bold uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className="mt-1 font-display text-3xl font-black gradient-text">{value}</div>
    </div>
  );
}
