import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Trophy, Calendar, Users as UsersIcon, Lock, Play, Sword, ExternalLink, Copy } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { toast } from "sonner";
import { formatPKTDateTime } from "@/lib/time";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";
import type { Database } from "@/integrations/supabase/types";
import { SponsorBanner } from "@/components/SponsorBanner";
import { PrizeBanner } from "@/components/PrizeBanner";
import { PaymentReceiptUpload } from "@/components/PaymentReceiptUpload";
import { getTournamentDisplayStatus } from "@/lib/tournamentStatus";

type Tournament = Database["public"]["Tables"]["tournaments"]["Row"];
type Match = Database["public"]["Tables"]["tournament_matches"]["Row"];
type Team = Database["public"]["Tables"]["teams"]["Row"];

export const Route = createFileRoute("/_authenticated/tournaments/$id")({
  component: TournamentDetail,
});

interface MatchRow extends Match {
  team_a_name: string | null;
  team_b_name: string | null;
  is_my_team: boolean;
}

function TournamentDetail() {
  const { id } = Route.useParams();
  const { user, isVerified } = useAuth();
  const [t, setT] = useState<Tournament | null>(null);
  const [matches, setMatches] = useState<MatchRow[]>([]);
  const [myTeam, setMyTeam] = useState<Team | null>(null);
  const [canRegister, setCanRegister] = useState(false);
  const [registered, setRegistered] = useState(false);
  const [myTeamRegistered, setMyTeamRegistered] = useState(false);
  const [verifiedMemberCount, setVerifiedMemberCount] = useState(0);
  const [registeredTeams, setRegisteredTeams] = useState<{ id: string; name: string }[]>([]);
  const [soloPlayers, setSoloPlayers] = useState<{ id: string; username: string | null }[]>([]);
  const [loading, setLoading] = useState(true);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const i = setInterval(() => setNow(Date.now()), 15000);
    return () => clearInterval(i);
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: tour } = await supabase.from("tournaments").select("*").eq("id", id).maybeSingle();
    setT(tour);

    let currentTeam: Team | null = null;
    let delegated = false;
    let verifiedCount = 0;
    if (user) {
      const { data: memberRow } = await supabase
        .from("team_members").select("team_id, can_register").eq("user_id", user.id).maybeSingle();
      if (memberRow) {
        const { data: team } = await supabase.from("teams").select("*").eq("id", memberRow.team_id).maybeSingle();
        currentTeam = team;
        delegated = !!(memberRow as any).can_register;
        if (team) {
          const { data: teamMembers } = await supabase
            .from("team_members").select("user_id").eq("team_id", team.id);
          const ids = (teamMembers ?? []).map((x) => x.user_id);
          if (ids.length) {
            const { data: profs } = await supabase
              .from("profiles").select("id").in("id", ids).eq("verification_status", "approved");
            verifiedCount = (profs ?? []).length;
          }
        }
      }
    }
    setMyTeam(currentTeam);
    setCanRegister(delegated || (!!currentTeam && currentTeam.owner_id === user?.id));
    setVerifiedMemberCount(verifiedCount);

    const { data: regs } = await supabase
      .from("tournament_registrations")
      .select("participant_id, participant_type, registered_by")
      .eq("tournament_id", id);
    const teamIds = (regs ?? []).filter((r) => r.participant_type === "team").map((r) => r.participant_id);
    const userIds = (regs ?? []).filter((r) => r.participant_type === "user").map((r) => r.participant_id);
    const { data: teamData } = teamIds.length
      ? await supabase.from("teams").select("id, name").in("id", teamIds)
      : { data: [] as { id: string; name: string }[] };
    const { data: userData } = userIds.length
      ? await supabase.from("profiles").select("id, username").in("id", userIds)
      : { data: [] as { id: string; username: string | null }[] };
    setRegisteredTeams(teamData ?? []);
    setSoloPlayers(userData ?? []);
    if (user) {
      setRegistered((regs ?? []).some((r) => r.registered_by === user.id));
    }
    setMyTeamRegistered(!!currentTeam && (regs ?? []).some((r) => r.participant_type === "team" && r.participant_id === currentTeam!.id));

    const { data: m } = await supabase
      .from("tournament_matches")
      .select("id, tournament_id, round, match_number, team_a_id, team_b_id, scheduled_at, status, winner_team_id, spectator_link, created_at, updated_at")
      .eq("tournament_id", id)
      .order("scheduled_at", { ascending: true });
    const teamMap = new Map<string, string>((teamData ?? []).map((x) => [x.id, x.name]));
    const baseRows = (m ?? []).map((row) => ({
      ...row,
      room_id: null as string | null,
      room_password: null as string | null,
      team_a_name: row.team_a_id ? teamMap.get(row.team_a_id) ?? null : null,
      team_b_name: row.team_b_id ? teamMap.get(row.team_b_id) ?? null : null,
      is_my_team: !!currentTeam && (row.team_a_id === currentTeam.id || row.team_b_id === currentTeam.id),
    }));
    // Fetch room credentials only for matches the user participates in and that are about to start
    const nowMs = Date.now();
    await Promise.all(baseRows.map(async (row) => {
      if (!row.is_my_team) return;
      const startMs = Date.parse(row.scheduled_at);
      if (nowMs < startMs - 60_000) return;
      const { data: room } = await supabase.rpc("get_match_room", { _match_id: row.id });
      const first = Array.isArray(room) ? room[0] : null;
      if (first) {
        row.room_id = (first as { room_id: string | null }).room_id ?? null;
        row.room_password = (first as { room_password: string | null }).room_password ?? null;
      }
    }));
    setMatches(baseRows);

    setLoading(false);
  }, [id, user?.id]);

  useEffect(() => { void load(); }, [load]);
  useRealtimeRefresh(["tournaments", "tournament_matches", "tournament_registrations", "team_members"], load);

  const register = async () => {
    if (!t || !user) return;
    if (!isVerified) return toast.error("You must be verified first");
    if (t.type === "team") {
      if (!myTeam) return toast.error("Join a team first");
      if (!canRegister) return toast.error("Only the team owner or a delegated member can register");
      if (verifiedMemberCount < (t.min_team_members ?? 1)) {
        return toast.error(`Team needs at least ${t.min_team_members} verified members`);
      }
      const { error } = await supabase.from("tournament_registrations").insert({
        tournament_id: t.id, participant_id: myTeam.id, participant_type: "team", registered_by: user.id,
      });
      if (error) return toast.error(error.message);
    } else {
      const { error } = await supabase.from("tournament_registrations").insert({
        tournament_id: t.id, participant_id: user.id, participant_type: "user", registered_by: user.id,
      });
      if (error) return toast.error(error.message);
    }
    toast.success("Registered!");
    void load();
  };

  if (loading) return <p className="text-sm text-muted-foreground">Loading…</p>;
  if (!t) return <p className="text-sm text-muted-foreground">Tournament not found.</p>;

  const regOpen = t.registration_ends_at ? Date.parse(t.registration_ends_at) > now : true;
  const regDeadline = formatPKTDateTime(t.registration_ends_at);

  const copyRoom = (room: string, label = "Room ID") => {
    navigator.clipboard.writeText(room);
    toast.success(`${label} copied!`);
  };

  const eligibilityNote = t.type === "team" && myTeam && verifiedMemberCount < (t.min_team_members ?? 1)
    ? `Team needs ${(t.min_team_members ?? 1) - verifiedMemberCount} more verified member${(t.min_team_members ?? 1) - verifiedMemberCount === 1 ? "" : "s"} to register`
    : null;

  const regDisabled = !isVerified
    || (t.type === "team" && (!myTeam || !canRegister || verifiedMemberCount < (t.min_team_members ?? 1)));
  const regTooltip = !isVerified
    ? "Get verified by admin to join tournaments."
    : t.type === "team" && !myTeam ? "Join a team first."
    : t.type === "team" && !canRegister ? "Only the team owner or a delegated member can register."
    : eligibilityNote ?? "";

  const display = getTournamentDisplayStatus(t);
  const isPaid = Number(t.entry_fee ?? 0) > 0;

  return (
    <div className="space-y-6">
      <div className="rounded-xl border border-primary/20 bg-card p-5 card-glow">
        {t.thumbnail_url && (
          <img src={t.thumbnail_url} alt={t.name} className="mb-4 max-h-56 w-full rounded-lg object-cover" />
        )}
        <div className="flex flex-wrap items-center gap-2">
          <span className={`rounded-full border px-2 py-0.5 text-[10px] uppercase ${display.badgeClass}`}>{display.label}</span>
          <span className="rounded-full border border-border px-2 py-0.5 text-[10px] uppercase">{t.type}</span>
          <span className="rounded-full border border-border px-2 py-0.5 text-[10px] uppercase">{t.match_team_size}v{t.match_team_size}</span>
          {isPaid && <span className="rounded-full border border-warning/40 bg-warning/10 px-2 py-0.5 text-[10px] uppercase text-warning">Entry PKR {t.entry_fee}</span>}
          {myTeamRegistered && (
            <span className="rounded-full border border-success/40 bg-success/10 px-2 py-0.5 text-[10px] uppercase text-success">
              Your team is registered
            </span>
          )}
        </div>
        <h1 className="mt-3 text-2xl font-bold gradient-text">{t.name}</h1>
        {t.description && <p className="mt-2 text-sm text-muted-foreground">{t.description}</p>}
        <div className="mt-3 grid gap-2 text-xs text-muted-foreground sm:grid-cols-2">
          <div className="flex items-center gap-1"><Calendar className="h-3 w-3" /> Starts: {formatPKTDateTime(t.starts_at)}</div>
          <div className="flex items-center gap-1"><Lock className="h-3 w-3" /> Reg ends: {regDeadline}</div>
          <div>Win: <span className="font-mono text-foreground">{t.points_per_match_win} pt</span></div>
          <div>Champion bonus: <span className="font-mono text-foreground">{t.champion_points_multiplier}× team size</span></div>
          {t.type === "team" && (
            <div>Min verified members: <span className="font-mono text-foreground">{t.min_team_members}</span></div>
          )}
        </div>

        {regOpen && t.status !== "completed" && (
          <div className="mt-4">
            {registered || myTeamRegistered ? (
              <span className="inline-flex items-center gap-1 rounded-md border border-success/30 bg-success/10 px-3 py-2 text-sm text-success">
                <Trophy className="h-4 w-4" /> {myTeamRegistered ? "Team registered" : "Registered"}
              </span>
            ) : (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span className={regDisabled ? "inline-block cursor-not-allowed" : ""}>
                      <Button
                        onClick={register}
                        disabled={regDisabled}
                        className={`gradient-bg glow-primary ${regDisabled ? "pointer-events-none opacity-60" : ""}`}
                      >
                        <Play className="mr-2 h-4 w-4" />
                        {t.type === "team" ? "Register team" : "Register"}
                      </Button>
                    </span>
                  </TooltipTrigger>
                  {regDisabled && regTooltip && (
                    <TooltipContent>{regTooltip}</TooltipContent>
                  )}
                </Tooltip>
              </TooltipProvider>
            )}
            {eligibilityNote && !myTeamRegistered && (
              <p className="mt-2 text-xs text-warning">{eligibilityNote}.</p>
            )}
          </div>
        )}
        {!regOpen && t.status !== "completed" && <p className="mt-4 text-xs text-warning">Registration closed.</p>}
      </div>

      <PrizeBanner
        pointsPerWin={t.points_per_match_win}
        championMult={t.champion_points_multiplier}
        teamSize={t.match_team_size}
      />

      <SponsorBanner s={t} />

      {isPaid && !registered && !myTeamRegistered && (
        <PaymentReceiptUpload
          tournamentId={t.id}
          entryFee={Number(t.entry_fee)}
          accountLabel={t.payment_account_label}
          accountNumber={t.payment_account_number}
          instructions={t.payment_instructions}
        />
      )}

      {t.rules && (
        <div className="rounded-xl border border-border bg-card p-5">
          <h2 className="font-semibold">Rules</h2>
          <p className="mt-2 whitespace-pre-wrap text-sm text-muted-foreground">{t.rules}</p>
        </div>
      )}

      <div className="rounded-xl border border-border bg-card p-5">
        <h2 className="font-semibold">
          {t.type === "solo" ? `Registered players (${soloPlayers.length})` : `Registered teams (${registeredTeams.length})`}
        </h2>
        {t.type === "solo" ? (
          soloPlayers.length === 0 ? (
            <p className="mt-2 text-sm text-muted-foreground">No players yet.</p>
          ) : (
            <div className="mt-3 flex flex-wrap gap-2">
              {soloPlayers.map((p) => (
                <span key={p.id} className="flex items-center gap-1 rounded-md border border-border bg-background px-3 py-1.5 text-sm">
                  <UsersIcon className="h-3 w-3 text-primary" /> {p.username ?? "Player"}
                </span>
              ))}
            </div>
          )
        ) : registeredTeams.length === 0 ? (
          <p className="mt-2 text-sm text-muted-foreground">No teams yet.</p>
        ) : (
          <div className="mt-3 flex flex-wrap gap-2">
            {registeredTeams.map((rt) => (
              <Link key={rt.id} to="/teams/$teamId" params={{ teamId: rt.id }}
                className="flex items-center gap-1 rounded-md border border-border bg-background px-3 py-1.5 text-sm hover:border-primary/40">
                <UsersIcon className="h-3 w-3 text-primary" /> {rt.name}
              </Link>
            ))}
          </div>
        )}
      </div>

      <div className="rounded-xl border border-border bg-card p-5">
        <h2 className="font-semibold flex items-center gap-2"><Sword className="h-4 w-4 text-primary" /> Match Schedule</h2>
        {matches.length === 0 ? (
          <p className="mt-2 text-sm text-muted-foreground">Schedule will appear after registration closes and admin selects an AI proposal.</p>
        ) : (
          <ul className="mt-3 space-y-2">
            {matches.map((m) => {
              const startMs = Date.parse(m.scheduled_at);
              const showRoomTo = m.is_my_team && (now >= startMs - 60_000);
              const msUntil = startMs - now;
              const showCountdown = m.is_my_team && !showRoomTo && msUntil > 0 && msUntil < 60 * 60_000;
              const cdMins = Math.floor(msUntil / 60_000);
              const cdSecs = Math.floor((msUntil % 60_000) / 1000);
              return (
                <li key={m.id} className={`rounded-lg border p-3 ${m.is_my_team ? "border-primary/40 bg-primary/5" : "border-border"}`}>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="text-[10px] uppercase text-muted-foreground">{m.round} · Match #{m.match_number}</div>
                      <div className="font-display font-bold">
                        {m.team_a_name ?? "TBD"} <span className="text-muted-foreground">vs</span> {m.team_b_name ?? "TBD"}
                      </div>
                      <div className="text-xs text-muted-foreground">{formatPKTDateTime(m.scheduled_at)}</div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      {m.winner_team_id && (
                        <span className="rounded bg-success/10 px-2 py-0.5 text-xs text-success">
                          🏆 Winner: {m.winner_team_id === m.team_a_id ? m.team_a_name : m.team_b_name}
                        </span>
                      )}
                      {m.spectator_link && (
                        <a href={m.spectator_link} target="_blank" rel="noreferrer"
                          className="inline-flex items-center gap-1 rounded-md border border-border px-2 py-1 text-xs hover:border-primary/40">
                          <ExternalLink className="h-3 w-3" /> Watch
                        </a>
                      )}
                      {showRoomTo && m.room_id && (
                        <button onClick={() => copyRoom(m.room_id!)}
                          className="inline-flex items-center gap-1 rounded-md gradient-bg glow-primary px-3 py-1.5 text-xs font-bold uppercase text-primary-foreground">
                          <Copy className="h-3 w-3" /> Join: {m.room_id}
                        </button>
                      )}
                      {showRoomTo && m.room_password && (
                        <button onClick={() => copyRoom(m.room_password!, "Password")}
                          className="inline-flex items-center gap-1 rounded-md border border-border px-2 py-1 text-xs hover:border-primary/40">
                          <Copy className="h-3 w-3" /> Pass
                        </button>
                      )}
                      {showCountdown && (
                        <span className="rounded-md border border-primary/30 bg-primary/10 px-2 py-1 text-[11px] text-primary">
                          Room unlocks in {cdMins}m {cdSecs.toString().padStart(2, "0")}s
                        </span>
                      )}
                      {m.is_my_team && !showRoomTo && !showCountdown && msUntil > 0 && (
                        <span className="text-[11px] text-muted-foreground">Room ID unlocks 1 min before start</span>
                      )}
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
