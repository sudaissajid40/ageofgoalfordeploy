import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Trophy, Calendar, Users as UsersIcon, User as UserIcon, Lock, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatPKTDate } from "@/lib/time";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";
import type { Database } from "@/integrations/supabase/types";

type Tournament = Database["public"]["Tables"]["tournaments"]["Row"];

export const Route = createFileRoute("/_authenticated/tournaments/")({
  component: TournamentsList,
});

function TournamentsList() {
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const { data } = await supabase
      .from("tournaments")
      .select("*")
      .order("created_at", { ascending: false });
    setTournaments(data ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { void load(); }, [load]);
  useRealtimeRefresh(["tournaments"], load);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-black uppercase tracking-tight sm:text-4xl">
          Active <span className="gradient-text">Tournaments</span>
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">Compete solo or with your squad.</p>
      </div>

      {loading ? (
        <div className="rounded-xl border border-border bg-card p-12 text-center text-sm text-muted-foreground">
          Loading…
        </div>
      ) : tournaments.length === 0 ? (
        <div className="rounded-xl border border-border bg-card p-12 text-center">
          <Trophy className="mx-auto h-10 w-10 text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">No tournaments yet. Check back soon.</p>
        </div>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {tournaments.map((t) => {
            const isClosed = t.status === "completed";
            const isLive = t.status === "live";
            const regOpen = t.status === "upcoming" && (!t.registration_ends_at || Date.parse(t.registration_ends_at) > Date.now());
            const regClosed = t.status === "upcoming" && !regOpen;
            return (
              <article
                key={t.id}
                className="group flex flex-col overflow-hidden rounded-xl border border-border bg-card card-glow"
              >
                <div className="aspect-[4/3] bg-gradient-to-br from-primary/15 via-card to-background flex items-center justify-center overflow-hidden">
                  {t.thumbnail_url ? (
                    <img src={t.thumbnail_url} alt={t.name} className="h-full w-full object-cover transition-transform group-hover:scale-105" />
                  ) : (
                    <Trophy className="h-16 w-16 text-primary/40 group-hover:text-primary/70 transition-colors" />
                  )}
                </div>
                <div className="flex flex-1 flex-col p-4">
                  {isClosed ? (
                    <span className="inline-block w-fit rounded border border-border bg-background px-2 py-0.5 font-display text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
                      Completed
                    </span>
                  ) : isLive ? (
                    <span className="inline-block w-fit rounded border border-success/40 bg-success/10 px-2 py-0.5 font-display text-[10px] font-bold uppercase tracking-widest text-success">
                      Live Now
                    </span>
                  ) : regClosed ? (
                    <span className="inline-block w-fit rounded border border-warning/40 bg-warning/10 px-2 py-0.5 font-display text-[10px] font-bold uppercase tracking-widest text-warning">
                      Registration Closed
                    </span>
                  ) : (
                    <span className="inline-block w-fit rounded border border-cyan-400/40 bg-cyan-400/10 px-2 py-0.5 font-display text-[10px] font-bold uppercase tracking-widest text-cyan-300">
                      Registration Open
                    </span>
                  )}

                  <h3 className="mt-3 font-display text-lg font-bold uppercase leading-tight">{t.name}</h3>

                  <div className="mt-3 flex flex-wrap gap-x-3 gap-y-1.5 text-xs">
                    <span className="flex items-center gap-1 text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      {formatPKTDate(t.starts_at)}
                    </span>
                    {t.max_participants && (
                      <span className="flex items-center gap-1 text-muted-foreground">
                        <UsersIcon className="h-3 w-3" />
                        {t.max_participants} {t.type === "team" ? "Teams" : "Players"}
                      </span>
                    )}
                    <span className="flex items-center gap-1 text-primary">
                      {t.type === "team" ? <UsersIcon className="h-3 w-3" /> : <UserIcon className="h-3 w-3" />}
                      <span className="font-display font-bold uppercase">{t.type}</span>
                    </span>
                  </div>

                  <div className="mt-auto pt-4">
                    {isClosed ? (
                      <Button asChild variant="outline" className="w-full font-display font-bold uppercase tracking-wider">
                        <Link to="/tournaments/$id" params={{ id: t.id }}>
                          <Trophy className="mr-2 h-3.5 w-3.5" /> View Results
                        </Link>
                      </Button>
                    ) : isLive ? (
                      <Button asChild className="w-full gradient-bg glow-primary font-display font-bold uppercase tracking-wider text-primary-foreground">
                        <Link to="/tournaments/$id" params={{ id: t.id }}>
                          <Play className="mr-2 h-3.5 w-3.5" /> Watch Live
                        </Link>
                      </Button>
                    ) : regClosed ? (
                      <Button asChild variant="outline" className="w-full font-display font-bold uppercase tracking-wider">
                        <Link to="/tournaments/$id" params={{ id: t.id }}>
                          <Lock className="mr-2 h-3.5 w-3.5" /> View Bracket
                        </Link>
                      </Button>
                    ) : (
                      <Button
                        asChild
                        className="w-full gradient-bg glow-primary font-display font-bold uppercase tracking-wider text-primary-foreground"
                      >
                        <Link to="/tournaments/$id" params={{ id: t.id }}>
                          <Play className="mr-2 h-3.5 w-3.5" /> Join Now
                        </Link>
                      </Button>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
