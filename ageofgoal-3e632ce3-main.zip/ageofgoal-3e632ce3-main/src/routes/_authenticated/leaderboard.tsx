import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Crown, Shield, Medal, Star, Gem, Flame, Users, User } from "lucide-react";
import { getTier, type RankTier } from "@/lib/rank";
import { REGIONS, REGION_LABEL, type Region } from "@/lib/region";
import type { Database } from "@/integrations/supabase/types";

 type ProfileRow = Database["public"]["Tables"]["profiles"]["Row"];
 type TeamRow = Database["public"]["Tables"]["teams"]["Row"] & { city: string | null };
 type Mode = "players" | "teams";
 type SortBy = "aog_points" | "level";

const ICONS: Record<RankTier["icon"], typeof Shield> = { shield: Shield, medal: Medal, star: Star, gem: Gem, flame: Flame, crown: Crown };

export const Route = createFileRoute("/_authenticated/leaderboard")({ component: Leaderboard });

function Leaderboard() {
  const { profile } = useAuth();
  const [mode, setMode] = useState<Mode>("players");
  const [sortBy, setSortBy] = useState<SortBy>("aog_points");
  const [region, setRegion] = useState<"all" | Region>("all");
  const [city, setCity] = useState("");
  const [players, setPlayers] = useState<ProfileRow[]>([]);
  const [teams, setTeams] = useState<TeamRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      const [{ data: profileRows }, { data: teamRows }] = await Promise.all([
        supabase.from("profiles").select("*").eq("verification_status", "approved").limit(200),
        supabase.from("teams").select("*").limit(200),
      ]);
      setPlayers(profileRows ?? []);
      const ownerIds = (teamRows ?? []).map((t) => t.owner_id);
      const { data: ownerProfiles } = ownerIds.length
        ? await supabase.from("profiles").select("id, city").in("id", ownerIds)
        : { data: [] as { id: string; city: string | null }[] };
      const cityMap = new Map((ownerProfiles ?? []).map((p) => [p.id, p.city]));
      setTeams((teamRows ?? []).map((team) => ({ ...team, city: cityMap.get(team.owner_id) ?? null })));
      setLoading(false);
    })();
  }, []);

  const rows = useMemo(() => {
    const cityFilter = city.trim().toLowerCase();
    const source = mode === "players" ? players : teams;
    return source
      .filter((row) => region === "all" || row.region === region)
      .filter((row) => !cityFilter || (row.city ?? "").toLowerCase().includes(cityFilter))
      .sort((a, b) => {
        const aValue = mode === "players" ? (sortBy === "level" ? (a as ProfileRow).level ?? 0 : a.aog_points) : (sortBy === "level" ? (a as TeamRow).team_level : a.aog_points);
        const bValue = mode === "players" ? (sortBy === "level" ? (b as ProfileRow).level ?? 0 : b.aog_points) : (sortBy === "level" ? (b as TeamRow).team_level : b.aog_points);
        return bValue - aValue;
      })
      .slice(0, 100);
  }, [city, mode, players, region, sortBy, teams]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-black uppercase tracking-tight sm:text-4xl">AOG <span className="gradient-text">Rankings</span></h1>
        <p className="mt-1 text-sm text-muted-foreground">Filter players and teams by region, city, points, and Free Fire level.</p>
      </div>

      <div className="rounded-xl border border-border bg-card p-4">
        <div className="grid gap-3 md:grid-cols-4">
          <div className="flex rounded-md border border-border bg-background p-1">
            <button onClick={() => setMode("players")} className={`flex flex-1 items-center justify-center gap-1 rounded px-3 py-2 text-xs font-semibold ${mode === "players" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}><User className="h-3 w-3" /> Players</button>
            <button onClick={() => setMode("teams")} className={`flex flex-1 items-center justify-center gap-1 rounded px-3 py-2 text-xs font-semibold ${mode === "teams" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}><Users className="h-3 w-3" /> Teams</button>
          </div>
          <select value={sortBy} onChange={(e) => setSortBy(e.target.value as SortBy)} className="h-10 rounded-md border border-input bg-background px-3 text-sm">
            <option value="aog_points">Sort by AOG points</option>
            <option value="level">Sort by level</option>
          </select>
          <select value={region} onChange={(e) => setRegion(e.target.value as "all" | Region)} className="h-10 rounded-md border border-input bg-background px-3 text-sm">
            <option value="all">All regions</option>
            {REGIONS.map((r) => <option key={r} value={r}>{REGION_LABEL[r]}</option>)}
          </select>
          <input value={city} onChange={(e) => setCity(e.target.value)} placeholder="City filter" className="h-10 rounded-md border border-input bg-background px-3 text-sm" />
        </div>
      </div>

      {loading ? (
        <div className="rounded-xl border border-border bg-card p-12 text-center text-sm text-muted-foreground">Loading rankings…</div>
      ) : rows.length === 0 ? (
        <div className="rounded-xl border border-border bg-card p-12 text-center text-sm text-muted-foreground">No matching rankings yet.</div>
      ) : (
        <ul className="space-y-2">
          {rows.map((row, i) => {
            const isPlayer = mode === "players";
            const player = row as ProfileRow;
            const team = row as TeamRow;
            const points = row.aog_points;
            const level = isPlayer ? player.level ?? 0 : team.team_level;
            const tier = getTier(points);
            const Icon = ICONS[tier.icon];
            const isMe = isPlayer && row.id === profile?.id;
            return (
              <li key={row.id} className="relative flex items-center gap-4 overflow-hidden rounded-lg border bg-card px-4 py-3 transition-all hover:translate-x-1" style={{ borderColor: `${tier.hex}66`, background: `linear-gradient(90deg, ${tier.hex}25 0%, ${tier.hex}10 30%, transparent 70%)`, boxShadow: `0 0 24px -8px ${tier.hex}80, inset 0 0 24px -8px ${tier.hex}40` }}>
                <div className="font-display text-2xl font-black" style={{ color: tier.hex, textShadow: `0 0 12px ${tier.hex}` }}>#{i + 1}</div>
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-md" style={{ background: `${tier.hex}20`, boxShadow: `0 0 16px -4px ${tier.hex}80` }}><Icon className="h-6 w-6" style={{ color: tier.hex }} /></div>
                <div className="min-w-0 flex-1">
                  <div className="truncate font-display text-lg font-black uppercase tracking-wider" style={{ color: tier.hex, textShadow: `0 0 8px ${tier.hex}99` }}>{isPlayer ? player.username : team.name}{isMe && <span className="ml-2 text-xs text-foreground/70">(YOU)</span>}</div>
                  <div className="font-mono text-xs text-foreground/70">{tier.name} · AOG: {points.toLocaleString()} · Level: {level.toLocaleString()} · {row.region ? REGION_LABEL[row.region] : "No region"}{row.city ? ` · ${row.city}` : ""}</div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
