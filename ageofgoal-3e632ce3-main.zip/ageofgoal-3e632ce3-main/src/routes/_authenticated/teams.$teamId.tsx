import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { X, Check, Search, LogOut, Send, UserPlus, Copy } from "lucide-react";
import { toast } from "sonner";
import { StatusBadge } from "@/components/StatusBadge";
import { MemberSlot, EmptySlot } from "@/components/TeamLobbySlot";
import { useVisibilityRefresh } from "@/hooks/useVisibilityRefresh";
import type { Database } from "@/integrations/supabase/types";

type Team = Database["public"]["Tables"]["teams"]["Row"];
type Profile = Database["public"]["Tables"]["profiles"]["Row"];
interface MemberRow { id: string; user_id: string; joined_at: string; invite_frozen: boolean; can_register: boolean; profile: Profile | null }
interface RequestRow { id: string; user_id: string; profile: Profile | null }

export const Route = createFileRoute("/_authenticated/teams/$teamId")({ component: TeamDetail });

const LOCK_MS = 3 * 24 * 60 * 60 * 1000; // 3 days

function TeamDetail() {
  const { teamId } = Route.useParams();
  const { user, isVerified } = useAuth();
  const navigate = useNavigate();
  const [team, setTeam] = useState<Team | null>(null);
  const [members, setMembers] = useState<MemberRow[]>([]);
  const [requests, setRequests] = useState<RequestRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState<Profile[]>([]);
  const [hasJoined, setHasJoined] = useState(false);
  const [hasPending, setHasPending] = useState(false);
  const [transferTarget, setTransferTarget] = useState<MemberRow | null>(null);
  const [myMembership, setMyMembership] = useState<MemberRow | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: t }, { data: m }, { data: r }] = await Promise.all([
      supabase.from("teams").select("*").eq("id", teamId).maybeSingle(),
      supabase.from("team_members").select("id, user_id, joined_at, invite_frozen, can_register").eq("team_id", teamId).order("joined_at"),
      supabase.from("team_join_requests").select("id, user_id").eq("team_id", teamId).eq("status", "pending"),
    ]);
    setTeam(t);
    const allUserIds = [...((m ?? []) as Array<{ user_id: string }>).map((x) => x.user_id), ...(r ?? []).map((x) => x.user_id)];
    const profilesMap = new Map<string, Profile>();
    if (allUserIds.length > 0) {
      const { data: profs } = await supabase.from("profiles").select("*").in("id", allUserIds);
      (profs ?? []).forEach((prof) => profilesMap.set(prof.id, prof));
    }
    const memberRows: MemberRow[] = ((m ?? []) as Array<{ id: string; user_id: string; joined_at: string; invite_frozen?: boolean; can_register?: boolean }>).map((x) => ({ id: x.id, user_id: x.user_id, joined_at: x.joined_at, invite_frozen: !!x.invite_frozen, can_register: !!x.can_register, profile: profilesMap.get(x.user_id) ?? null }));
    setMembers(memberRows);
    setRequests((r ?? []).map((x) => ({ ...x, profile: profilesMap.get(x.user_id) ?? null })));
    const mine = memberRows.find((x) => x.user_id === user?.id) ?? null;
    setMyMembership(mine);
    setHasJoined(!!mine);
    if (user) {
      const { data: req } = await supabase.from("team_join_requests").select("id").eq("team_id", teamId).eq("user_id", user.id).eq("status", "pending").maybeSingle();
      setHasPending(!!req);
    }
    setLoading(false);
  }, [teamId, user?.id]);

  useEffect(() => { void load(); }, [load]);
  useVisibilityRefresh(load, [load]);

  useEffect(() => {
    const handle = window.setTimeout(async () => {
      const q = searchTerm.trim();
      if (q.length < 2) return setSearchResults([]);
      const { data } = await supabase.from("profiles").select("*").or(`username.ilike.%${q}%,city.ilike.%${q}%,ff_uid.ilike.%${q}%`).eq("verification_status", "approved").limit(8);
      const memberIds = new Set(members.map((m) => m.user_id));
      setSearchResults((data ?? []).filter((p) => !memberIds.has(p.id)));
    }, 250);
    return () => window.clearTimeout(handle);
  }, [searchTerm, members]);

  const isOwner = team?.owner_id === user?.id;

  const leaveLockReason = useMemo(() => {
    if (!hasJoined) return "You're not in this team";
    if (isOwner) return "Transfer ownership before leaving";
    if (myMembership) {
      const elapsed = Date.now() - Date.parse(myMembership.joined_at);
      if (elapsed < LOCK_MS) {
        const daysLeft = Math.ceil((LOCK_MS - elapsed) / (24 * 60 * 60 * 1000));
        return `Locked: you can leave in ${daysLeft} day${daysLeft > 1 ? "s" : ""}`;
      }
    }
    return null;
  }, [hasJoined, isOwner, myMembership]);

  const leave = async () => {
    if (!user || leaveLockReason) return;
    const { error } = await supabase.from("team_members").delete().eq("team_id", teamId).eq("user_id", user.id);
    if (error) return toast.error(error.message);
    toast.success("Left team");
    navigate({ to: "/teams" });
  };

  const deleteTeam = async () => {
    if (!confirm("Delete this team? Teams with members require ownership transfer first.")) return;
    const { error } = await supabase.from("teams").delete().eq("id", teamId);
    if (error) return toast.error(error.message);
    toast.success("Team deleted");
    navigate({ to: "/teams" });
  };

  const requestJoin = async () => {
    if (!user) return;
    if (!isVerified) return toast.error("Verification required to request a join");
    const { error } = await supabase.from("team_join_requests").insert({ team_id: teamId, user_id: user.id });
    if (error) return toast.error(error.message);
    toast.success("Request sent");
    setHasPending(true);
  };

  const handleRequest = async (req: RequestRow, approve: boolean) => {
    const { error } = await supabase.from("team_join_requests").update({ status: approve ? "approved" : "rejected" }).eq("id", req.id);
    if (error) return toast.error(error.message);
    toast.success(approve ? "Approved" : "Rejected");
    void load();
  };

  const inviteUser = async (uid: string) => {
    const { error } = await supabase.from("team_invitations").insert({ team_id: teamId, invited_user_id: uid, invited_by: user!.id });
    if (error) return toast.error(error.message);
    toast.success("Invitation sent to mailbox");
    setSearchResults((prev) => prev.filter((p) => p.id !== uid));
  };

  const transferOwnership = async (uid: string) => {
    const { error } = await supabase.from("team_ownership_transfers").insert({ team_id: teamId, current_owner_id: user!.id, proposed_owner_id: uid });
    if (error) return toast.error(error.message);
    toast.success("Ownership transfer request sent");
    setTransferTarget(null);
  };

  const kickMember = async (m: MemberRow) => {
    if (!confirm(`Kick ${m.profile?.username ?? "this player"} from the team?`)) return;
    const { error } = await supabase.from("team_members").delete().eq("id", m.id);
    if (error) return toast.error(error.message);
    toast.success("Player removed");
    void load();
  };

  const toggleFreeze = async (m: MemberRow) => {
    const next = !m.invite_frozen;
    const { error } = await (supabase.from("team_members") as any).update({ invite_frozen: next }).eq("id", m.id);
    if (error) return toast.error(error.message);
    toast.success(next ? "Invites frozen for this player" : "Invites unfrozen");
    void load();
  };

  const toggleRegistrar = async (m: MemberRow) => {
    const next = !m.can_register;
    const { error } = await (supabase.from("team_members") as any).update({ can_register: next }).eq("id", m.id);
    if (error) return toast.error(error.message);
    toast.success(next ? "Player can now register the team" : "Registration permission revoked");
    void load();
  };

  if (loading) return <p className="text-sm text-muted-foreground">Loading…</p>;
  if (!team) return <p className="text-sm text-muted-foreground">Team not found.</p>;

  // 6-slot lobby
  const slots = Array.from({ length: 6 }, (_, i) => members[i] ?? null);

  return (
    <TooltipProvider>
      <div className="space-y-6">
        {/* Header */}
        <div className="rounded-xl border border-primary/30 bg-card p-5 card-glow">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h1 className="font-display text-3xl font-black uppercase gradient-text">{team.name}</h1>
              <p className="mt-1 text-xs text-muted-foreground">
                {members.length}/6 players · Team Lv {team.team_level} · {team.aog_points} AOG points
              </p>
              <div className="mt-2 flex items-center gap-2 font-mono text-xs">
                <span className="text-muted-foreground">Invite code:</span>
                <button
                  className="inline-flex items-center gap-1 rounded border border-primary/30 bg-primary/10 px-2 py-0.5 font-bold text-primary hover:bg-primary/20"
                  onClick={() => { navigator.clipboard.writeText(team.join_code); toast.success("Code copied"); }}
                >
                  {team.join_code} <Copy className="h-3 w-3" />
                </button>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Always-visible Leave button with tooltip when locked */}
              {hasJoined && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span className={leaveLockReason ? "cursor-not-allowed" : ""}>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={leave}
                        disabled={!!leaveLockReason}
                        className={leaveLockReason ? "pointer-events-none opacity-60" : ""}
                      >
                        <LogOut className="mr-1 h-3 w-3" /> Leave team
                      </Button>
                    </span>
                  </TooltipTrigger>
                  {leaveLockReason && <TooltipContent>{leaveLockReason}</TooltipContent>}
                </Tooltip>
              )}

              {isOwner && <Button variant="destructive" size="sm" onClick={deleteTeam}>Delete</Button>}

              {!hasJoined && !hasPending && members.length < 6 && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span>
                      <Button size="sm" onClick={requestJoin} disabled={!isVerified} className="gradient-bg">
                        Request to join
                      </Button>
                    </span>
                  </TooltipTrigger>
                  {!isVerified && <TooltipContent>Verify your account first</TooltipContent>}
                </Tooltip>
              )}
              {hasPending && (
                <span className="rounded-md border border-warning/40 bg-warning/10 px-3 py-2 text-xs text-warning">
                  Request pending
                </span>
              )}
            </div>
          </div>
        </div>

        {/* 6-slot lobby grid */}
        <div className="rounded-xl border border-border bg-card p-5">
          <div className="flex items-center justify-between">
            <h2 className="font-display font-bold uppercase">Squad Lobby</h2>
            <span className="font-mono text-xs uppercase text-muted-foreground">{members.length} of 6 ready</span>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {slots.map((m, idx) =>
              m ? (
                <MemberSlot
                  key={m.id}
                  slot={idx}
                  username={m.profile?.username ?? "Player"}
                  level={m.profile?.level}
                  gender={(m.profile as any)?.gender}
                  isOwner={m.user_id === team.owner_id}
                  canTransfer={isOwner && m.user_id !== user?.id}
                  onTransfer={() => setTransferTarget(m)}
                  canKick={isOwner && m.user_id !== team.owner_id}
                  onKick={() => kickMember(m)}
                  canFreeze={isOwner && m.user_id !== team.owner_id}
                  isFrozen={m.invite_frozen}
                  onToggleFreeze={() => toggleFreeze(m)}
                  canToggleRegister={isOwner && m.user_id !== team.owner_id}
                  isRegistrar={m.can_register}
                  onToggleRegister={() => toggleRegistrar(m)}
                />
              ) : (
                <EmptySlot key={`empty-${idx}`} slot={idx} label="Open Slot" />
              )
            )}
          </div>
        </div>

        {/* Owner-only: join requests */}
        {isOwner && (
          <div className="rounded-xl border border-border bg-card p-5">
            <h2 className="font-display font-bold uppercase">Join requests</h2>
            {requests.length === 0 ? (
              <p className="mt-2 text-sm text-muted-foreground">No pending requests.</p>
            ) : (
              <ul className="mt-3 space-y-2">
                {requests.map((r) => (
                  <li key={r.id} className="flex items-center justify-between rounded-lg border border-border p-3">
                    <div>
                      <div className="font-medium">{r.profile?.username}</div>
                      <div className="text-xs text-muted-foreground">Lv {r.profile?.level} · {r.profile?.city}</div>
                    </div>
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost" onClick={() => handleRequest(r, true)}>
                        <Check className="h-4 w-4 text-success" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => handleRequest(r, false)}>
                        <X className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}

        {/* Any member can invite — unless owner has frozen them */}
        {hasJoined && (
          <div className="rounded-xl border border-border bg-card p-5">
            <h2 className="flex items-center gap-2 font-display font-bold uppercase">
              <UserPlus className="h-4 w-4" /> Invite player
            </h2>
            {myMembership?.invite_frozen ? (
              <p className="mt-3 rounded-md border border-warning/40 bg-warning/10 p-3 text-xs text-warning">
                The team owner has frozen your ability to invite players.
              </p>
            ) : (
              <>
                <div className="relative mt-3">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} placeholder="Search username, city, or UID…" className="pl-9" />
                </div>
                {searchResults.length > 0 && (
                  <ul className="mt-3 space-y-2">
                    {searchResults.map((p) => (
                      <li key={p.id} className="flex items-center justify-between rounded-lg border border-border p-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{p.username}</span>
                            <StatusBadge status={p.verification_status} />
                          </div>
                          <div className="text-xs text-muted-foreground">Lv {p.level} · {p.city} · UID {p.ff_uid ?? "—"}</div>
                        </div>
                        <Button size="sm" onClick={() => inviteUser(p.id)} disabled={p.id === user?.id}>
                          <Send className="mr-1 h-3 w-3" /> Invite
                        </Button>
                      </li>
                    ))}
                  </ul>
                )}
              </>
            )}
          </div>
        )}

        {/* Transfer ownership confirm */}
        {transferTarget && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 p-4 backdrop-blur-sm" onClick={() => setTransferTarget(null)}>
            <div className="max-w-sm rounded-xl border border-primary/30 bg-card p-6" onClick={(e) => e.stopPropagation()}>
              <h3 className="font-display text-lg font-bold uppercase">Transfer ownership</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Send an ownership transfer request to <span className="font-bold text-foreground">{transferTarget.profile?.username}</span>?
                They must accept before the change takes effect.
              </p>
              <div className="mt-4 flex justify-end gap-2">
                <Button variant="outline" size="sm" onClick={() => setTransferTarget(null)}>Cancel</Button>
                <Button size="sm" className="gradient-bg" onClick={() => transferOwnership(transferTarget.user_id)}>Send request</Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </TooltipProvider>
  );
}
