import { createFileRoute, Outlet, useNavigate, Link } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth-context";
import { Shield, Users, Trophy, CheckSquare, Mail, BarChart3, PieChart } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/_admin")({ component: AdminLayout });

function AdminLayout() {
  const { isAdmin, loading, profile } = useAuth();
  const navigate = useNavigate();
  useEffect(() => { if (!loading && profile && !isAdmin) navigate({ to: "/profile" }); }, [isAdmin, loading, profile, navigate]);
  if (!isAdmin) return null;
  return <div className="space-y-6"><div className="rounded-xl border border-primary/30 bg-card p-5 card-glow"><div className="flex items-center gap-3"><div className="flex h-11 w-11 items-center justify-center rounded-md gradient-bg glow-primary"><Shield className="h-5 w-5 text-primary-foreground" /></div><div><h1 className="font-display text-3xl font-black uppercase">Admin <span className="gradient-text">Command</span></h1><p className="text-sm text-muted-foreground">Verification, tournaments, teams, users, analytics, and broadcasts.</p></div></div></div><nav className="grid gap-2 rounded-xl border border-border bg-card p-2 sm:grid-cols-3 lg:grid-cols-7"><AdminLink to="/admin" exact icon={<BarChart3 className="h-4 w-4" />} label="Overview" /><AdminLink to="/admin/verifications" icon={<CheckSquare className="h-4 w-4" />} label="Verify" /><AdminLink to="/admin/users" icon={<Users className="h-4 w-4" />} label="Users" /><AdminLink to="/admin/teams" icon={<Users className="h-4 w-4" />} label="Teams" /><AdminLink to="/admin/tournaments" icon={<Trophy className="h-4 w-4" />} label="Tournaments" /><AdminLink to="/admin/analytics" icon={<PieChart className="h-4 w-4" />} label="Analytics" /><AdminLink to="/mailbox" icon={<Mail className="h-4 w-4" />} label="Broadcast" /></nav><Outlet /></div>;
}
function AdminLink({ to, icon, label, exact }: { to: string; icon: React.ReactNode; label: string; exact?: boolean }) { return <Link to={to as any} activeOptions={{ exact }} className="flex items-center justify-center gap-2 rounded-md px-3 py-2 text-sm font-semibold uppercase tracking-wider text-muted-foreground hover:bg-accent hover:text-foreground" activeProps={{ className: cn("bg-primary/15 text-primary border border-primary/30") }}>{icon}{label}</Link>; }
