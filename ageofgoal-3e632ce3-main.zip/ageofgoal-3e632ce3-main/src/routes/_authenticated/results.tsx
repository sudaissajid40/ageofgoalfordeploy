import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Award, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";

export const Route = createFileRoute("/_authenticated/results")({ component: ResultsPage });

interface Tournament { id: string; name: string; status: string; starts_at: string }
interface Standing { team_id: string; team_name: string; wins: number; points: number }

function ResultsPage() {
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [standings, setStandings] = useState<Record<string, Standing[]>>({});
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from("tournaments")
      .select("id, name, status, starts_at")
      .order("starts_at", { ascending: false });
    const list = (data ?? []) as Tournament[];
    setTournaments(list);
    setSelected((cur) => {
      if (cur.length > 0) return cur;
      const completed = list.filter((t) => t.status === "completed");
      return completed.length ? [completed[0].id] : list.length ? [list[0].id] : [];
    });
    setLoading(false);
  }, []);

  useEffect(() => { void load(); }, [load]);
  useRealtimeRefresh(["tournaments", "tournament_matches"], load);

  useEffect(() => {
    (async () => {
      const next: Record<string, Standing[]> = {};
      for (const id of selected) {
        const { data } = await supabase.rpc("get_tournament_standings", { _tournament_id: id });
        next[id] = (data ?? []).map((r: any) => ({
          team_id: r.team_id, team_name: r.team_name, wins: Number(r.wins), points: Number(r.points),
        }));
      }
      setStandings(next);
    })();
  }, [selected]);

  const toggle = (id: string) => {
    setSelected((cur) => {
      if (cur.includes(id)) return cur.filter((x) => x !== id);
      if (cur.length >= 3) return [...cur.slice(1), id];
      return [...cur, id];
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-black uppercase">
          Tournament <span className="gradient-text">Results</span>
        </h1>
        <p className="text-sm text-muted-foreground">Compare up to 3 tournaments side-by-side.</p>
      </div>

      <div className="rounded-xl border border-border bg-card p-4">
        <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Pick tournaments</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {tournaments.map((t) => {
            const on = selected.includes(t.id);
            return (
              <button key={t.id} onClick={() => toggle(t.id)}
                className={`rounded-md border px-3 py-1.5 text-xs ${on ? "border-primary bg-primary/10 text-primary" : "border-border bg-background hover:border-primary/40"}`}>
                {t.name} <span className="ml-1 text-[10px] text-muted-foreground">{t.status}</span>
              </button>
            );
          })}
        </div>
      </div>

      {loading ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : selected.length === 0 ? (
        <div className="rounded-xl border border-border bg-card p-12 text-center">
          <Award className="mx-auto h-10 w-10 text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">Select a tournament above.</p>
        </div>
      ) : (
        <div className={`grid gap-4 ${selected.length === 1 ? "" : selected.length === 2 ? "lg:grid-cols-2" : "lg:grid-cols-3"}`}>
          {selected.map((id) => {
            const t = tournaments.find((x) => x.id === id);
            const rows = standings[id] ?? [];
            return (
              <div key={id} className="rounded-xl border border-border bg-card p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Link to="/tournaments/$id" params={{ id }} className="font-display font-bold uppercase gradient-text hover:underline">{t?.name ?? "—"}</Link>
                    <div className="text-[10px] uppercase text-muted-foreground">{t?.status}</div>
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => toggle(id)}>Remove</Button>
                </div>
                {rows.length === 0 ? (
                  <p className="mt-3 text-sm text-muted-foreground">No matches played yet.</p>
                ) : (
                  <ol className="mt-3 space-y-1">
                    {rows.map((r, i) => (
                      <li key={r.team_id} className={`flex items-center justify-between rounded border px-3 py-2 text-sm ${i === 0 ? "border-success/40 bg-success/5" : "border-border"}`}>
                        <span className="flex items-center gap-2">
                          <span className="font-mono text-xs text-muted-foreground">#{i + 1}</span>
                          {i === 0 && <Trophy className="h-3 w-3 text-success" />}
                          <Link to="/teams/$teamId" params={{ teamId: r.team_id }} className="font-medium hover:underline">{r.team_name}</Link>
                        </span>
                        <span className="font-mono text-xs">{r.wins}W · {r.points} pts</span>
                      </li>
                    ))}
                  </ol>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
