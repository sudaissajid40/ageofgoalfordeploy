import { createFileRoute } from "@tanstack/react-router";
import { Mail, Instagram, MessageCircle, Shield, Trophy, Users } from "lucide-react";

export const Route = createFileRoute("/_authenticated/about")({
  head: () => ({
    meta: [
      { title: "About — AOG" },
      { name: "description", content: "About Age of Goal (AOG): our mission, support team, and community channels." },
      { property: "og:title", content: "About — AOG" },
      { property: "og:description", content: "About Age of Goal (AOG): our mission, support team, and community channels." },
    ],
  }),
  component: AboutPage,
});

const SUPPORT_TEAM = [
  { name: "Tournament Ops", role: "Match scheduling & results", icon: Trophy },
  { name: "Verification Desk", role: "Account & UID verification", icon: Shield },
  { name: "Community Team", role: "Players, teams & disputes", icon: Users },
];

function AboutPage() {
  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <header>
        <h1 className="font-display text-3xl font-black uppercase tracking-tight sm:text-4xl">
          About <span className="gradient-text">AOG</span>
        </h1>
        <p className="mt-3 text-sm text-muted-foreground">
          Age of Goal (AOG) is a competitive tournament platform built for verified players and real teams.
          We host fair, structured tournaments and reward consistency with rank progression and prizes.
        </p>
      </header>

      <section className="rounded-xl border border-primary/30 bg-card p-6 card-glow">
        <h2 className="font-display text-lg font-bold uppercase tracking-wide">Our Mission</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Build a trusted home for competitive players — verified IDs, transparent results, and a ranking
          system that rewards real performance.
        </p>
      </section>

      <section>
        <h2 className="font-display text-lg font-bold uppercase tracking-wide">Support Team</h2>
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          {SUPPORT_TEAM.map(({ name, role, icon: Icon }) => (
            <div key={name} className="rounded-xl border border-border bg-card p-5 text-center">
              <Icon className="mx-auto h-6 w-6 text-primary" />
              <div className="mt-2 font-display text-sm font-bold uppercase">{name}</div>
              <div className="mt-1 text-xs text-muted-foreground">{role}</div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="font-display text-lg font-bold uppercase tracking-wide">Connect With Us</h2>
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          <a
            href="https://www.instagram.com/age_of_goal?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/50"
          >
            <Instagram className="h-6 w-6 text-primary" />
            <div className="min-w-0">
              <div className="font-display text-sm font-bold uppercase">Instagram</div>
              <div className="truncate text-xs text-muted-foreground">@age_of_goal</div>
            </div>
          </a>
          <a
            href="https://discord.gg/vdHfDwVQ"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/50"
          >
            <MessageCircle className="h-6 w-6 text-primary" />
            <div className="min-w-0">
              <div className="font-display text-sm font-bold uppercase">Discord</div>
              <div className="truncate text-xs text-muted-foreground">Join our server</div>
            </div>
          </a>
          <a
            href="mailto:ageofgoal@gmail.com"
            className="flex items-center gap-3 rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/50"
          >
            <Mail className="h-6 w-6 text-primary" />
            <div className="min-w-0">
              <div className="font-display text-sm font-bold uppercase">Email</div>
              <div className="truncate text-xs text-muted-foreground">ageofgoal@gmail.com</div>
            </div>
          </a>
        </div>
      </section>
    </div>
  );
}
