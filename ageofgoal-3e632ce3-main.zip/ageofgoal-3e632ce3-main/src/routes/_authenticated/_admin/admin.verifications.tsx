import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Check, X, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import type { Database } from "@/integrations/supabase/types";
import { REGION_LABEL, type Region } from "@/lib/region";

type Profile = Database["public"]["Tables"]["profiles"]["Row"];

export const Route = createFileRoute("/_authenticated/_admin/admin/verifications")({
  component: VerificationsPage,
});

function VerificationsPage() {
  const [pending, setPending] = useState<Profile[]>([]);
  const [reasons, setReasons] = useState<Record<string, string>>({});

  const load = async () => {
    const { data } = await supabase
      .from("profiles")
      .select("*")
      .eq("verification_status", "pending")
      .eq("profile_completed", true)
      .order("created_at", { ascending: true });
    setPending(data ?? []);
  };

  useEffect(() => { void load(); }, []);

  const approve = async (id: string) => {
    const { error } = await supabase
      .from("profiles")
      .update({ verification_status: "approved", rejection_reason: null })
      .eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Verified! User can now access tournaments.");
    void load();
  };

  const reject = async (id: string) => {
    const reason = reasons[id]?.trim() || "Did not meet verification criteria";
    const { error } = await supabase
      .from("profiles")
      .update({ verification_status: "rejected", rejection_reason: reason })
      .eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Rejected");
    void load();
  };

  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="flex items-center gap-2">
        <ShieldCheck className="h-5 w-5 text-primary" />
        <h2 className="font-semibold">Pending verifications ({pending.length})</h2>
      </div>
      {pending.length === 0 ? (
        <p className="mt-3 text-sm text-muted-foreground">No pending profiles. 🎉</p>
      ) : (
        <ul className="mt-3 space-y-3">
          {pending.map((p) => (
            <li key={p.id} className="rounded-lg border border-border p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="font-display text-lg font-bold">{p.username}</div>
                  <div className="mt-1 text-xs text-muted-foreground space-x-2">
                    <span>FF Lv {p.level}</span>
                    <span>·</span>
                    <span>{p.city}</span>
                    <span>·</span>
                    <span className="uppercase">{p.region ? REGION_LABEL[p.region as Region] : "—"}</span>
                  </div>
                  <div className="mt-1 font-mono text-[11px] text-muted-foreground">
                    Joined {new Date(p.created_at).toLocaleDateString()}
                  </div>
                </div>
                <div className="flex flex-wrap items-end gap-2">
                  <Input
                    placeholder="Rejection reason (optional)"
                    value={reasons[p.id] ?? ""}
                    onChange={(e) => setReasons((r) => ({ ...r, [p.id]: e.target.value }))}
                    className="w-56"
                  />
                  <Button size="sm" onClick={() => approve(p.id)} className="bg-success text-success-foreground hover:bg-success/90">
                    <Check className="mr-1 h-4 w-4" /> Verify
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => reject(p.id)}>
                    <X className="mr-1 h-4 w-4" /> Reject
                  </Button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
