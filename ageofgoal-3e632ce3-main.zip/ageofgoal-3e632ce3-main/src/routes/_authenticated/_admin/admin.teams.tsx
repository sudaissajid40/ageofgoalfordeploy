import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Users, Crown, ChevronRight, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { REGION_LABEL, type Region } from "@/lib/region";

export const Route = createFileRoute("/_authenticated/_admin/admin/teams")({
  component: AdminTeamsPage,
});

interface MemberInfo {
  user_id: string;
  username: string | null;
  level: number | null;
  verification_status: string;
  can_register: boolean;
  invite_frozen: boolean;
}
interface TeamRow {
  id: string;
  name: string;
  team_level: number;
  aog_points: number;
  region: Region | null;
  owner_id: string;
  join_code: string;
  created_at: string;
  members: MemberInfo[];
}

function AdminTeamsPage() {
  const [teams, setTeams] = useState<TeamRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");

  useEffect(() => {
    void (async () => {
      setLoading(true);
      const { data: ts } = await supabase
        .from("teams")
        .select("id, name, team_level, aog_points, region, owner_id, join_code, created_at")
        .order("team_level", { ascending: false });
      const teamIds = (ts ?? []).map((t) => t.id);
      const [{ data: members }, { data: profs }] = await Promise.all([
        teamIds.length
          ? supabase.from("team_members").select("team_id, user_id, can_register, invite_frozen").in("team_id", teamIds)
          : Promise.resolve({ data: [] as any[] }),
        supabase.from("profiles").select("id, username, level, verification_status"),
      ]);
      const profMap = new Map((profs ?? []).map((p: any) => [p.id, p]));
      const byTeam = new Map<string, MemberInfo[]>();
      (members ?? []).forEach((m: any) => {
        const p = profMap.get(m.user_id);
        const arr = byTeam.get(m.team_id) ?? [];
        arr.push({
          user_id: m.user_id,
          username: p?.username ?? null,
          level: p?.level ?? null,
          verification_status: p?.verification_status ?? "pending",
          can_register: !!m.can_register,
          invite_frozen: !!m.invite_frozen,
        });
        byTeam.set(m.team_id, arr);
      });
      setTeams(
        (ts ?? []).map((t: any) => ({ ...t, members: byTeam.get(t.id) ?? [] }))
      );
      setLoading(false);
    })();
  }, []);

  const filtered = teams.filter(
    (t) =>
      !q.trim() ||
      t.name.toLowerCase().includes(q.toLowerCase()) ||
      t.join_code.toLowerCase().includes(q.toLowerCase()) ||
      t.members.some((m) => m.username?.toLowerCase().includes(q.toLowerCase()))
  );

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-border bg-card p-4">
        <div className="flex items-center justify-between">
          <h2 className="font-display font-bold uppercase">All teams ({teams.length})</h2>
        </div>
        <div className="relative mt-3">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by team name, code, or member…" className="pl-9" />
        </div>
      </div>

      {loading ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : filtered.length === 0 ? (
        <p className="text-sm text-muted-foreground">No teams found.</p>
      ) : (
        <div className="grid gap-3">
          {filtered.map((t) => (
            <div key={t.id} className="rounded-xl border border-border bg-card p-4 card-glow">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-md bg-primary/15">
                    <Users className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <div className="font-display text-lg font-bold uppercase">{t.name}</div>
                    <div className="text-xs text-muted-foreground">
                      Lv {t.team_level} · {t.aog_points} pts · {t.region ? REGION_LABEL[t.region] : "—"} ·
                      <span className="ml-1 font-mono">{t.join_code}</span>
                    </div>
                  </div>
                </div>
                <Link
                  to="/teams/$teamId"
                  params={{ teamId: t.id }}
                  className="inline-flex items-center gap-1 rounded-md border border-primary/40 bg-primary/10 px-3 py-1.5 text-xs font-bold uppercase text-primary hover:bg-primary/20"
                >
                  Open <ChevronRight className="h-3 w-3" />
                </Link>
              </div>
              <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {t.members.length === 0 && (
                  <p className="text-xs text-muted-foreground">No members.</p>
                )}
                {t.members.map((m) => {
                  const isOwner = m.user_id === t.owner_id;
                  return (
                    <Link
                      key={m.user_id}
                      to="/admin/users/$userId"
                      params={{ userId: m.user_id }}
                      className="flex items-center justify-between rounded-md border border-border bg-background/40 px-3 py-2 text-xs hover:border-primary/40"
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-1 font-medium">
                          {isOwner && <Crown className="h-3 w-3 text-primary" />}
                          <span className="truncate">{m.username ?? "—"}</span>
                        </div>
                        <div className="text-[10px] uppercase text-muted-foreground">
                          Lv {m.level ?? "-"} · {m.verification_status}
                          {m.can_register && " · registrar"}
                          {m.invite_frozen && " · frozen"}
                        </div>
                      </div>
                    </Link>
                  );
                })}
              </div>
              <div className="mt-2 text-[10px] uppercase text-muted-foreground">
                {t.members.length}/6 members
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
