import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { BarChart3, Users, Trophy, MapPin, UserCheck, TrendingUp, X } from "lucide-react";
import { useVisibilityRefresh } from "@/hooks/useVisibilityRefresh";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/StatusBadge";
import { REGION_LABEL, type Region } from "@/lib/region";
import type { Database } from "@/integrations/supabase/types";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RTooltip,
  PieChart, Pie, Cell, LineChart, Line, Legend,
} from "recharts";

type Profile = Database["public"]["Tables"]["profiles"]["Row"];
type DrillDim = "region" | "gender" | "age" | "level" | "verification" | "play_style" | "signup_day";
interface Drill { dim: DrillDim; value: string; label: string }

export const Route = createFileRoute("/_authenticated/_admin/admin/analytics")({ component: AnalyticsPage });

const COLORS = ["oklch(0.7 0.18 25)", "oklch(0.75 0.16 200)", "oklch(0.7 0.18 150)", "oklch(0.82 0.17 90)", "oklch(0.65 0.2 320)", "oklch(0.6 0.18 260)"];

interface Bucket { bucket: string; count: number }
interface RegionRow { region: string; count: number; total_points: number }
interface KeyVal { name: string; value: number }
interface DayRow { day: string; signups: number; _raw?: string }
interface SizeRow { size: number; team_count: number }

function AnalyticsPage() {
  const [signups, setSignups] = useState<DayRow[]>([]);
  const [regions, setRegions] = useState<RegionRow[]>([]);
  const [genders, setGenders] = useState<KeyVal[]>([]);
  const [ages, setAges] = useState<Bucket[]>([]);
  const [levels, setLevels] = useState<Bucket[]>([]);
  const [verifications, setVerifications] = useState<KeyVal[]>([]);
  const [playStyles, setPlayStyles] = useState<KeyVal[]>([]);
  const [teamSizes, setTeamSizes] = useState<SizeRow[]>([]);
  const [partRate, setPartRate] = useState<{ verified_users: number; participants: number; rate: number } | null>(null);
  const [totals, setTotals] = useState({ users: 0, teams: 0, tournaments: 0 });
  const [drill, setDrill] = useState<Drill | null>(null);
  const [drillUsers, setDrillUsers] = useState<Profile[] | null>(null);
  const [drillLoading, setDrillLoading] = useState(false);

  const openDrill = useCallback(async (d: Drill) => {
    setDrill(d);
    setDrillLoading(true);
    setDrillUsers(null);
    let q = supabase.from("profiles").select("*").order("created_at", { ascending: false }).limit(500);
    switch (d.dim) {
      case "region":
        q = d.value === "unknown" ? q.is("region", null) : q.eq("region", d.value as Region);
        break;
      case "gender":
        q = d.value === "unknown" ? q.is("gender", null) : q.eq("gender", d.value as NonNullable<Profile["gender"]>);
        break;
      case "verification":
        q = q.eq("verification_status", d.value as Profile["verification_status"]);
        break;
      case "play_style":
        q = d.value === "unknown" ? q.is("play_style", null) : q.eq("play_style", d.value);
        break;
      case "age": {
        const ranges: Record<string, [number | null, number | null]> = {
          "10-15": [10, 15], "16-18": [16, 18], "19-22": [19, 22], "23-30": [23, 30], "31+": [31, 200],
        };
        if (d.value === "unknown") q = q.is("age", null);
        else { const [lo, hi] = ranges[d.value] ?? [null, null]; if (lo !== null && hi !== null) q = q.gte("age", lo).lte("age", hi); }
        break;
      }
      case "level": {
        const ranges: Record<string, [number, number]> = {
          "1-10": [1, 10], "11-20": [11, 20], "21-30": [21, 30], "31-40": [31, 40],
          "41-50": [41, 50], "51-60": [51, 60], "61-70": [61, 70], "71+": [71, 999],
        };
        if (d.value === "unknown") q = q.is("level", null);
        else { const r = ranges[d.value]; if (r) q = q.gte("level", r[0]).lte("level", r[1]); }
        break;
      }
      case "signup_day": {
        const start = new Date(d.value); start.setHours(0, 0, 0, 0);
        const end = new Date(start); end.setDate(end.getDate() + 1);
        q = q.gte("created_at", start.toISOString()).lt("created_at", end.toISOString());
        break;
      }
    }
    const { data } = await q;
    setDrillUsers((data as Profile[]) ?? []);
    setDrillLoading(false);
  }, []);

  const load = useCallback(async () => {
    const [sup, reg, gen, age, lvl, ver, ps, ts, pr, uCount, tCount, trCount] = await Promise.all([
      supabase.rpc("analytics_signups_by_day", { _days: 30 }),
      supabase.rpc("analytics_region_breakdown"),
      supabase.rpc("analytics_gender_breakdown"),
      supabase.rpc("analytics_age_buckets"),
      supabase.rpc("analytics_level_buckets"),
      supabase.rpc("analytics_verification_breakdown"),
      supabase.rpc("analytics_play_style_breakdown"),
      supabase.rpc("analytics_team_size_distribution"),
      supabase.rpc("analytics_participation_rate"),
      supabase.from("profiles").select("id", { count: "exact", head: true }),
      supabase.from("teams").select("id", { count: "exact", head: true }),
      supabase.from("tournaments").select("id", { count: "exact", head: true }),
    ]);
    setSignups(((sup.data ?? []) as DayRow[]).map((r) => ({ ...r, _raw: r.day, day: new Date(r.day).toLocaleDateString(undefined, { month: "short", day: "numeric" }), signups: Number(r.signups) }) as DayRow & { _raw: string }));
    setRegions(((reg.data ?? []) as RegionRow[]).map((r) => ({ ...r, count: Number(r.count), total_points: Number(r.total_points) })));
    setGenders(((gen.data ?? []) as { gender: string; count: number }[]).map((r) => ({ name: r.gender, value: Number(r.count) })));
    setAges(((age.data ?? []) as Bucket[]).map((r) => ({ ...r, count: Number(r.count) })));
    setLevels(((lvl.data ?? []) as Bucket[]).map((r) => ({ ...r, count: Number(r.count) })));
    setVerifications(((ver.data ?? []) as { status: string; count: number }[]).map((r) => ({ name: r.status, value: Number(r.count) })));
    setPlayStyles(((ps.data ?? []) as { style: string; count: number }[]).map((r) => ({ name: r.style, value: Number(r.count) })));
    setTeamSizes(((ts.data ?? []) as SizeRow[]).map((r) => ({ size: Number(r.size), team_count: Number(r.team_count) })));
    const prRow = ((pr.data ?? []) as { verified_users: number; participants: number; rate: number }[])[0];
    if (prRow) setPartRate({ verified_users: Number(prRow.verified_users), participants: Number(prRow.participants), rate: Number(prRow.rate) });
    setTotals({ users: uCount.count ?? 0, teams: tCount.count ?? 0, tournaments: trCount.count ?? 0 });
  }, []);

  useEffect(() => { void load(); }, [load]);
  useVisibilityRefresh(load, [load]);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-2xl font-black uppercase">Audience <span className="gradient-text">Analytics</span></h2>
        <p className="text-sm text-muted-foreground">Real-time insights across all profile dimensions. <span className="text-primary">Click any bar or slice to view the players inside.</span></p>
      </div>

      {/* KPIs */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <KPI label="Total Players" value={totals.users} icon={<Users className="h-5 w-5" />} />
        <KPI label="Active Teams" value={totals.teams} icon={<Trophy className="h-5 w-5" />} />
        <KPI label="Tournaments" value={totals.tournaments} icon={<BarChart3 className="h-5 w-5" />} />
        <KPI label="Participation Rate" value={partRate ? `${partRate.rate}%` : "—"} icon={<TrendingUp className="h-5 w-5" />} sub={partRate ? `${partRate.participants}/${partRate.verified_users} verified` : undefined} />
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <ChartCard title="Signups (last 30 days)" icon={<UserCheck className="h-4 w-4" />}>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={signups} onClick={(e) => { const p = e?.activePayload?.[0]?.payload as { _raw?: string; day: string } | undefined; if (p?._raw) void openDrill({ dim: "signup_day", value: p._raw, label: `Signed up on ${p.day}` }); }} style={{ cursor: "pointer" }}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0.02 260)" />
              <XAxis dataKey="day" stroke="oklch(0.6 0.02 260)" fontSize={10} />
              <YAxis stroke="oklch(0.6 0.02 260)" fontSize={10} allowDecimals={false} />
              <RTooltip contentStyle={{ background: "oklch(0.18 0.02 260)", border: "1px solid oklch(0.3 0.02 260)", borderRadius: 8 }} />
              <Line type="monotone" dataKey="signups" stroke={COLORS[0]} strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Region Breakdown" icon={<MapPin className="h-4 w-4" />}>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={regions} onClick={(e) => { const p = e?.activePayload?.[0]?.payload as RegionRow | undefined; if (p) void openDrill({ dim: "region", value: p.region, label: `Region: ${p.region}` }); }} style={{ cursor: "pointer" }}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0.02 260)" />
              <XAxis dataKey="region" stroke="oklch(0.6 0.02 260)" fontSize={10} />
              <YAxis stroke="oklch(0.6 0.02 260)" fontSize={10} allowDecimals={false} />
              <RTooltip contentStyle={{ background: "oklch(0.18 0.02 260)", border: "1px solid oklch(0.3 0.02 260)", borderRadius: 8 }} />
              <Bar dataKey="count" fill={COLORS[1]} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Gender Distribution">
          <PieCard data={genders} onSlice={(name) => void openDrill({ dim: "gender", value: name, label: `Gender: ${name}` })} />
        </ChartCard>

        <ChartCard title="Verification Status">
          <PieCard data={verifications} onSlice={(name) => void openDrill({ dim: "verification", value: name, label: `Verification: ${name}` })} />
        </ChartCard>

        <ChartCard title="Age Buckets">
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={ages} onClick={(e) => { const p = e?.activePayload?.[0]?.payload as Bucket | undefined; if (p) void openDrill({ dim: "age", value: p.bucket, label: `Age ${p.bucket}` }); }} style={{ cursor: "pointer" }}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0.02 260)" />
              <XAxis dataKey="bucket" stroke="oklch(0.6 0.02 260)" fontSize={10} />
              <YAxis stroke="oklch(0.6 0.02 260)" fontSize={10} allowDecimals={false} />
              <RTooltip contentStyle={{ background: "oklch(0.18 0.02 260)", border: "1px solid oklch(0.3 0.02 260)", borderRadius: 8 }} />
              <Bar dataKey="count" fill={COLORS[2]} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Player Level Buckets">
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={levels} onClick={(e) => { const p = e?.activePayload?.[0]?.payload as Bucket | undefined; if (p) void openDrill({ dim: "level", value: p.bucket, label: `Level ${p.bucket}` }); }} style={{ cursor: "pointer" }}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0.02 260)" />
              <XAxis dataKey="bucket" stroke="oklch(0.6 0.02 260)" fontSize={10} />
              <YAxis stroke="oklch(0.6 0.02 260)" fontSize={10} allowDecimals={false} />
              <RTooltip contentStyle={{ background: "oklch(0.18 0.02 260)", border: "1px solid oklch(0.3 0.02 260)", borderRadius: 8 }} />
              <Bar dataKey="count" fill={COLORS[3]} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Play Style">
          <PieCard data={playStyles} onSlice={(name) => void openDrill({ dim: "play_style", value: name, label: `Play style: ${name}` })} />
        </ChartCard>

        <ChartCard title="Team Size Distribution">
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={teamSizes}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0.02 260)" />
              <XAxis dataKey="size" stroke="oklch(0.6 0.02 260)" fontSize={10} />
              <YAxis stroke="oklch(0.6 0.02 260)" fontSize={10} allowDecimals={false} />
              <RTooltip contentStyle={{ background: "oklch(0.18 0.02 260)", border: "1px solid oklch(0.3 0.02 260)", borderRadius: 8 }} />
              <Bar dataKey="team_count" fill={COLORS[4]} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="AOG Points by Region">
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={regions} onClick={(e) => { const p = e?.activePayload?.[0]?.payload as RegionRow | undefined; if (p) void openDrill({ dim: "region", value: p.region, label: `Region: ${p.region}` }); }} style={{ cursor: "pointer" }}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0.02 260)" />
              <XAxis dataKey="region" stroke="oklch(0.6 0.02 260)" fontSize={10} />
              <YAxis stroke="oklch(0.6 0.02 260)" fontSize={10} />
              <RTooltip contentStyle={{ background: "oklch(0.18 0.02 260)", border: "1px solid oklch(0.3 0.02 260)", borderRadius: 8 }} />
              <Bar dataKey="total_points" fill={COLORS[5]} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Tournament Participation">
          <div className="flex h-[260px] flex-col items-center justify-center gap-3">
            <div className="font-display text-6xl font-black gradient-text">{partRate?.rate ?? 0}%</div>
            <div className="text-sm text-muted-foreground">
              <span className="font-bold text-foreground">{partRate?.participants ?? 0}</span> of{" "}
              <span className="font-bold text-foreground">{partRate?.verified_users ?? 0}</span> verified players have joined a tournament
            </div>
          </div>
        </ChartCard>
      </div>

      {drill && (
        <DrillPanel drill={drill} users={drillUsers} loading={drillLoading} onClose={() => { setDrill(null); setDrillUsers(null); }} />
      )}
    </div>
  );
}

function DrillPanel({ drill, users, loading, onClose }: { drill: Drill; users: Profile[] | null; loading: boolean; onClose: () => void }) {
  return (
    <div className="rounded-xl border border-primary/30 bg-card p-5 card-glow">
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="font-display text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Drill-down</div>
          <h3 className="font-display text-lg font-bold uppercase">{drill.label} <span className="text-muted-foreground">· {users?.length ?? 0} player{(users?.length ?? 0) === 1 ? "" : "s"}</span></h3>
        </div>
        <Button size="sm" variant="ghost" onClick={onClose}><X className="h-4 w-4" /></Button>
      </div>
      <div className="mt-4 max-h-[420px] overflow-y-auto">
        {loading ? (
          <p className="text-sm text-muted-foreground">Loading players…</p>
        ) : (users && users.length > 0) ? (
          <ul className="space-y-2">
            {users.map((u) => (
              <li key={u.id}>
                <Link to="/admin/users/$userId" params={{ userId: u.id }} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border p-3 hover:border-primary/40 hover:bg-primary/5">
                  <div className="flex min-w-0 items-center gap-3">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 font-bold">{u.username?.[0]?.toUpperCase() ?? "?"}</div>
                    <div className="min-w-0">
                      <div className="font-medium">{u.username ?? <span className="italic text-muted-foreground">No profile</span>}</div>
                      <div className="text-xs text-muted-foreground">Lv {u.level ?? "-"} · {u.city ?? "-"} · {u.region ? REGION_LABEL[u.region as Region] : "-"} · {u.aog_points} pts</div>
                    </div>
                  </div>
                  <StatusBadge status={u.verification_status} />
                </Link>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-muted-foreground">No players match this segment.</p>
        )}
      </div>
    </div>
  );
}

function KPI({ label, value, icon, sub }: { label: string; value: number | string; icon: React.ReactNode; sub?: string }) {
  return (
    <div className="rounded-xl border border-primary/20 bg-card p-5 card-glow">
      <div className="flex items-center justify-between">
        <span className="font-display text-[10px] font-bold uppercase tracking-widest text-muted-foreground">{label}</span>
        <span className="text-primary">{icon}</span>
      </div>
      <div className="mt-2 font-display text-3xl font-black gradient-text">{value}</div>
      {sub && <div className="mt-1 text-[10px] text-muted-foreground">{sub}</div>}
    </div>
  );
}

function ChartCard({ title, icon, children }: { title: string; icon?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <h3 className="flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wide">
        {icon}{title}
      </h3>
      <div className="mt-3">{children}</div>
    </div>
  );
}

function PieCard({ data, onSlice }: { data: KeyVal[]; onSlice?: (name: string) => void }) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <PieChart>
        <Pie
          data={data}
          dataKey="value"
          nameKey="name"
          cx="50%"
          cy="50%"
          outerRadius={80}
          innerRadius={45}
          paddingAngle={3}
          onClick={(d: { name?: string }) => { if (onSlice && d?.name) onSlice(d.name); }}
          style={{ cursor: onSlice ? "pointer" : "default" }}
        >
          {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
        </Pie>
        <RTooltip contentStyle={{ background: "oklch(0.18 0.02 260)", border: "1px solid oklch(0.3 0.02 260)", borderRadius: 8 }} />
        <Legend wrapperStyle={{ fontSize: 11 }} />
      </PieChart>
    </ResponsiveContainer>
  );
}
