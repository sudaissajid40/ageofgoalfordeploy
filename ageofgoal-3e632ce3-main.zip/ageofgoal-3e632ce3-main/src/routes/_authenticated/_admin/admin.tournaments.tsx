import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Plus, Trophy, Trash2, Award, Settings, CalendarDays, Lock, Wand2, ImageIcon, CalendarIcon } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { formatPKTDateTime, pktToUtcIso, todayPKT } from "@/lib/time";
import type { Database } from "@/integrations/supabase/types";

type Tournament = Database["public"]["Tables"]["tournaments"]["Row"];
export const Route = createFileRoute("/_authenticated/_admin/admin/tournaments")({ component: AdminTournamentsPage });

interface FormState {
  name: string; description: string; type: "solo" | "team"; rules: string;
  startDate: string; startTime: string;
  regEndDate: string; regEndTime: string;
  matchTeamSize: string; minMembers: string; maxMembers: string;
  pointsPerWin: string; championMult: string;
  bracketSize: string;
  sponsorName: string; sponsorHook: string; sponsorCtaLabel: string; sponsorCtaUrl: string;
  entryFee: string; payAccountLabel: string; payAccountNumber: string; payInstructions: string;
}

function AdminTournamentsPage() {
  const { user } = useAuth();
  const [list, setList] = useState<Tournament[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<FormState>({
    name: "", description: "", type: "team", rules: "",
    startDate: todayPKT(), startTime: "20:00",
    regEndDate: todayPKT(), regEndTime: "18:00",
    matchTeamSize: "4", minMembers: "4", maxMembers: "6",
    pointsPerWin: "2", championMult: "2", bracketSize: "4",
    sponsorName: "", sponsorHook: "", sponsorCtaLabel: "", sponsorCtaUrl: "",
    entryFee: "0", payAccountLabel: "", payAccountNumber: "", payInstructions: "",
  });
  const [thumbnail, setThumbnail] = useState<File | null>(null);
  const [sponsorBannerUrl, setSponsorBannerUrl] = useState<string>("");
  const [generatingBanner, setGeneratingBanner] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => setForm((f) => ({ ...f, [key]: value }));

  const load = async () => {
    const { data } = await supabase.from("tournaments").select("*").order("created_at", { ascending: false });
    setList(data ?? []);
  };
  useEffect(() => { void load(); }, []);

  const create = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!form.name.trim() || !form.startDate || !form.startTime || !form.regEndDate || !form.regEndTime) {
      return toast.error("Name, start date/time, and registration deadline are required");
    }
    setSubmitting(true);

    let thumbnail_url: string | null = null;
    if (thumbnail) {
      const ext = thumbnail.name.split(".").pop() || "jpg";
      const path = `${user.id}/${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("tournament-thumbnails").upload(path, thumbnail, { upsert: false, contentType: thumbnail.type });
      if (upErr) {
        setSubmitting(false);
        return toast.error("Thumbnail upload failed: " + upErr.message);
      }
      const { data: pub } = supabase.storage.from("tournament-thumbnails").getPublicUrl(path);
      thumbnail_url = pub.publicUrl;
    }

    const { error } = await supabase.from("tournaments").insert({
      name: form.name.trim(),
      description: form.description.trim() || null,
      type: form.type,
      rules: form.rules.trim() || null,
      starts_at: pktToUtcIso(form.startDate, form.startTime),
      registration_ends_at: pktToUtcIso(form.regEndDate, form.regEndTime),
      match_team_size: parseInt(form.matchTeamSize, 10),
      min_team_members: parseInt(form.minMembers, 10),
      max_team_members: parseInt(form.maxMembers, 10),
      points_per_match_win: parseInt(form.pointsPerWin, 10),
      champion_points_multiplier: parseInt(form.championMult, 10),
      bracket_size: parseInt(form.bracketSize, 10),
      thumbnail_url,
      sponsor_name: form.sponsorName.trim() || null,
      sponsor_hook: form.sponsorHook.trim() || null,
      sponsor_cta_label: form.sponsorCtaLabel.trim() || null,
      sponsor_cta_url: form.sponsorCtaUrl.trim() || null,
      sponsor_banner_url: sponsorBannerUrl || null,
      entry_fee: parseFloat(form.entryFee || "0") || 0,
      payment_account_label: form.payAccountLabel.trim() || null,
      payment_account_number: form.payAccountNumber.trim() || null,
      payment_instructions: form.payInstructions.trim() || null,
      point_payouts: {},
      created_by: user.id,
    } as any);
    setSubmitting(false);
    if (error) return toast.error(error.message);
    toast.success("Tournament created and notices sent");
    setShowForm(false);
    setForm((f) => ({ ...f, name: "", description: "", rules: "", sponsorName: "", sponsorHook: "", sponsorCtaLabel: "", sponsorCtaUrl: "", entryFee: "0", payAccountLabel: "", payAccountNumber: "", payInstructions: "" }));
    setThumbnail(null);
    setSponsorBannerUrl("");
    void load();
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this tournament?")) return;
    const { error } = await supabase.from("tournaments").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    void load();
  };
  const setStatus = async (id: string, status: "upcoming" | "live" | "completed") => {
    const { error } = await supabase.from("tournaments").update({ status }).eq("id", id);
    if (error) return toast.error(error.message);
    void load();
  };
  const closeRegistration = async (id: string) => {
    if (!confirm("Close registration for this tournament now?")) return;
    const { error } = await supabase.from("tournaments").update({ registration_ends_at: new Date().toISOString() }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Registration closed");
    void load();
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-2xl font-black uppercase">Tournament <span className="gradient-text">Management</span></h2>
          <p className="text-sm text-muted-foreground">Times in Lahore (PKT). Thumbnails appear on the tournaments list.</p>
        </div>
        <Button onClick={() => setShowForm((s) => !s)} className="gradient-bg">
          <Plus className="mr-1 h-4 w-4" /> {showForm ? "Close" : "Create tournament"}
        </Button>
      </div>

      {showForm && (
        <form onSubmit={create} className="space-y-5 rounded-xl border border-primary/30 bg-card p-5 card-glow">
          <Section icon={<Trophy className="h-4 w-4" />} title="Basic info" />
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Tournament name" span><Input value={form.name} onChange={(e) => set("name", e.target.value)} required /></Field>
            <Field label="Type">
              <select className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm" value={form.type} onChange={(e) => set("type", e.target.value as any)}>
                <option value="team">Team</option>
                <option value="solo">Solo</option>
              </select>
            </Field>
            <Field label="Match size">
              <select className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm" value={form.matchTeamSize} onChange={(e) => set("matchTeamSize", e.target.value)}>
                <option value="4">Squad 4</option>
                <option value="2">Duo 2</option>
                <option value="1">Solo 1</option>
              </select>
            </Field>
            <Field label="Description" span><Input value={form.description} onChange={(e) => set("description", e.target.value)} /></Field>
            <Field label="Thumbnail (optional)" span>
              <div className="flex items-center gap-2">
                <Input type="file" accept="image/*" onChange={(e) => setThumbnail(e.target.files?.[0] ?? null)} />
                {thumbnail && <span className="text-xs text-muted-foreground"><ImageIcon className="inline h-3 w-3" /> {thumbnail.name}</span>}
              </div>
            </Field>
          </div>

          <Section icon={<CalendarDays className="h-4 w-4" />} title="Schedule (Lahore time)" />
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Field label="Registration ends — date">
              <DatePickerField value={form.regEndDate} onChange={(v) => set("regEndDate", v)} />
            </Field>
            <Field label="Registration ends — time">
              <Input type="time" value={form.regEndTime} onChange={(e) => set("regEndTime", e.target.value)} required />
            </Field>
            <Field label="Tournament starts — date">
              <DatePickerField value={form.startDate} onChange={(v) => set("startDate", v)} />
            </Field>
            <Field label="Tournament starts — time">
              <Input type="time" value={form.startTime} onChange={(e) => set("startTime", e.target.value)} required />
            </Field>
          </div>

          <Section icon={<Settings className="h-4 w-4" />} title="Rules and points" />
          <div className="grid gap-3 sm:grid-cols-4">
            <Field label="Min members"><Input type="number" min={1} max={6} value={form.minMembers} onChange={(e) => set("minMembers", e.target.value)} /></Field>
            <Field label="Max members"><Input type="number" min={1} max={6} value={form.maxMembers} onChange={(e) => set("maxMembers", e.target.value)} /></Field>
            <Field label="Win points"><Input type="number" min={0} value={form.pointsPerWin} onChange={(e) => set("pointsPerWin", e.target.value)} /></Field>
            <Field label="Champion multiplier"><Input type="number" min={0} value={form.championMult} onChange={(e) => set("championMult", e.target.value)} /></Field>
            <Field label="Bracket size (knockout)">
              <select className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm" value={form.bracketSize} onChange={(e) => set("bracketSize", e.target.value)}>
                <option value="2">Final only (2)</option>
                <option value="4">Semis (4)</option>
                <option value="8">Quarters (8)</option>
              </select>
            </Field>
            <Field label="Rules" span><Textarea value={form.rules} onChange={(e) => set("rules", e.target.value)} rows={3} /></Field>
          </div>

          <Section icon={<ImageIcon className="h-4 w-4" />} title="Sponsor (optional)" />
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Sponsor name"><Input value={form.sponsorName} onChange={(e) => set("sponsorName", e.target.value)} /></Field>
            <Field label="Hook / tagline"><Input value={form.sponsorHook} onChange={(e) => set("sponsorHook", e.target.value)} /></Field>
            <Field label="CTA label"><Input value={form.sponsorCtaLabel} onChange={(e) => set("sponsorCtaLabel", e.target.value)} placeholder="Visit site" /></Field>
            <Field label="CTA URL"><Input type="url" value={form.sponsorCtaUrl} onChange={(e) => set("sponsorCtaUrl", e.target.value)} placeholder="https://..." /></Field>
            <Field label="Sponsor banner" span>
              <div className="flex flex-wrap items-center gap-2">
                <Button type="button" variant="outline" disabled={generatingBanner || !form.sponsorName.trim()}
                  onClick={async () => {
                    setGeneratingBanner(true);
                    const { data, error } = await supabase.functions.invoke("generate-sponsor-banner", {
                      body: { tournament_name: form.name, sponsor_name: form.sponsorName, sponsor_hook: form.sponsorHook },
                    });
                    setGeneratingBanner(false);
                    if (error || !data?.url) return toast.error("Banner generation failed");
                    setSponsorBannerUrl(data.url);
                    toast.success("Banner generated");
                  }}>
                  <Wand2 className="mr-1 h-3 w-3" />{generatingBanner ? "Generating..." : "Generate banner with AI"}
                </Button>
                {sponsorBannerUrl && <img src={sponsorBannerUrl} alt="" className="h-12 rounded border border-border" />}
              </div>
            </Field>
          </div>

          <Section icon={<Lock className="h-4 w-4" />} title="Entry fee (optional — paid tournament)" />
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Entry fee (PKR)"><Input type="number" min={0} step="1" value={form.entryFee} onChange={(e) => set("entryFee", e.target.value)} /></Field>
            <Field label="Account label (e.g. JazzCash)"><Input value={form.payAccountLabel} onChange={(e) => set("payAccountLabel", e.target.value)} /></Field>
            <Field label="Account / phone number" span><Input value={form.payAccountNumber} onChange={(e) => set("payAccountNumber", e.target.value)} /></Field>
            <Field label="Payment instructions" span><Textarea rows={2} value={form.payInstructions} onChange={(e) => set("payInstructions", e.target.value)} /></Field>
          </div>

          <Button type="submit" disabled={submitting} className="gradient-bg glow-primary">
            {submitting ? "Creating..." : "Create and notify players"}
          </Button>
        </form>
      )}

      <div className="grid gap-3">
        {list.map((t) => {
          const regOpen = t.registration_ends_at ? new Date(t.registration_ends_at) > new Date() : true;
          return (
            <article key={t.id} className="rounded-xl border border-border bg-card p-4 card-glow">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="flex gap-3">
                  {t.thumbnail_url && (
                    <img src={t.thumbnail_url} alt="" className="h-16 w-16 rounded object-cover" />
                  )}
                  <div>
                    <div className="flex items-center gap-2">
                      <Trophy className="h-4 w-4 text-primary" />
                      <span className="font-display font-bold uppercase">{t.name}</span>
                      <span className="rounded bg-primary/10 px-1.5 py-0.5 text-[10px] uppercase text-primary">{t.type}</span>
                      {!regOpen && <span className="rounded bg-destructive/10 px-1.5 py-0.5 text-[10px] uppercase text-destructive">Reg closed</span>}
                    </div>
                    <div className="mt-2 grid gap-1 text-xs text-muted-foreground sm:grid-cols-2">
                      <span><CalendarDays className="mr-1 inline h-3 w-3" />Starts {formatPKTDateTime(t.starts_at)}</span>
                      <span>Reg ends {formatPKTDateTime(t.registration_ends_at)}</span>
                      <span>Match size {t.match_team_size} · Team {t.min_team_members}-{t.max_team_members}</span>
                      <span>Win {t.points_per_match_win} pts · Champion {t.champion_points_multiplier}× members · Bracket {t.bracket_size ?? "—"}</span>
                    </div>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <select value={t.status} onChange={(e) => setStatus(t.id, e.target.value as any)} className="h-9 rounded-md border border-input bg-background px-2 text-xs">
                    <option value="upcoming">Upcoming</option>
                    <option value="live">Live</option>
                    <option value="completed">Completed</option>
                  </select>
                  {regOpen && <Button size="sm" variant="outline" onClick={() => closeRegistration(t.id)}><Lock className="mr-1 h-3 w-3" /> Close reg</Button>}
                  <Button asChild size="sm" variant="outline"><Link to="/admin/tournaments/$id/results" params={{ id: t.id }}><Wand2 className="mr-1 h-3 w-3" /> Schedule</Link></Button>
                  <Button asChild size="sm" variant="outline"><Link to="/admin/tournaments/$id/results" params={{ id: t.id }}><Award className="mr-1 h-3 w-3" /> Control</Link></Button>
                  <Button size="sm" variant="ghost" onClick={() => remove(t.id)}><Trash2 className="h-3 w-3 text-destructive" /></Button>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}

function DatePickerField({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const date = value ? new Date(value + "T00:00:00") : undefined;
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button type="button" variant="outline" className={cn("w-full justify-start text-left font-normal", !value && "text-muted-foreground")}>
          <CalendarIcon className="mr-2 h-4 w-4" />
          {value || "Pick a date"}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <Calendar
          mode="single"
          selected={date}
          onSelect={(d) => {
            if (!d) return;
            const y = d.getFullYear();
            const m = String(d.getMonth() + 1).padStart(2, "0");
            const day = String(d.getDate()).padStart(2, "0");
            onChange(`${y}-${m}-${day}`);
          }}
          initialFocus
          className={cn("p-3 pointer-events-auto")}
        />
      </PopoverContent>
    </Popover>
  );
}

function Section({ icon, title }: { icon: React.ReactNode; title: string }) {
  return <div className="flex items-center gap-2 border-b border-border pb-2 font-display text-sm font-bold uppercase tracking-widest text-primary">{icon}{title}</div>;
}
function Field({ label, children, span }: { label: string; children: React.ReactNode; span?: boolean }) {
  return <div className={`space-y-1.5 ${span ? "sm:col-span-2" : ""}`}><Label className="font-display text-xs font-bold uppercase tracking-widest">{label}</Label>{children}</div>;
}
