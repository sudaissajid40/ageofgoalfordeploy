import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Award, ChevronLeft, Sparkles, CalendarDays, Check, Trash2, Trophy, Wand2, Save, X, ListChecks, Crown,
} from "lucide-react";
import { toast } from "sonner";
import type { Database } from "@/integrations/supabase/types";

type Tournament = Database["public"]["Tables"]["tournaments"]["Row"];
type Reg = Database["public"]["Tables"]["tournament_registrations"]["Row"];
type Match = Database["public"]["Tables"]["tournament_matches"]["Row"];
type Proposal = Database["public"]["Tables"]["tournament_schedule_proposals"]["Row"];

interface RegRow extends Reg { name: string }
interface MatchRow extends Match { team_a_name: string | null; team_b_name: string | null }

export const Route = createFileRoute("/_authenticated/_admin/admin/tournaments_/$id/results")({
  component: ControlPage,
});

function toLocalInput(iso: string | null | undefined) {
  if (!iso) return "";
  const d = new Date(iso);
  const tz = d.getTimezoneOffset() * 60000;
  return new Date(d.getTime() - tz).toISOString().slice(0, 16);
}

function ControlPage() {
  const { id } = Route.useParams();
  const { session } = useAuth();
  const [t, setT] = useState<Tournament | null>(null);
  const [regs, setRegs] = useState<RegRow[]>([]);
  const [matches, setMatches] = useState<MatchRow[]>([]);
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [teams, setTeams] = useState<{ id: string; name: string }[]>([]);
  const [placements, setPlacements] = useState<Record<string, string>>({});
  const [edits, setEdits] = useState<Record<string, Partial<MatchRow>>>({});
  const [saving, setSaving] = useState(false);
  const [showWizard, setShowWizard] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [previewId, setPreviewId] = useState<string | null>(null);

  const wizardDefaults = useMemo(() => {
    const base = t?.registration_ends_at ? new Date(t.registration_ends_at) : new Date();
    base.setDate(base.getDate() + 1);
    return { startDate: base.toISOString().slice(0, 10) };
  }, [t?.registration_ends_at]);

  const [wizard, setWizard] = useState({ days: "3", perDay: "3", startTime: "18:00", slot: "90", startDate: "" });
  useEffect(() => { if (!wizard.startDate && wizardDefaults.startDate) setWizard((w) => ({ ...w, startDate: wizardDefaults.startDate })); }, [wizardDefaults.startDate, wizard.startDate]);

  const load = async () => {
    const [{ data: tour }, { data: r }, { data: props }, { data: m }] = await Promise.all([
      supabase.from("tournaments").select("*").eq("id", id).maybeSingle(),
      supabase.from("tournament_registrations").select("*").eq("tournament_id", id),
      supabase.from("tournament_schedule_proposals").select("*").eq("tournament_id", id).order("created_at", { ascending: false }),
      supabase.from("tournament_matches").select("id, tournament_id, round, match_number, team_a_id, team_b_id, scheduled_at, status, winner_team_id, spectator_link, created_at, updated_at").eq("tournament_id", id).order("scheduled_at", { ascending: true }),
    ]);
    setT(tour);
    setProposals(props ?? []);

    const userIds = (r ?? []).filter((x) => x.participant_type === "user").map((x) => x.participant_id);
    const teamIds = (r ?? []).filter((x) => x.participant_type === "team").map((x) => x.participant_id);
    const [{ data: profs }, { data: teamRows }] = await Promise.all([
      userIds.length ? supabase.from("profiles").select("id, username").in("id", userIds) : Promise.resolve({ data: [] as { id: string; username: string | null }[] }),
      teamIds.length ? supabase.from("teams").select("id, name").in("id", teamIds) : Promise.resolve({ data: [] as { id: string; name: string }[] }),
    ]);
    setTeams(teamRows ?? []);
    const nameMap = new Map<string, string>();
    profs?.forEach((p) => nameMap.set(p.id, p.username ?? "Player"));
    teamRows?.forEach((tt) => nameMap.set(tt.id, tt.name));

    const rows = (r ?? []).map((x) => ({ ...x, name: nameMap.get(x.participant_id) ?? "—" }));
    setRegs(rows);
    setPlacements(Object.fromEntries(rows.map((x) => [x.id, x.placement?.toString() ?? ""])));

    const teamMap = new Map<string, string>((teamRows ?? []).map((x) => [x.id, x.name]));
    const baseRows = (m ?? []).map((row) => ({
      ...row,
      room_id: null as string | null,
      room_password: null as string | null,
      team_a_name: row.team_a_id ? teamMap.get(row.team_a_id) ?? null : null,
      team_b_name: row.team_b_id ? teamMap.get(row.team_b_id) ?? null : null,
    }));
    // Admins fetch room credentials via authorized RPC (column-level SELECT is revoked from authenticated)
    await Promise.all(baseRows.map(async (row) => {
      const { data: room } = await supabase.rpc("get_match_room", { _match_id: row.id });
      const first = Array.isArray(room) ? room[0] : null;
      if (first) {
        row.room_id = (first as { room_id: string | null }).room_id ?? null;
        row.room_password = (first as { room_password: string | null }).room_password ?? null;
      }
    }));
    setMatches(baseRows);
    setEdits({});
  };

  useEffect(() => { void load(); }, [id]);

  // ---------- Schedule wizard ----------
  const generate = async (e: FormEvent) => {
    e.preventDefault();
    if (!session) return;
    setGenerating(true);
    try {
      const resp = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-schedule`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session.access_token}` },
        body: JSON.stringify({
          tournament_id: id,
          days: parseInt(wizard.days, 10),
          matches_per_day: parseInt(wizard.perDay, 10),
          start_time: wizard.startTime,
          slot_minutes: parseInt(wizard.slot, 10),
          start_date: wizard.startDate || undefined,
        }),
      });
      const data = await resp.json();
      if (!resp.ok) {
        toast.error(data.error || "AI failed to generate schedules");
        return;
      }
      toast.success(`${data.proposals?.length ?? 0} schedules generated`);
      setShowWizard(false);
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Network error");
    } finally {
      setGenerating(false);
    }
  };

  const useProposal = async (p: Proposal) => {
    if (!confirm(`Apply "${p.label}"? This replaces all existing matches.`)) return;
    const { error } = await supabase.rpc("replace_tournament_schedule", { _tournament_id: id, _proposal_id: p.id });
    if (error) return toast.error(error.message);
    toast.success("Schedule applied. You can now edit times and add room IDs.");
    await load();
  };

  // ---------- Match control ----------
  const setEdit = (mid: string, patch: Partial<MatchRow>) =>
    setEdits((e) => ({ ...e, [mid]: { ...(e[mid] ?? {}), ...patch } }));

  const saveMatch = async (m: MatchRow) => {
    const e = edits[m.id];
    if (!e) return;
    const update: Partial<Match> = {};
    if (e.scheduled_at !== undefined) update.scheduled_at = new Date(e.scheduled_at as unknown as string).toISOString();
    if (e.room_id !== undefined) update.room_id = (e.room_id as string) || null;
    if (e.room_password !== undefined) update.room_password = (e.room_password as string) || null;
    if (e.spectator_link !== undefined) update.spectator_link = (e.spectator_link as string) || null;
    if (e.team_a_id !== undefined) update.team_a_id = (e.team_a_id as string) || null;
    if (e.team_b_id !== undefined) update.team_b_id = (e.team_b_id as string) || null;
    if (Object.keys(update).length === 0) return;
    const { error } = await supabase.from("tournament_matches").update(update).eq("id", m.id);
    if (error) return toast.error(error.message);
    toast.success(`Match #${m.match_number} updated`);
    await load();
  };

  const pickWinner = async (m: MatchRow, winnerId: string) => {
    if (!winnerId) return;
    if (!confirm("Confirm winner? Points will be auto-awarded to that team's members.")) return;
    const { error } = await supabase.rpc("award_match_win", { _match_id: m.id, _winner_team_id: winnerId });
    if (error) return toast.error(error.message);
    toast.success("Winner recorded & points awarded");
    await load();
  };

  const deleteMatch = async (m: MatchRow) => {
    if (!confirm("Delete this match?")) return;
    const { error } = await supabase.from("tournament_matches").delete().eq("id", m.id);
    if (error) return toast.error(error.message);
    await load();
  };

  // ---------- Final placements ----------
  const savePlacements = async () => {
    setSaving(true);
    for (const r of regs) {
      const v = placements[r.id]?.trim();
      const placement = v ? parseInt(v, 10) : null;
      if (v && (!Number.isFinite(placement!) || placement! < 1)) {
        toast.error(`Invalid placement for ${r.name}`);
        setSaving(false); return;
      }
      await supabase.from("tournament_registrations").update({ placement }).eq("id", r.id);
    }
    const { error } = await supabase.rpc("award_tournament_points", { _tournament_id: id });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Results saved & points awarded!");
    void load();
  };

  if (!t) return <p className="text-sm text-muted-foreground">Loading…</p>;

  const payouts = (t.point_payouts ?? {}) as Record<string, number>;
  const teamOpts = teams; // teams registered

  return (
    <div className="space-y-5">
      <Link to="/admin/tournaments" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground">
        <ChevronLeft className="h-4 w-4" /> Back
      </Link>

      <div className="rounded-xl border border-primary/20 bg-card p-5 card-glow">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="text-xl font-bold gradient-text">{t.name} — Control</h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Reg ends {t.registration_ends_at ? new Date(t.registration_ends_at).toLocaleString() : "—"} · Starts {new Date(t.starts_at).toLocaleString()}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              Payouts: {Object.entries(payouts).sort((a, b) => +a[0] - +b[0]).map(([k, v]) => `#${k}=${v}`).join(", ") || "none"}
            </p>
          </div>
          <Button onClick={() => setShowWizard(true)} className="gradient-bg glow-primary">
            <Wand2 className="mr-1 h-4 w-4" /> Generate schedule
          </Button>
        </div>
      </div>

      {/* WIZARD */}
      {showWizard && (
        <form onSubmit={generate} className="space-y-3 rounded-xl border border-primary/30 bg-card p-5 card-glow">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-sm font-bold uppercase tracking-widest text-primary">
              <Sparkles className="mr-1 inline h-4 w-4" /> AI schedule generator
            </h3>
            <Button type="button" size="sm" variant="ghost" onClick={() => setShowWizard(false)}><X className="h-4 w-4" /></Button>
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            <Field label="Number of days"><Input type="number" min={1} max={14} value={wizard.days} onChange={(e) => setWizard({ ...wizard, days: e.target.value })} required /></Field>
            <Field label="Matches per day"><Input type="number" min={1} max={8} value={wizard.perDay} onChange={(e) => setWizard({ ...wizard, perDay: e.target.value })} required /></Field>
            <Field label="First match start (UTC)"><Input type="time" value={wizard.startTime} onChange={(e) => setWizard({ ...wizard, startTime: e.target.value })} required /></Field>
            <Field label="Slot length (minutes)"><Input type="number" min={15} max={240} step={15} value={wizard.slot} onChange={(e) => setWizard({ ...wizard, slot: e.target.value })} required /></Field>
            <Field label="First day (UTC)"><Input type="date" value={wizard.startDate} onChange={(e) => setWizard({ ...wizard, startDate: e.target.value })} required /></Field>
          </div>
          <p className="text-xs text-muted-foreground">AI will produce 3 different round-robin proposals. Pick one below to apply it.</p>
          <Button type="submit" disabled={generating} className="gradient-bg glow-primary">
            <Sparkles className="mr-1 h-4 w-4" /> {generating ? "Generating…" : "Generate 3 proposals"}
          </Button>
        </form>
      )}

      {/* PROPOSALS */}
      {proposals.length > 0 && (
        <div className="rounded-xl border border-border bg-card p-5">
          <h3 className="font-display text-sm font-bold uppercase tracking-widest text-primary">
            <ListChecks className="mr-1 inline h-4 w-4" /> Proposals ({proposals.length})
          </h3>
          <div className="mt-3 grid gap-3 md:grid-cols-3">
            {proposals.map((p) => {
              const list = (p.matches as Array<{ round: string; match_number: number; team_a_id: string | null; team_b_id: string | null; scheduled_at: string }>) ?? [];
              const counts = list.reduce<Record<string, number>>((acc, x) => { acc[x.round] = (acc[x.round] ?? 0) + 1; return acc; }, {});
              const isSelected = t.selected_schedule_id === p.id;
              const teamMap = new Map(teams.map((tt) => [tt.id, tt.name]));
              return (
                <article key={p.id} className={`rounded-lg border p-3 ${isSelected ? "border-success/50 bg-success/5" : "border-border"}`}>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="font-display font-bold">{p.label}</div>
                      <div className="text-xs text-muted-foreground">{p.description}</div>
                    </div>
                    {isSelected && <span className="rounded bg-success/10 px-1.5 py-0.5 text-[10px] uppercase text-success"><Check className="inline h-3 w-3" /> Active</span>}
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground">
                    {list.length} matches · {Object.entries(counts).map(([k, v]) => `${v} ${k}`).join(" · ")}
                  </div>
                  <div className="mt-3 flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => setPreviewId(previewId === p.id ? null : p.id)}>
                      {previewId === p.id ? "Hide" : "Preview"}
                    </Button>
                    {!isSelected && (
                      <Button size="sm" className="gradient-bg" onClick={() => useProposal(p)}>
                        <Check className="mr-1 h-3 w-3" /> Use this
                      </Button>
                    )}
                  </div>
                  {previewId === p.id && (
                    <ul className="mt-3 max-h-64 space-y-1 overflow-y-auto rounded border border-border bg-background p-2 text-xs">
                      {list.map((m, i) => (
                        <li key={i} className="flex items-center justify-between gap-2">
                          <span><span className="text-muted-foreground">#{m.match_number} {m.round}</span> {teamMap.get(m.team_a_id ?? "") ?? "TBD"} vs {teamMap.get(m.team_b_id ?? "") ?? "TBD"}</span>
                          <span className="text-muted-foreground">{new Date(m.scheduled_at).toLocaleString()}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </article>
              );
            })}
          </div>
        </div>
      )}

      {/* MATCH CONTROL */}
      <div className="rounded-xl border border-border bg-card p-5">
        <div className="flex items-center justify-between">
          <h3 className="font-display text-sm font-bold uppercase tracking-widest text-primary">
            <CalendarDays className="mr-1 inline h-4 w-4" /> Match control ({matches.length})
          </h3>
          <p className="text-xs text-muted-foreground">Add room ID 5–30 min before kickoff. Players see it 1 min before start.</p>
        </div>
        {matches.length === 0 ? (
          <p className="mt-3 text-sm text-muted-foreground">No matches yet. Generate a schedule above and apply one of the proposals.</p>
        ) : (
          <ul className="mt-3 space-y-3">
            {matches.map((m) => {
              const e = edits[m.id] ?? {};
              const dirty = Object.keys(e).length > 0;
              const localTime = e.scheduled_at !== undefined ? (e.scheduled_at as unknown as string) : toLocalInput(m.scheduled_at);
              const winner = m.winner_team_id;
              return (
                <li key={m.id} className={`rounded-lg border p-3 ${winner ? "border-success/40 bg-success/5" : "border-border"}`}>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="text-[10px] uppercase text-muted-foreground">{m.round} · Match #{m.match_number} · <span className={m.status === "completed" ? "text-success" : ""}>{m.status}</span></div>
                      <div className="font-display font-bold">{m.team_a_name ?? "TBD"} <span className="text-muted-foreground">vs</span> {m.team_b_name ?? "TBD"}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      {dirty && <Button size="sm" onClick={() => saveMatch(m)}><Save className="mr-1 h-3 w-3" /> Save</Button>}
                      <Button size="sm" variant="ghost" onClick={() => deleteMatch(m)}><Trash2 className="h-3 w-3 text-destructive" /></Button>
                    </div>
                  </div>

                  <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
                    <Field label="Scheduled at">
                      <Input type="datetime-local" value={localTime}
                        onChange={(ev) => setEdit(m.id, { scheduled_at: ev.target.value as unknown as Match["scheduled_at"] })} />
                    </Field>
                    <Field label="Room ID">
                      <Input value={e.room_id !== undefined ? (e.room_id as string) : (m.room_id ?? "")}
                        onChange={(ev) => setEdit(m.id, { room_id: ev.target.value })} placeholder="e.g. 824193" />
                    </Field>
                    <Field label="Room password">
                      <Input value={e.room_password !== undefined ? (e.room_password as string) : (m.room_password ?? "")}
                        onChange={(ev) => setEdit(m.id, { room_password: ev.target.value })} placeholder="optional" />
                    </Field>
                    <Field label="Spectator link">
                      <Input value={e.spectator_link !== undefined ? (e.spectator_link as string) : (m.spectator_link ?? "")}
                        onChange={(ev) => setEdit(m.id, { spectator_link: ev.target.value })} placeholder="https://…" />
                    </Field>
                  </div>

                  {/* TBD assignment for semis/finals */}
                  {(!m.team_a_id || !m.team_b_id) && (
                    <div className="mt-2 grid gap-2 sm:grid-cols-2">
                      {!m.team_a_id && (
                        <Field label="Assign Team A">
                          <select className="h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
                            value={(e.team_a_id as string) ?? ""}
                            onChange={(ev) => setEdit(m.id, { team_a_id: ev.target.value })}>
                            <option value="">— pick team —</option>
                            {teamOpts.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
                          </select>
                        </Field>
                      )}
                      {!m.team_b_id && (
                        <Field label="Assign Team B">
                          <select className="h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
                            value={(e.team_b_id as string) ?? ""}
                            onChange={(ev) => setEdit(m.id, { team_b_id: ev.target.value })}>
                            <option value="">— pick team —</option>
                            {teamOpts.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
                          </select>
                        </Field>
                      )}
                    </div>
                  )}

                  {/* Winner picker */}
                  {m.team_a_id && m.team_b_id && (
                    <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-border pt-3">
                      <span className="text-xs text-muted-foreground">Pick winner:</span>
                      <Button size="sm" variant={winner === m.team_a_id ? "default" : "outline"}
                        className={winner === m.team_a_id ? "gradient-bg" : ""}
                        onClick={() => pickWinner(m, m.team_a_id!)}>
                        <Trophy className="mr-1 h-3 w-3" /> {m.team_a_name}
                      </Button>
                      <Button size="sm" variant={winner === m.team_b_id ? "default" : "outline"}
                        className={winner === m.team_b_id ? "gradient-bg" : ""}
                        onClick={() => pickWinner(m, m.team_b_id!)}>
                        <Trophy className="mr-1 h-3 w-3" /> {m.team_b_name}
                      </Button>
                      {winner && <span className="text-xs text-success">+{t.points_per_match_win} pts awarded</span>}
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </div>

      {/* KNOCKOUT BRACKET SEEDER */}
      <BracketSeeder tournamentId={id} initialSize={t.bracket_size ?? 4} onChange={() => void load()} />
      <div className="rounded-xl border border-border bg-card p-5">
        <h3 className="font-display text-sm font-bold uppercase tracking-widest text-primary">Final placements & payouts</h3>
        {regs.length === 0 ? (
          <p className="mt-2 text-sm text-muted-foreground">No registrations.</p>
        ) : (
          <>
            <ul className="mt-3 space-y-2">
              {regs.map((r) => (
                <li key={r.id} className="flex items-center justify-between gap-3 rounded-lg border border-border p-3">
                  <div>
                    <div className="font-medium">{r.name}</div>
                    <div className="text-xs text-muted-foreground capitalize">{r.participant_type}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Input type="number" min={1} placeholder="—" value={placements[r.id] ?? ""}
                      onChange={(ev) => setPlacements((p) => ({ ...p, [r.id]: ev.target.value }))} className="w-20" />
                    {r.points_awarded != null && <span className="text-xs text-primary">+{r.points_awarded}</span>}
                  </div>
                </li>
              ))}
            </ul>
            <Button onClick={savePlacements} disabled={saving} className="mt-4 gradient-bg glow-primary">
              <Award className="mr-2 h-4 w-4" /> {saving ? "Saving..." : "Save placements & award payouts"}
            </Button>
            <p className="mt-2 text-xs text-muted-foreground">
              Saving will reset previously awarded placement points and recalculate. Tournament will be marked completed.
            </p>
          </>
        )}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <Label className="font-display text-[10px] font-bold uppercase tracking-widest text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

function BracketSeeder({ tournamentId, initialSize, onChange }: { tournamentId: string; initialSize: number; onChange: () => void }) {
  const [size, setSize] = useState(String(initialSize));
  const [busy, setBusy] = useState(false);

  const seed = async () => {
    if (!confirm(`Auto-seed bracket of ${size}? This replaces existing knockout matches.`)) return;
    setBusy(true);
    const { error: upErr } = await supabase.from("tournaments").update({ bracket_size: parseInt(size, 10) }).eq("id", tournamentId);
    if (upErr) { setBusy(false); return toast.error(upErr.message); }
    const { error } = await supabase.rpc("seed_knockout_bracket", { _tournament_id: tournamentId });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Bracket seeded by win rate. Edit teams/times below.");
    onChange();
  };

  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <h3 className="font-display text-sm font-bold uppercase tracking-widest text-primary">
        <Crown className="mr-1 inline h-4 w-4" /> Knockout bracket
      </h3>
      <p className="mt-1 text-xs text-muted-foreground">Auto-picks top teams by win rate from group stage. Admin can drag/swap teams in the match list above after seeding.</p>
      <div className="mt-3 flex flex-wrap items-end gap-3">
        <Field label="Bracket size">
          <select className="h-10 w-32 rounded-md border border-input bg-background px-3 text-sm" value={size} onChange={(e) => setSize(e.target.value)}>
            <option value="2">Final (2)</option>
            <option value="4">Semis (4)</option>
            <option value="8">Quarters (8)</option>
          </select>
        </Field>
        <Button onClick={seed} disabled={busy} className="gradient-bg">
          <Wand2 className="mr-1 h-4 w-4" /> {busy ? "Seeding…" : "Auto-seed bracket"}
        </Button>
      </div>
    </div>
  );
}
