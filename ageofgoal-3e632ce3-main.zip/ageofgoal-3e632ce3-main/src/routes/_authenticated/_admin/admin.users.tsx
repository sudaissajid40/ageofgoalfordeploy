import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Shield, ShieldOff, Check, X } from "lucide-react";
import { toast } from "sonner";
import { StatusBadge } from "@/components/StatusBadge";
import type { Database } from "@/integrations/supabase/types";
import { REGION_LABEL, type Region } from "@/lib/region";

type Profile = Database["public"]["Tables"]["profiles"]["Row"];

export const Route = createFileRoute("/_authenticated/_admin/admin/users")({
  component: UsersPage,
});

function UsersPage() {
  const [users, setUsers] = useState<Profile[]>([]);
  const [adminIds, setAdminIds] = useState<Set<string>>(new Set());

  const load = async () => {
    const [{ data: u }, { data: r }] = await Promise.all([
      supabase.from("profiles").select("*").order("created_at", { ascending: false }),
      supabase.from("user_roles").select("user_id, role").eq("role", "admin"),
    ]);
    setUsers(u ?? []);
    setAdminIds(new Set((r ?? []).map((x) => x.user_id)));
  };

  useEffect(() => { void load(); }, []);

  const toggleAdmin = async (uid: string, makeAdmin: boolean) => {
    const op = makeAdmin
      ? supabase.from("user_roles").insert({ user_id: uid, role: "admin" })
      : supabase.from("user_roles").delete().eq("user_id", uid).eq("role", "admin");
    const { error } = await op;
    if (error) return toast.error(error.message);
    toast.success(makeAdmin ? "Promoted to admin" : "Admin removed");
    void load();
  };

  const verify = async (uid: string) => {
    const { error } = await supabase
      .from("profiles")
      .update({ verification_status: "approved", rejection_reason: null })
      .eq("id", uid);
    if (error) return toast.error(error.message);
    toast.success("Verified");
    void load();
  };

  const reject = async (uid: string) => {
    const reason = prompt("Rejection reason?") || "Did not meet criteria";
    const { error } = await supabase
      .from("profiles")
      .update({ verification_status: "rejected", rejection_reason: reason })
      .eq("id", uid);
    if (error) return toast.error(error.message);
    toast.success("Rejected");
    void load();
  };

  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <h2 className="font-semibold">All users ({users.length})</h2>
      <ul className="mt-3 space-y-2">
        {users.map((u) => {
          const isAdmin = adminIds.has(u.id);
          return (
            <li key={u.id} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border p-3">
              <Link to="/admin/users/$userId" params={{ userId: u.id }} className="flex min-w-0 flex-1 items-center gap-3 hover:text-primary">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 font-bold">
                  {u.username?.[0]?.toUpperCase() ?? "?"}
                </div>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2 font-medium">
                    {u.username ?? <span className="italic text-muted-foreground">No profile</span>}
                    {isAdmin && <span className="rounded bg-primary/15 px-1.5 py-0.5 text-[10px] font-bold text-primary">ADMIN</span>}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Lv {u.level ?? "-"} · {u.city ?? "-"} · {u.region ? REGION_LABEL[u.region as Region] : "-"} · {u.aog_points} pts
                  </div>
                </div>
              </Link>
              <div className="flex flex-wrap items-center gap-2">
                <StatusBadge status={u.verification_status} />
                {u.verification_status !== "approved" && u.profile_completed && (
                  <Button size="sm" variant="outline" onClick={() => verify(u.id)} className="text-success">
                    <Check className="h-3 w-3" />
                  </Button>
                )}
                {u.verification_status !== "rejected" && u.profile_completed && (
                  <Button size="sm" variant="outline" onClick={() => reject(u.id)} className="text-destructive">
                    <X className="h-3 w-3" />
                  </Button>
                )}
                <Button size="sm" variant="outline" onClick={() => toggleAdmin(u.id, !isAdmin)}>
                  {isAdmin ? <><ShieldOff className="mr-1 h-3 w-3" /> Demote</> : <><Shield className="mr-1 h-3 w-3" /> Promote</>}
                </Button>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
