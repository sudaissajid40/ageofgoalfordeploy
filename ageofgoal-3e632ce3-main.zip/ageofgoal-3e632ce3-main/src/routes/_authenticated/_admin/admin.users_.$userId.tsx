import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, Mail, Trophy, Users, Crown } from "lucide-react";
import { StatusBadge } from "@/components/StatusBadge";
import { RankBadge } from "@/components/RankBadge";
import { UserAvatar } from "@/components/UserAvatar";
import { REGION_LABEL, type Region } from "@/lib/region";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import type { Database } from "@/integrations/supabase/types";

type Profile = Database["public"]["Tables"]["profiles"]["Row"];
type Tournament = Database["public"]["Tables"]["tournaments"]["Row"];
type Team = Database["public"]["Tables"]["teams"]["Row"];

interface RegRow { id: string; placement: number | null; points_awarded: number | null; tournaments: Pick<Tournament, "id" | "name" | "type" | "starts_at"> | null }

export const Route = createFileRoute("/_authenticated/_admin/admin/users_/$userId")({ component: AdminUserDetail });

function AdminUserDetail() {
  const { userId } = Route.useParams();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [email, setEmail] = useState<string>("—");
  const [team, setTeam] = useState<Team | null>(null);
  const [regs, setRegs] = useState<RegRow[]>([]);
  const [adminFlag, setAdminFlag] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: prof }, { data: emailRow }, { data: tm }, { data: reg }, { data: roles }] = await Promise.all([
      supabase.from("profiles").select("*").eq("id", userId).maybeSingle(),
      supabase.rpc("get_user_email", { _user_id: userId }),
      supabase.from("team_members").select("teams(id, name, team_level, owner_id, aog_points, region, join_code, created_at)").eq("user_id", userId).maybeSingle(),
      supabase.from("tournament_registrations").select("id, placement, points_awarded, tournaments(id, name, type, starts_at)").eq("registered_by", userId).order("created_at", { ascending: false }),
      supabase.from("user_roles").select("role").eq("user_id", userId).eq("role", "admin"),
    ]);
    setProfile(prof ?? null);
    setEmail((emailRow as unknown as string) ?? "—");
    setTeam(((tm as { teams: Team | null } | null)?.teams) ?? null);
    setRegs((reg as RegRow[]) ?? []);
    setAdminFlag((roles ?? []).length > 0);
    setLoading(false);
  }, [userId]);

  useEffect(() => { void load(); }, [load]);

  const verify = async (status: "approved" | "rejected") => {
    const reason = status === "rejected" ? prompt("Rejection reason?") || "Did not meet criteria" : null;
    const { error } = await supabase.from("profiles").update({ verification_status: status, rejection_reason: reason }).eq("id", userId);
    if (error) return toast.error(error.message);
    toast.success(status === "approved" ? "Verified" : "Rejected");
    void load();
  };

  if (loading) return <p className="text-sm text-muted-foreground">Loading user…</p>;
  if (!profile) return <p className="text-sm text-muted-foreground">User not found.</p>;

  const uid = profile.id.replace(/-/g, "").slice(0, 9);

  return (
    <div className="space-y-6">
      <Link to="/admin/users" className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-primary">
        <ArrowLeft className="h-3 w-3" /> Back to users
      </Link>

      <div className="rounded-xl border border-primary/30 bg-card p-6 card-glow">
        <div className="flex flex-wrap items-start gap-5">
          <UserAvatar username={profile.username} gender={profile.gender} size="xl" />
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="font-display text-3xl font-black uppercase gradient-text">{profile.username ?? "—"}</h1>
              {adminFlag && <span className="rounded bg-primary/15 px-2 py-0.5 text-[10px] font-bold text-primary">ADMIN</span>}
            </div>
            <div className="mt-1 flex flex-wrap items-center gap-3 font-mono text-sm">
              <span><span className="text-muted-foreground">UID:</span> <span className="font-bold text-primary">{uid}</span></span>
              <span className="flex items-center gap-1"><Mail className="h-3 w-3" /> {email}</span>
            </div>
            <div className="mt-3"><StatusBadge status={profile.verification_status} /></div>
          </div>
          <div className="flex flex-col items-end gap-2">
            <RankBadge points={profile.aog_points} />
            <div className="flex gap-2">
              {profile.verification_status !== "approved" && (
                <Button size="sm" className="gradient-bg" onClick={() => verify("approved")}>Approve</Button>
              )}
              {profile.verification_status !== "rejected" && (
                <Button size="sm" variant="destructive" onClick={() => verify("rejected")}>Reject</Button>
              )}
            </div>
          </div>
        </div>

        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <DataCell label="AOG Points" value={profile.aog_points.toString()} />
          <DataCell label="Player Level" value={profile.level?.toString() ?? "—"} />
          <DataCell label="Age" value={profile.age?.toString() ?? "—"} />
          <DataCell label="Gender" value={profile.gender ?? "—"} />
          <DataCell label="City" value={profile.city ?? "—"} />
          <DataCell label="Region" value={profile.region ? REGION_LABEL[profile.region as Region] : "—"} />
          <DataCell label="FF UID" value={profile.ff_uid ?? "—"} />
          <DataCell label="Onboarding" value={profile.profile_completed ? "Complete" : `Step ${profile.onboarding_step}`} />
          <DataCell label="Play Style" value={profile.play_style ?? "—"} />
          <DataCell label="Preferred Mode" value={profile.preferred_mode ?? "—"} />
          <DataCell label="Joined" value={new Date(profile.created_at).toLocaleDateString()} />
          <DataCell label="Updated" value={new Date(profile.updated_at).toLocaleDateString()} />
        </div>

        {profile.profile_note && (
          <div className="mt-4 rounded-lg border border-border bg-background/50 p-4">
            <div className="font-display text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Profile Note</div>
            <p className="mt-1 text-sm">{profile.profile_note}</p>
          </div>
        )}
        {profile.rejection_reason && (
          <div className="mt-4 rounded-lg border border-destructive/30 bg-destructive/10 p-4">
            <div className="font-display text-[10px] font-bold uppercase tracking-widest text-destructive">Rejection Reason</div>
            <p className="mt-1 text-sm">{profile.rejection_reason}</p>
          </div>
        )}
      </div>

      {/* Team */}
      <div className="rounded-xl border border-border bg-card p-5">
        <h2 className="flex items-center gap-2 font-display font-bold uppercase">
          <Users className="h-4 w-4 text-primary" /> Team
        </h2>
        {team ? (
          <Link to="/teams/$teamId" params={{ teamId: team.id }} className="mt-3 flex items-center justify-between rounded-lg border border-primary/20 bg-primary/5 p-4 hover:border-primary/40">
            <div>
              <div className="flex items-center gap-2 font-display font-bold uppercase">
                {team.name}
                {team.owner_id === userId && <Crown className="h-3.5 w-3.5 text-warning" />}
              </div>
              <div className="mt-1 font-mono text-xs text-muted-foreground">
                Lv {team.team_level} · {team.aog_points} pts · {team.region ? REGION_LABEL[team.region as Region] : "no region"}
              </div>
            </div>
            <span className="text-xs text-primary">View →</span>
          </Link>
        ) : (
          <p className="mt-2 text-sm text-muted-foreground">Not in a team.</p>
        )}
      </div>

      {/* Tournaments */}
      <div className="rounded-xl border border-border bg-card p-5">
        <h2 className="flex items-center gap-2 font-display font-bold uppercase">
          <Trophy className="h-4 w-4 text-primary" /> Tournament History ({regs.length})
        </h2>
        {regs.length === 0 ? (
          <p className="mt-2 text-sm text-muted-foreground">No tournament history.</p>
        ) : (
          <ul className="mt-3 space-y-2">
            {regs.map((r) => (
              <li key={r.id} className="flex items-center justify-between rounded-lg border border-border p-3">
                <div>
                  <div className="font-display font-bold">{r.tournaments?.name ?? "—"}</div>
                  <div className="font-mono text-[10px] uppercase text-muted-foreground">
                    {r.tournaments?.type} · {r.tournaments?.starts_at ? new Date(r.tournaments.starts_at).toLocaleDateString() : "—"}
                  </div>
                </div>
                <div className="text-right">
                  {r.placement ? (
                    <>
                      <div className="font-display text-sm font-bold text-primary">#{r.placement}</div>
                      <div className="font-mono text-xs text-primary">+{r.points_awarded ?? 0} pts</div>
                    </>
                  ) : (
                    <span className="font-mono text-xs uppercase text-muted-foreground">Pending</span>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function DataCell({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-border/50 bg-background/30 p-3">
      <div className="font-display text-[10px] font-bold uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className="mt-0.5 truncate text-sm font-medium text-foreground">{value}</div>
    </div>
  );
}
