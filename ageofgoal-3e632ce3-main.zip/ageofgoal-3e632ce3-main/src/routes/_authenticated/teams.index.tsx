import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Users, Plus, Search, Send } from "lucide-react";
import { toast } from "sonner";
import { REGION_LABEL, type Region } from "@/lib/region";

export const Route = createFileRoute("/_authenticated/teams/")({ component: TeamsList });

interface TeamRow { id: string; name: string; team_level: number; owner_id: string; aog_points: number; region: Region | null; member_count?: number; city?: string | null }

function TeamsList() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [teams, setTeams] = useState<TeamRow[]>([]);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [pendingTeamIds, setPendingTeamIds] = useState<Set<string>>(new Set());
  const [myTeamId, setMyTeamId] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    const [{ data }, { data: pending }, { data: mine }] = await Promise.all([
      supabase.from("teams").select("id, name, team_level, owner_id, aog_points, region, team_members(count)").order("team_level", { ascending: false }).limit(100),
      user ? supabase.from("team_join_requests").select("team_id").eq("user_id", user.id).eq("status", "pending") : Promise.resolve({ data: [] }),
      user ? supabase.from("team_members").select("team_id").eq("user_id", user.id).maybeSingle() : Promise.resolve({ data: null }),
    ]);
    setTeams((data ?? []).map((t: any) => ({ id: t.id, name: t.name, team_level: t.team_level, owner_id: t.owner_id, aog_points: t.aog_points, region: t.region, member_count: t.team_members?.[0]?.count ?? 0 })));
    setPendingTeamIds(new Set((pending ?? []).map((p) => p.team_id)));
    setMyTeamId((mine as { team_id: string } | null)?.team_id ?? null);
    setLoading(false);
  };

  useEffect(() => { void load(); }, [user?.id]);

  const filtered = teams.filter((t) => !query.trim() || t.name.toLowerCase().includes(query.toLowerCase()) || REGION_LABEL[t.region as Region]?.toLowerCase().includes(query.toLowerCase()));

  const requestJoin = async (teamId: string) => {
    if (!user) return;
    const { error } = await supabase.from("team_join_requests").insert({ team_id: teamId, user_id: user.id });
    if (error) return toast.error(error.message);
    toast.success("Request sent to team owner");
    setPendingTeamIds((prev) => new Set(prev).add(teamId));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-black uppercase">Team <span className="gradient-text">Hub</span></h1>
          <p className="text-sm text-muted-foreground">Browse teams, request access, or create your squad.</p>
        </div>
        {!myTeamId && (
          <Button asChild className="gradient-bg glow-primary">
            <Link to="/teams/create"><Plus className="mr-1 h-4 w-4" /> Create team</Link>
          </Button>
        )}
      </div>
      {myTeamId && (
        <Link
          to="/teams/$teamId"
          params={{ teamId: myTeamId }}
          className="block rounded-xl border border-primary/40 bg-gradient-to-r from-primary/15 via-primary/10 to-transparent p-4 card-glow transition hover:border-primary/70 active:scale-[0.99]"
        >
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-md bg-primary/20">
                <Users className="h-5 w-5 text-primary" />
              </div>
              <div>
                <div className="font-display text-sm font-bold uppercase tracking-wide text-primary">Tap to open your team</div>
                <div className="text-xs text-muted-foreground">Jump straight into your squad lobby and roster.</div>
              </div>
            </div>
            <span className="rounded-md bg-primary px-3 py-1.5 text-xs font-bold uppercase text-primary-foreground">Open →</span>
          </div>
        </Link>
      )}
      <div className="relative rounded-xl border border-border bg-card p-3"><Search className="absolute left-6 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search teams by name or region…" className="pl-9" /></div>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {loading ? <p className="text-sm text-muted-foreground">Loading…</p> : filtered.length === 0 ? <p className="text-sm text-muted-foreground">No matching teams.</p> : filtered.map((t) => <div key={t.id} className="rounded-xl border border-border bg-card p-4 card-glow"><Link to="/teams/$teamId" params={{ teamId: t.id }} className="block"><div className="flex items-center justify-between"><div className="flex items-center gap-3"><div className="flex h-11 w-11 items-center justify-center rounded-md bg-primary/10"><Users className="h-5 w-5 text-primary" /></div><div><div className="font-display font-bold uppercase">{t.name}</div><div className="text-xs text-muted-foreground">{t.member_count}/6 players · {t.region ? REGION_LABEL[t.region] : "No region"}</div></div></div><div className="text-right"><div className="font-mono text-lg font-bold gradient-text">{t.team_level}</div><div className="text-[10px] uppercase text-muted-foreground">level</div></div></div></Link><div className="mt-4 flex gap-2"><Button size="sm" variant="outline" onClick={() => navigate({ to: "/teams/$teamId", params: { teamId: t.id } })}>Details</Button>{!myTeamId && user?.id !== t.owner_id && <Button size="sm" onClick={() => requestJoin(t.id)} disabled={pendingTeamIds.has(t.id) || (t.member_count ?? 0) >= 6} className="gradient-bg"><Send className="mr-1 h-3 w-3" /> {pendingTeamIds.has(t.id) ? "Pending" : "Request"}</Button>}</div></div>)}
      </div>
    </div>
  );
}
