import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Users } from "lucide-react";

export const Route = createFileRoute("/_authenticated/teams/create")({
  component: CreateTeam,
});

const schema = z.object({
  name: z.string().trim().min(3).max(30),
});

function generateJoinCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 6; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

function CreateTeam() {
  const { user, myTeamId, refreshTeam } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [checking, setChecking] = useState(true);
  const [existingTeamId, setExistingTeamId] = useState<string | null>(null);

  // Authoritative check on mount: bypass any stale auth-context state.
  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("team_members")
        .select("team_id")
        .eq("user_id", user.id)
        .maybeSingle();
      if (cancelled) return;
      const tid = (data as { team_id: string } | null)?.team_id ?? null;
      setExistingTeamId(tid);
      setChecking(false);
      if (tid) {
        // Sync auth context so sidebar / other pages reflect reality.
        void refreshTeam();
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) return;
    const parsed = schema.safeParse({ name });
    if (!parsed.success) return toast.error(parsed.error.issues[0].message);

    // Re-check right before insert to avoid stale state.
    const { data: existing } = await supabase
      .from("team_members")
      .select("team_id")
      .eq("user_id", user.id)
      .maybeSingle();
    if (existing) {
      const tid = (existing as { team_id: string }).team_id;
      setExistingTeamId(tid);
      void refreshTeam();
      toast.error("You're already on a team. Opening it now…");
      navigate({ to: "/teams/$teamId", params: { teamId: tid } });
      return;
    }

    setSubmitting(true);
    const { data, error } = await supabase
      .from("teams")
      .insert({ name: parsed.data.name, owner_id: user.id, join_code: generateJoinCode() })
      .select()
      .single();
    setSubmitting(false);
    if (error) return toast.error(error.message);
    toast.success("Team created!");
    void refreshTeam();
    navigate({ to: "/teams/$teamId", params: { teamId: data.id } });
  };

  // Prefer authoritative DB result; fall back to context.
  const blockingTeamId = existingTeamId ?? myTeamId;

  if (checking) {
    return (
      <div className="mx-auto max-w-md">
        <p className="text-sm text-muted-foreground">Checking your team status…</p>
      </div>
    );
  }

  if (blockingTeamId) {
    return (
      <div className="mx-auto max-w-md">
        <h1 className="text-2xl font-bold">You're already on a team</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Each player can be on only one team. Open your team or leave it before creating a new one.
        </p>
        <div className="mt-6 rounded-xl border border-primary/40 bg-gradient-to-r from-primary/15 via-primary/10 to-transparent p-5 card-glow">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-md bg-primary/20">
              <Users className="h-5 w-5 text-primary" />
            </div>
            <div className="flex-1">
              <div className="font-display text-sm font-bold uppercase tracking-wide text-primary">Your team</div>
              <div className="text-xs text-muted-foreground">Tap below to open your squad lobby.</div>
            </div>
          </div>
          <div className="mt-4 flex gap-2">
            <Button asChild className="flex-1 gradient-bg glow-primary">
              <Link to="/teams/$teamId" params={{ teamId: blockingTeamId }}>Open my team</Link>
            </Button>
            <Button asChild variant="outline">
              <Link to="/teams">Browse</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-md">
      <h1 className="text-2xl font-bold">Create a team</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        You'll be team owner and the first member. Each player can be on only one team.
      </p>
      <form onSubmit={onSubmit} className="mt-6 space-y-4 rounded-xl border border-border bg-card p-5">
        <div className="space-y-2">
          <Label htmlFor="name">Team name</Label>
          <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Phoenix Squad" required />
        </div>
        <Button type="submit" className="w-full gradient-bg glow-primary" disabled={submitting}>
          {submitting ? "Creating..." : "Create team"}
        </Button>
      </form>
    </div>
  );
}
