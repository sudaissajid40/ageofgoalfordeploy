import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { CalendarDays, Search, Sword } from "lucide-react";
import { formatPKTDateTime } from "@/lib/time";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";

export const Route = createFileRoute("/_authenticated/schedule")({ component: SchedulePage });

interface Row {
  id: string;
  scheduled_at: string;
  status: string;
  round: string;
  match_number: number;
  tournament_id: string;
  tournament_name: string;
  team_a_id: string | null;
  team_b_id: string | null;
  team_a_name: string | null;
  team_b_name: string | null;
  member_usernames: string[];
}

function SchedulePage() {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [tournamentId, setTournamentId] = useState("");
  const [teamId, setTeamId] = useState("");
  const [status, setStatus] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    const { data: m } = await supabase
      .from("tournament_matches")
      .select("id, scheduled_at, status, round, match_number, tournament_id, team_a_id, team_b_id")
      .order("scheduled_at", { ascending: true });
    const matches = m ?? [];
    const tournamentIds = Array.from(new Set(matches.map((x) => x.tournament_id)));
    const teamIds = Array.from(new Set(matches.flatMap((x) => [x.team_a_id, x.team_b_id]).filter(Boolean) as string[]));
    const [{ data: tours }, { data: teams }, { data: members }] = await Promise.all([
      tournamentIds.length ? supabase.from("tournaments").select("id, name").in("id", tournamentIds) : Promise.resolve({ data: [] as any[] }),
      teamIds.length ? supabase.from("teams").select("id, name").in("id", teamIds) : Promise.resolve({ data: [] as any[] }),
      teamIds.length ? supabase.from("team_members").select("team_id, user_id").in("team_id", teamIds) : Promise.resolve({ data: [] as any[] }),
    ]);
    const userIds = Array.from(new Set((members ?? []).map((x: any) => x.user_id)));
    const { data: profs } = userIds.length
      ? await supabase.from("profiles").select("id, username").in("id", userIds)
      : { data: [] as any[] };
    const profMap = new Map((profs ?? []).map((p: any) => [p.id, p.username ?? "Player"]));
    const teamMembers = new Map<string, string[]>();
    (members ?? []).forEach((mm: any) => {
      const arr = teamMembers.get(mm.team_id) ?? [];
      arr.push(profMap.get(mm.user_id) ?? "Player");
      teamMembers.set(mm.team_id, arr);
    });
    const tourMap = new Map((tours ?? []).map((t: any) => [t.id, t.name]));
    const teamMap = new Map((teams ?? []).map((t: any) => [t.id, t.name]));
    setRows(matches.map((x) => {
      const aMembers = x.team_a_id ? teamMembers.get(x.team_a_id) ?? [] : [];
      const bMembers = x.team_b_id ? teamMembers.get(x.team_b_id) ?? [] : [];
      return {
        ...x,
        tournament_name: tourMap.get(x.tournament_id) ?? "—",
        team_a_name: x.team_a_id ? teamMap.get(x.team_a_id) ?? null : null,
        team_b_name: x.team_b_id ? teamMap.get(x.team_b_id) ?? null : null,
        member_usernames: [...aMembers, ...bMembers],
      };
    }));
    setLoading(false);
  }, []);

  useEffect(() => { void load(); }, [load]);
  useRealtimeRefresh(["tournament_matches", "tournaments", "team_members"], load);

  const tournaments = useMemo(() => {
    const map = new Map<string, string>();
    rows.forEach((r) => map.set(r.tournament_id, r.tournament_name));
    return Array.from(map, ([id, name]) => ({ id, name }));
  }, [rows]);

  const teamOptions = useMemo(() => {
    const map = new Map<string, string>();
    rows.forEach((r) => {
      if (r.team_a_id && r.team_a_name) map.set(r.team_a_id, r.team_a_name);
      if (r.team_b_id && r.team_b_name) map.set(r.team_b_id, r.team_b_name);
    });
    return Array.from(map, ([id, name]) => ({ id, name }));
  }, [rows]);

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    return rows.filter((r) => {
      if (tournamentId && r.tournament_id !== tournamentId) return false;
      if (teamId && r.team_a_id !== teamId && r.team_b_id !== teamId) return false;
      if (status && r.status !== status) return false;
      const ts = Date.parse(r.scheduled_at);
      if (from && ts < Date.parse(from)) return false;
      if (to && ts > Date.parse(to) + 86400000) return false;
      if (term) {
        const hay = [r.tournament_name, r.team_a_name, r.team_b_name, ...r.member_usernames].join(" ").toLowerCase();
        if (!hay.includes(term)) return false;
      }
      return true;
    });
  }, [rows, q, tournamentId, teamId, status, from, to]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-black uppercase">
          Match <span className="gradient-text">Schedule</span>
        </h1>
        <p className="text-sm text-muted-foreground">All matches in Lahore (PKT) time, sorted by kickoff.</p>
      </div>

      <div className="rounded-xl border border-border bg-card p-4 space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search team, member, or tournament…" className="pl-9" />
        </div>
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
          <select className="h-10 rounded-md border border-input bg-background px-3 text-sm" value={tournamentId} onChange={(e) => setTournamentId(e.target.value)}>
            <option value="">All tournaments</option>
            {tournaments.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
          <select className="h-10 rounded-md border border-input bg-background px-3 text-sm" value={teamId} onChange={(e) => setTeamId(e.target.value)}>
            <option value="">All teams</option>
            {teamOptions.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
          <select className="h-10 rounded-md border border-input bg-background px-3 text-sm" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">Any status</option>
            <option value="scheduled">Scheduled</option>
            <option value="live">Live</option>
            <option value="completed">Completed</option>
          </select>
          <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </div>
        {(q || tournamentId || teamId || status || from || to) && (
          <Button size="sm" variant="ghost" onClick={() => { setQ(""); setTournamentId(""); setTeamId(""); setStatus(""); setFrom(""); setTo(""); }}>Clear filters</Button>
        )}
      </div>

      {loading ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : filtered.length === 0 ? (
        <div className="rounded-xl border border-border bg-card p-12 text-center">
          <CalendarDays className="mx-auto h-10 w-10 text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">No matches match your filters.</p>
        </div>
      ) : (
        <ul className="space-y-2">
          {filtered.map((m) => (
            <li key={m.id} className="rounded-lg border border-border bg-card p-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <Link to="/tournaments/$id" params={{ id: m.tournament_id }} className="text-[10px] uppercase text-primary hover:underline">{m.tournament_name}</Link>
                  <div className="text-[10px] uppercase text-muted-foreground">{m.round} · Match #{m.match_number} · {m.status}</div>
                  <div className="font-display font-bold flex items-center gap-2">
                    <Sword className="h-3 w-3 text-primary" />
                    {m.team_a_name ?? "TBD"} <span className="text-muted-foreground">vs</span> {m.team_b_name ?? "TBD"}
                  </div>
                </div>
                <div className="text-xs text-muted-foreground">{formatPKTDateTime(m.scheduled_at)}</div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
