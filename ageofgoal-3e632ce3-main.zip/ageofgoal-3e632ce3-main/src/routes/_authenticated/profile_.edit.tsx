import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { ArrowLeft, AlertTriangle, Save } from "lucide-react";
import { REGIONS, REGION_LABEL, type Region } from "@/lib/region";

export const Route = createFileRoute("/_authenticated/profile_/edit")({ component: EditProfilePage });

const schema = z.object({
  username: z.string().trim().min(3).max(20).regex(/^[a-zA-Z0-9_]+$/, "Letters, numbers, _ only"),
  city: z.string().trim().min(2).max(60),
  region: z.enum(REGIONS),
  gender: z.enum(["male", "female", "other", "prefer_not_to_say"]),
  age: z.coerce.number().int().min(10).max(80),
  ff_uid: z.string().trim().min(5).max(32).regex(/^[0-9]+$/, "UID must be numeric"),
  ff_username: z.string().trim().min(2).max(40),
  level: z.coerce.number().int().min(1).max(100),
  play_style: z.string().trim().min(2).max(40),
  preferred_mode: z.string().trim().min(2).max(40),
  profile_note: z.string().trim().max(220).optional(),
});

function nextEditWindowDays(editCount: number): number {
  if (editCount <= 0) return 0;
  if (editCount === 1) return 3;
  if (editCount === 2) return 7;
  return 30;
}

function EditProfilePage() {
  const navigate = useNavigate();
  const { user, profile, refreshProfile } = useAuth();
  const [v, setV] = useState({
    username: "", city: "", region: "" as Region | "", gender: "prefer_not_to_say",
    age: "", ff_uid: "", ff_username: "", level: "", play_style: "", preferred_mode: "", profile_note: "",
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!profile) return;
    const x = profile as any;
    setV({
      username: profile.username ?? "",
      city: profile.city ?? "",
      region: (profile.region as Region | null) ?? "",
      gender: x.gender ?? "prefer_not_to_say",
      age: x.age?.toString() ?? "",
      ff_uid: profile.ff_uid ?? "",
      ff_username: x.ff_username ?? "",
      level: profile.level?.toString() ?? "",
      play_style: x.play_style ?? "",
      preferred_mode: x.preferred_mode ?? "",
      profile_note: x.profile_note ?? "",
    });
  }, [profile?.id]);

  if (!profile || !user) return null;

  const editCount = (profile as any).edit_count ?? 0;
  const lastEditAt = (profile as any).last_edit_at as string | null;
  const requiredDays = nextEditWindowDays(editCount);
  const sinceDays = lastEditAt ? (Date.now() - Date.parse(lastEditAt)) / 86_400_000 : Infinity;
  const lockedUntilDays = requiredDays > 0 && sinceDays < requiredDays ? Math.ceil(requiredDays - sinceDays) : 0;

  const save = async () => {
    const parsed = schema.safeParse(v);
    if (!parsed.success) return toast.error(parsed.error.issues[0].message);
    setSaving(true);
    const { error } = await supabase.from("profiles").update(parsed.data as any).eq("id", user.id);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Profile updated — re-submitted for verification");
    await refreshProfile();
    navigate({ to: "/pending" });
  };

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <Link to="/profile" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary">
        <ArrowLeft className="h-4 w-4" /> Back to profile
      </Link>

      <div className="rounded-xl border border-primary/30 bg-card p-5">
        <h1 className="font-display text-2xl font-black uppercase">Edit <span className="gradient-text">Profile</span></h1>
        <p className="mt-1 text-xs text-muted-foreground">
          Saving changes will reset your verification to <span className="font-bold text-warning">pending</span>.
        </p>
        <div className="mt-3 grid gap-2 text-xs sm:grid-cols-3">
          <Stat label="Edits used" value={editCount.toString()} />
          <Stat label="Next cooldown" value={requiredDays === 0 ? "None" : `${requiredDays} days`} />
          <Stat label="Status" value={profile.verification_status} />
        </div>
        {lockedUntilDays > 0 && (
          <div className="mt-4 flex items-start gap-2 rounded-lg border border-warning/40 bg-warning/10 p-3 text-sm text-warning">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
            <span>You can next edit your profile in {lockedUntilDays} day{lockedUntilDays === 1 ? "" : "s"}.</span>
          </div>
        )}
      </div>

      <div className="grid gap-4 rounded-xl border border-border bg-card p-5 sm:grid-cols-2">
        <Field label="Username"><Input value={v.username} onChange={(e) => setV({ ...v, username: e.target.value })} /></Field>
        <Field label="City"><Input value={v.city} onChange={(e) => setV({ ...v, city: e.target.value })} /></Field>
        <Field label="Region">
          <select value={v.region} onChange={(e) => setV({ ...v, region: e.target.value as Region })}
            className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm">
            <option value="">Select region</option>
            {REGIONS.map((r) => <option key={r} value={r}>{REGION_LABEL[r]}</option>)}
          </select>
        </Field>
        <Field label="Gender">
          <select value={v.gender} onChange={(e) => setV({ ...v, gender: e.target.value })}
            className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm">
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
            <option value="prefer_not_to_say">Prefer not to say</option>
          </select>
        </Field>
        <Field label="Age"><Input type="number" min={10} max={80} value={v.age} onChange={(e) => setV({ ...v, age: e.target.value })} /></Field>
        <Field label="Free Fire UID"><Input value={v.ff_uid} onChange={(e) => setV({ ...v, ff_uid: e.target.value })} /></Field>
        <Field label="Free Fire username"><Input value={v.ff_username} onChange={(e) => setV({ ...v, ff_username: e.target.value })} /></Field>
        <Field label="Level"><Input type="number" min={1} max={100} value={v.level} onChange={(e) => setV({ ...v, level: e.target.value })} /></Field>
        <Field label="Play style"><Input value={v.play_style} onChange={(e) => setV({ ...v, play_style: e.target.value })} /></Field>
        <Field label="Preferred mode"><Input value={v.preferred_mode} onChange={(e) => setV({ ...v, preferred_mode: e.target.value })} /></Field>
        <Field label="Profile note (optional)" className="sm:col-span-2">
          <Textarea rows={3} value={v.profile_note} onChange={(e) => setV({ ...v, profile_note: e.target.value })} />
        </Field>
      </div>

      <div className="flex justify-end">
        <Button onClick={save} disabled={saving || lockedUntilDays > 0} className="gradient-bg glow-primary">
          <Save className="mr-2 h-4 w-4" /> {saving ? "Saving…" : "Save & re-submit"}
        </Button>
      </div>
    </div>
  );
}

function Field({ label, children, className }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`space-y-1.5 ${className ?? ""}`}>
      <Label className="font-display text-xs font-bold uppercase tracking-widest">{label}</Label>
      {children}
    </div>
  );
}
function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-border bg-background/50 p-2.5">
      <div className="font-display text-[10px] font-bold uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className="text-sm font-bold text-foreground">{value}</div>
    </div>
  );
}
