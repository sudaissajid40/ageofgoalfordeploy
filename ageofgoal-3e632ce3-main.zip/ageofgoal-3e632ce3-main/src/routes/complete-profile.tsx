import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Check, Gamepad2, User, Users, AlertTriangle, ArrowLeft } from "lucide-react";
import { REGIONS, REGION_LABEL, type Region } from "@/lib/region";
import { FFUidCard } from "@/components/FFUidCard";

export const Route = createFileRoute("/complete-profile")({ component: CompleteProfilePage });

const personalSchema = z.object({
  username: z.string().trim().min(3, "Username needs 3+ chars").max(20).regex(/^[a-zA-Z0-9_]+$/, "Letters, numbers, _ only"),
  city: z.string().trim().min(2, "City is required").max(60),
  region: z.enum(REGIONS, { message: "Pick a region" }),
  gender: z.enum(["male", "female", "other", "prefer_not_to_say"], { message: "Pick a gender" }),
  age: z.coerce.number({ message: "Age is required" }).int().min(10, "Minimum age is 10").max(80),
});
const gameSchema = z.object({
  ff_uid: z.string().trim().min(5, "Free Fire UID required").max(32).regex(/^[0-9]+$/, "UID must contain numbers only"),
  ff_username: z.string().trim().min(2, "Free Fire username required").max(40),
  level: z.coerce.number({ message: "Level is required" }).int().min(1, "Level 1-100").max(100, "Level 1-100"),
  play_style: z.string().trim().min(2, "Play style is required").max(40),
  preferred_mode: z.string().trim().min(2, "Preferred mode is required").max(40),
  profile_note: z.string().trim().max(220).optional(),
});

type TeamRow = { id: string; name: string; team_level: number; member_count?: number };

function CompleteProfilePage() {
  const navigate = useNavigate();
  const { user, profile, loading: authLoading, refreshProfile } = useAuth();
  const isResubmit = profile?.verification_status === "rejected";

  const [step, setStep] = useState(1);
  const [username, setUsername] = useState("");
  const [city, setCity] = useState("");
  const [region, setRegion] = useState<Region | "">("");
  const [gender, setGender] = useState("prefer_not_to_say");
  const [age, setAge] = useState("");
  const [ffUid, setFfUid] = useState("");
  const [ffUsername, setFfUsername] = useState("");
  const [level, setLevel] = useState("");
  const [playStyle, setPlayStyle] = useState("Rusher");
  const [preferredMode, setPreferredMode] = useState("Squad");
  const [profileNote, setProfileNote] = useState("");
  const [teamName, setTeamName] = useState("");
  const [teamSearch, setTeamSearch] = useState("");
  const [teams, setTeams] = useState<TeamRow[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [alreadyOnTeam, setAlreadyOnTeam] = useState(false);

  // Redirect rules: rejected users SHOULD stay here (re-submit flow).
  useEffect(() => {
    if (authLoading) return;
    if (!user) navigate({ to: "/login" });
    else if (profile?.profile_completed && profile.verification_status === "approved") {
      navigate({ to: "/dashboard" });
    }
    // pending + completed: also let them tweak by staying here? No — keep current behavior, send to /pending
    else if (profile?.profile_completed && profile.verification_status === "pending") {
      navigate({ to: "/pending" });
    }
    // rejected => fall through, allow editing
  }, [user, profile, authLoading, navigate]);

  // Prefill from existing profile (or signup-derived fallbacks)
  useEffect(() => {
    if (!profile) return;
    const fallbackUsername = user?.email?.split("@")[0]?.replace(/[^a-zA-Z0-9_]/g, "_").slice(0, 20) ?? "";
    setUsername(profile.username ?? fallbackUsername);
    setCity(profile.city ?? "");
    setRegion((profile.region as Region | null) ?? "");
    setFfUid(profile.ff_uid ?? "");
    setLevel(profile.level?.toString() ?? "");
    const extra = profile as any;
    setFfUsername(extra.ff_username ?? "");
    setGender(extra.gender ?? "prefer_not_to_say");
    setAge(extra.age?.toString() ?? "");
    setPlayStyle(extra.play_style ?? "Rusher");
    setPreferredMode(extra.preferred_mode ?? "Squad");
    setProfileNote(extra.profile_note ?? "");
  }, [profile, user?.email]);

  useEffect(() => {
    if (!user) return;
    void supabase.from("team_members").select("team_id").eq("user_id", user.id).maybeSingle().then(({ data }) => {
      setAlreadyOnTeam(!!data);
    });
  }, [user?.id]);

  useEffect(() => {
    const handle = window.setTimeout(async () => {
      const q = teamSearch.trim();
      if (q.length < 2) return setTeams([]);
      const { data } = await supabase.from("teams").select("id, name, team_level, team_members(count)").ilike("name", `%${q}%`).limit(6);
      setTeams((data ?? []).map((t: any) => ({ id: t.id, name: t.name, team_level: t.team_level, member_count: t.team_members?.[0]?.count ?? 0 })));
    }, 250);
    return () => window.clearTimeout(handle);
  }, [teamSearch]);

  const steps = useMemo(() => ["Personal", "Game", "Team"], []);

  const savePersonal = async () => {
    if (!user) return;
    const parsed = personalSchema.safeParse({ username, city, region, gender, age });
    if (!parsed.success) return toast.error(parsed.error.issues[0].message);
    const { error } = await supabase.from("profiles").update({ ...parsed.data, onboarding_step: 2 } as any).eq("id", user.id);
    if (error) return toast.error(error.message);
    await refreshProfile();
    setStep(2);
  };

  const saveGame = async () => {
    if (!user) return;
    const parsed = gameSchema.safeParse({ ff_uid: ffUid, ff_username: ffUsername, level, play_style: playStyle, preferred_mode: preferredMode, profile_note: profileNote });
    if (!parsed.success) return toast.error(parsed.error.issues[0].message);
    const { error } = await supabase.from("profiles").update({ ...parsed.data, onboarding_step: 3 } as any).eq("id", user.id);
    if (error) return toast.error(error.message);
    await refreshProfile();
    setStep(3);
  };

  const createTeam = async () => {
    if (!user || teamName.trim().length < 3) return toast.error("Team name needs at least 3 characters");
    if (alreadyOnTeam) return toast.error("You're already on a team. Leave it first to create a new one.");
    const join_code = Math.random().toString(36).slice(2, 8).toUpperCase();
    const { error } = await supabase.from("teams").insert({ name: teamName.trim(), owner_id: user.id, join_code });
    if (error) return toast.error(error.message);
    toast.success("Team created");
    await finish();
  };

  const requestTeam = async (teamId: string) => {
    if (!user) return;
    const { error } = await supabase.from("team_join_requests").insert({ team_id: teamId, user_id: user.id });
    if (error) return toast.error(error.message);
    toast.success("Join request sent to team owner");
    await finish();
  };

  const finish = async () => {
    if (!user) return;
    setSubmitting(true);
    // For rejected users: flip status back to pending and clear the rejection reason so admin sees a fresh request.
    const update: any = { profile_completed: true, onboarding_step: 3 };
    if (isResubmit) {
      update.verification_status = "pending";
      update.rejection_reason = null;
    }
    const { error } = await supabase.from("profiles").update(update).eq("id", user.id);
    setSubmitting(false);
    if (error) return toast.error(error.message);
    toast.success(isResubmit ? "Re-submitted for verification" : "Profile submitted for verification");
    await refreshProfile();
    navigate({ to: "/pending" });
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (step === 1) await savePersonal();
    else if (step === 2) await saveGame();
    else await finish();
  };

  return (
    <div className="mx-auto grid min-h-screen max-w-6xl items-start gap-6 px-4 py-8 lg:grid-cols-[1fr_340px]">
      <div className="space-y-5">
        {isResubmit && (
          <div className="flex items-start gap-3 rounded-xl border border-destructive/40 bg-destructive/10 p-4">
            <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
            <div className="text-sm">
              <div className="font-display font-bold uppercase text-destructive">Your previous submission was rejected</div>
              {profile?.rejection_reason && <p className="mt-1 text-foreground/90 whitespace-pre-wrap"><span className="text-muted-foreground">Admin note:</span> {profile.rejection_reason}</p>}
              <p className="mt-2 text-muted-foreground">Update the fields below and re-submit. Your status will go back to pending review.</p>
              <Link to="/rejected" className="mt-2 inline-flex items-center gap-1 text-xs text-primary hover:underline">
                <ArrowLeft className="h-3 w-3" /> Back to rejection screen
              </Link>
            </div>
          </div>
        )}

        <div className="rounded-xl border border-primary/30 bg-card/90 p-5 card-glow">
          <h1 className="font-display text-2xl font-black uppercase">Complete <span className="gradient-text">Profile</span></h1>
          <p className="mt-1 text-xs text-muted-foreground">All fields are required.</p>
          <div className="mt-5 grid gap-2 sm:grid-cols-3">
            {steps.map((label, i) => <div key={label} className={`rounded-md border px-3 py-2 text-xs font-bold uppercase tracking-widest ${step === i + 1 ? "border-primary bg-primary/15 text-primary" : i + 1 < step ? "border-success/40 text-success" : "border-border text-muted-foreground"}`}>{i + 1 < step ? <Check className="mr-1 inline h-3 w-3" /> : null}{label}</div>)}
          </div>
        </div>

        <form onSubmit={onSubmit} className="rounded-xl border border-border bg-card p-6">
          {step === 1 && (
            <div className="grid gap-4 sm:grid-cols-2">
              <SectionTitle icon={<User className="h-4 w-4" />} title="Personal details" />
              <Field label="Username"><Input value={username} onChange={(e) => setUsername(e.target.value)} required minLength={3} maxLength={20} /></Field>
              <Field label="City"><Input value={city} onChange={(e) => setCity(e.target.value)} required minLength={2} /></Field>
              <Field label="Region">
                <select value={region} onChange={(e) => setRegion(e.target.value as Region)} className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm" required>
                  <option value="">Select region</option>
                  {REGIONS.map((r) => <option key={r} value={r}>{REGION_LABEL[r]}</option>)}
                </select>
              </Field>
              <Field label="Gender">
                <select value={gender} onChange={(e) => setGender(e.target.value)} className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm" required>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                  <option value="prefer_not_to_say">Prefer not to say</option>
                </select>
              </Field>
              <Field label="Age"><Input type="number" min={10} max={80} value={age} onChange={(e) => setAge(e.target.value)} required /></Field>
            </div>
          )}
          {step === 2 && (
            <div className="grid gap-4 sm:grid-cols-2">
              <SectionTitle icon={<Gamepad2 className="h-4 w-4" />} title="In-game details" />
              <Field label="Free Fire UID"><Input value={ffUid} onChange={(e) => setFfUid(e.target.value)} placeholder="5161434495" required /></Field>
              <Field label="Free Fire username"><Input value={ffUsername} onChange={(e) => setFfUsername(e.target.value)} placeholder="ProPlayerYT" required /></Field>
              <Field label="Free Fire level"><Input type="number" min={1} max={100} value={level} onChange={(e) => setLevel(e.target.value)} required /></Field>
              <Field label="Play style"><Input value={playStyle} onChange={(e) => setPlayStyle(e.target.value)} placeholder="Rusher / Sniper / Support" required /></Field>
              <Field label="Preferred mode"><Input value={preferredMode} onChange={(e) => setPreferredMode(e.target.value)} placeholder="Solo / Duo / Squad" required /></Field>
              <Field label="Profile note (optional)" className="sm:col-span-2"><Textarea value={profileNote} onChange={(e) => setProfileNote(e.target.value)} rows={3} placeholder="Short note for admins" /></Field>
            </div>
          )}
          {step === 3 && (
            <div className="space-y-5">
              <SectionTitle icon={<Users className="h-4 w-4" />} title="Team setup" />
              {alreadyOnTeam ? (
                <div className="rounded-lg border border-success/30 bg-success/10 p-4 text-sm text-success">You're already on a team. Skip to finish onboarding.</div>
              ) : (
                <div className="grid gap-4 lg:grid-cols-2">
                  <div className="rounded-lg border border-border bg-background/50 p-4">
                    <h3 className="font-display font-bold uppercase">Create team</h3>
                    <Input className="mt-3" value={teamName} onChange={(e) => setTeamName(e.target.value)} placeholder="Phoenix Squad" />
                    <Button type="button" onClick={createTeam} className="mt-3 w-full gradient-bg">Create and continue</Button>
                  </div>
                  <div className="rounded-lg border border-border bg-background/50 p-4">
                    <h3 className="font-display font-bold uppercase">Join team</h3>
                    <Input className="mt-3" value={teamSearch} onChange={(e) => setTeamSearch(e.target.value)} placeholder="Search team name" />
                    {teams.length > 0 && (
                      <ul className="mt-3 space-y-2">
                        {teams.map((team) => (
                          <li key={team.id} className="flex items-center justify-between rounded-md border border-border p-2 text-sm">
                            <span>{team.name} · Lv {team.team_level} · {team.member_count}/6</span>
                            <Button type="button" size="sm" variant="outline" onClick={() => requestTeam(team.id)}>Request</Button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </div>
              )}
              <div className="rounded-lg border border-primary/30 bg-primary/10 p-4 text-sm text-muted-foreground">
                <p><span className="font-bold text-primary">Important:</span> send a friend request to Free Fire UID <span className="font-mono text-foreground">5161434495</span>. Admin will verify your account after checking the request.</p>
              </div>
            </div>
          )}
          <div className="mt-6 flex flex-wrap gap-2">
            {step > 1 && <Button type="button" variant="outline" onClick={() => setStep((s) => s - 1)}>Back</Button>}
            <Button type="submit" disabled={submitting} className="gradient-bg glow-primary">
              {step === 3 ? (isResubmit ? "Re-submit for verification" : "Skip / Submit for verification") : "Continue"}
            </Button>
          </div>
        </form>
      </div>
      <div className="lg:pt-20"><FFUidCard /></div>
    </div>
  );
}

function SectionTitle({ icon, title }: { icon: React.ReactNode; title: string }) {
  return <div className="sm:col-span-2 flex items-center gap-2 font-display text-lg font-bold uppercase text-primary">{icon}{title}</div>;
}
function Field({ label, children, className }: { label: string; children: React.ReactNode; className?: string }) {
  return <div className={`space-y-1.5 ${className ?? ""}`}><Label className="font-display text-xs font-bold uppercase tracking-widest">{label}</Label>{children}</div>;
}
