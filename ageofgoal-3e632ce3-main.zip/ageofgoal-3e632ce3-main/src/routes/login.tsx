import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { GoogleSignInButton } from "@/components/GoogleSignInButton";
import heroArena from "@/assets/hero-arena.jpg";

export const Route = createFileRoute("/login")({
  component: LoginPage,
});

const schema = z.object({
  email: z.string().trim().email("Invalid email").max(255),
  password: z.string().min(6, "Min 6 characters").max(72),
});

function LoginPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  if (user) {
    navigate({ to: "/dashboard" });
  }

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse({ email, password });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword(parsed.data);
    setLoading(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Welcome back, soldier.");
    navigate({ to: "/dashboard" });
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center px-4">
      <div className="absolute inset-0 -z-10">
        <img src={heroArena} alt="" className="h-full w-full object-cover opacity-30" width={1920} height={1080} />
        <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/90 to-background" />
      </div>

      <div className="w-full max-w-md">
        <Link to="/" className="mb-8 flex items-baseline justify-center gap-0.5">
          <span className="font-display text-4xl font-black tracking-wider">AOG</span>
          <span className="font-display text-4xl font-black text-primary text-glow">.</span>
        </Link>
        <div className="rounded-xl border border-primary/30 bg-card/90 backdrop-blur-xl p-6 card-glow">
          <h1 className="font-display text-2xl font-black uppercase tracking-tight">
            Sign <span className="gradient-text">In</span>
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">Welcome back to the battleground.</p>
          <form onSubmit={onSubmit} className="mt-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="font-display text-xs font-bold uppercase tracking-widest">Email</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="font-display text-xs font-bold uppercase tracking-widest">Password</Label>
              <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
            </div>
            <Button type="submit" className="w-full h-12 gradient-bg glow-primary font-display font-bold uppercase tracking-widest text-primary-foreground" disabled={loading}>
              {loading ? "Signing in..." : "Engage"}
            </Button>
          </form>

          <div className="my-4 flex items-center gap-3">
            <div className="h-px flex-1 bg-border" />
            <span className="font-display text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Or</span>
            <div className="h-px flex-1 bg-border" />
          </div>
          <GoogleSignInButton label="Sign in with Google" />
          <p className="mt-4 text-center text-sm text-muted-foreground">
            New recruit?{" "}
            <Link to="/signup" className="font-display font-bold uppercase tracking-wider text-primary hover:underline">
              Enlist now
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
