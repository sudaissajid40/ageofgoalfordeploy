import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Clock, RefreshCw, LogOut, ArrowRight } from "lucide-react";
import { FFUidCard } from "@/components/FFUidCard";
import { REGION_LABEL, type Region } from "@/lib/region";

export const Route = createFileRoute("/pending")({
  component: PendingPage,
});

function PendingPage() {
  const navigate = useNavigate();
  const { user, profile, loading, refreshProfile, signOut } = useAuth();

  useEffect(() => {
    if (loading) return;
    if (!user) navigate({ to: "/login" });
    else if (!profile?.profile_completed) navigate({ to: "/complete-profile" });
    else if (profile.verification_status === "approved") navigate({ to: "/dashboard" });
    else if (profile.verification_status === "rejected") navigate({ to: "/rejected" });
  }, [user, profile, loading, navigate]);

  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-8">
      <div className="grid w-full max-w-3xl gap-6 lg:grid-cols-[1fr_340px]">
        <div className="text-center lg:text-left">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-warning/15 border border-warning/30 lg:mx-0">
            <Clock className="h-8 w-8 text-warning" />
          </div>
          <h1 className="mt-6 text-2xl font-bold">Verification pending</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Send a Free Fire friend request to the UID on the right, then wait for admin approval. You can already explore your profile while you wait.
          </p>
          <div className="mt-6 rounded-xl border border-border bg-card p-4 text-left text-sm">
            <Row k="Username" v={profile?.username ?? "—"} />
            <Row k="FF Username" v={(profile as any)?.ff_username ?? "—"} />
            <Row k="FF Level" v={String(profile?.level ?? "—")} />
            <Row k="City" v={profile?.city ?? "—"} />
            <Row k="Region" v={profile?.region ? REGION_LABEL[profile.region as Region] : "—"} />
          </div>
          <div className="mt-6 flex flex-wrap justify-center gap-3 lg:justify-start">
            <Button asChild className="gradient-bg glow-primary">
              <Link to="/profile">
                <ArrowRight className="mr-2 h-4 w-4" /> Enter profile
              </Link>
            </Button>
            <Button onClick={refreshProfile} variant="outline">
              <RefreshCw className="mr-2 h-4 w-4" /> Check status
            </Button>
            <Button onClick={signOut} variant="ghost">
              <LogOut className="mr-2 h-4 w-4" /> Sign out
            </Button>
          </div>
        </div>
        <FFUidCard />
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="mt-2 flex justify-between first:mt-0">
      <span className="text-muted-foreground">{k}</span>
      <span className="font-mono">{v}</span>
    </div>
  );
}
