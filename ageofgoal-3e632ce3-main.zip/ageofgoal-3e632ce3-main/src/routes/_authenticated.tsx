import { createFileRoute, Outlet, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth-context";
import { SidebarLayout } from "@/components/SidebarLayout";
import { RejectedBanner } from "@/components/RejectedBanner";
import { InstallAppBanner } from "@/components/InstallAppBanner";
import { EnableNotificationsBanner } from "@/components/EnableNotificationsBanner";
import { ensureSwRegistered } from "@/lib/push";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/_authenticated")({
  component: AuthenticatedLayout,
});

function AuthenticatedLayout() {
  const navigate = useNavigate();
  const { user, profile, loading } = useAuth();

  useEffect(() => {
    if (loading) return;
    if (!user) { navigate({ to: "/login" }); return; }
    if (!profile) return;
    if (!profile.profile_completed) navigate({ to: "/complete-profile" });
  }, [user, profile, loading, navigate]);

  useEffect(() => { void ensureSwRegistered(); }, []);

  if (loading || !user || !profile || !profile.profile_completed) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <SidebarLayout>
      <RejectedBanner />
      <Outlet />
      <InstallAppBanner />
      <EnableNotificationsBanner />
    </SidebarLayout>
  );
}
