import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Trophy, Calendar, Users, Flame, ArrowRight, Lock } from "lucide-react";
import heroArena from "@/assets/hero-arena.jpg";
import { useRealtimeRefresh } from "@/hooks/useRealtimeRefresh";
import { formatPKTDate } from "@/lib/time";
import type { Database } from "@/integrations/supabase/types";

type Tournament = Database["public"]["Tables"]["tournaments"]["Row"];

export const Route = createFileRoute("/")({ component: Index });

function Index() {
  const { user, profile, loading } = useAuth();
  const router = useRouter();
  const [featured, setFeatured] = useState<Tournament[]>([]);

  useEffect(() => {
    if (loading || !user || !profile) return;
    if (!profile.profile_completed) router.navigate({ to: "/complete-profile" });
    else if (profile.verification_status === "pending") router.navigate({ to: "/pending" });
    else if (profile.verification_status === "rejected") router.navigate({ to: "/rejected" });
    else router.navigate({ to: "/profile" });
  }, [user, profile, loading, router]);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("tournaments").select("*").in("status", ["upcoming", "live"]).order("starts_at", { ascending: true }).limit(3);
      setFeatured(data ?? []);
    })();
  }, []);

  const reloadFeatured = async () => {
    const { data } = await supabase.from("tournaments").select("*").in("status", ["upcoming", "live"]).order("starts_at", { ascending: true }).limit(3);
    setFeatured(data ?? []);
  };
  useRealtimeRefresh(["tournaments"], reloadFeatured);

  return (
    <div className="min-h-screen">
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img src={heroArena} alt="AOG arena" className="h-full w-full object-cover opacity-60" width={1920} height={1080} />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/85 to-background/40" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
        </div>
        <div className="relative mx-auto max-w-6xl px-6 py-20 sm:py-28 md:py-36">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 rounded-md border border-primary/40 bg-primary/10 px-4 py-1.5 backdrop-blur-sm">
              <Flame className="h-3.5 w-3.5 text-primary" />
              <span className="font-display text-[11px] font-bold uppercase tracking-[0.2em] text-primary">Top Mobile Esports</span>
            </div>
            <h1 className="mt-6 font-display text-5xl font-black uppercase leading-none tracking-tight sm:text-7xl md:text-8xl">
              <span className="text-glow text-foreground">Age</span> <span className="text-foreground">of</span> <span className="gradient-text text-glow">Goal</span>
            </h1>
            <p className="mt-6 max-w-md text-base text-muted-foreground sm:text-lg">Enter the ultimate Free Fire battleground. Build your profile, verify your account, join a squad, and compete for AOG points.</p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
              <Button asChild size="lg" className="h-14 gradient-bg glow-primary-strong font-display text-base font-bold uppercase tracking-widest text-primary-foreground clip-tactical">
                <Link to={user ? "/profile" : "/signup"}>{user ? "Enter Profile" : "Create Profile"}</Link>
              </Button>
              {!user && <Button asChild size="lg" variant="outline" className="h-14 border-2 font-display text-base font-bold uppercase tracking-widest hover:border-primary hover:text-primary clip-tactical"><Link to="/login">Log In</Link></Button>}
            </div>
          </div>
        </div>
      </section>

      <section className="relative mx-auto max-w-6xl px-6 py-12 sm:py-16">
        <div className="mb-8 flex items-end justify-between">
          <h2 className="font-display text-3xl font-black uppercase tracking-tight sm:text-4xl">Featured <span className="gradient-text">Tournaments</span></h2>
          {user && <Link to="/tournaments" className="hidden items-center gap-1 font-display text-xs font-bold uppercase tracking-widest text-primary hover:underline sm:inline-flex">View all <ArrowRight className="h-3.5 w-3.5" /></Link>}
        </div>
        {featured.length === 0 ? <div className="rounded-xl border border-border bg-card/50 p-12 text-center"><Trophy className="mx-auto h-10 w-10 text-muted-foreground" /><p className="mt-3 text-sm text-muted-foreground">No active tournaments yet — stay tuned.</p></div> : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {featured.map((t) => {
              const isLive = t.status === "live";
              const regOpen = t.status === "upcoming" && (!t.registration_ends_at || Date.parse(t.registration_ends_at) > Date.now());
              const regClosed = t.status === "upcoming" && !regOpen;
              const badgeLabel = isLive ? "Live Now" : regClosed ? "Registration Closed" : "Registration Open";
              const badgeClass = isLive
                ? "border-success/40 bg-success/10 text-success"
                : regClosed
                  ? "border-warning/40 bg-warning/10 text-warning"
                  : "border-primary/40 bg-primary/10 text-primary";
              const ctaLabel = isLive ? "Watch Live" : regClosed ? "View Bracket" : "Join Tournament";
              return (
              <article key={t.id} className="group relative overflow-hidden rounded-xl border border-border bg-card card-glow">
                <div className="aspect-[16/9] bg-gradient-to-br from-primary/20 via-card to-card flex items-center justify-center overflow-hidden">{t.thumbnail_url ? <img src={t.thumbnail_url} alt={t.name} className="h-full w-full object-cover" /> : <Trophy className="h-16 w-16 text-primary/40 group-hover:text-primary/70 transition-colors" />}</div>
                <div className="p-5">
                  <span className={`inline-block rounded border px-2 py-0.5 font-display text-[10px] font-bold uppercase tracking-widest ${badgeClass}`}>{badgeLabel}</span>
                  <h3 className="mt-3 font-display text-xl font-bold uppercase">{t.name}</h3>
                  <div className="mt-3 flex items-center gap-4 text-xs text-muted-foreground"><span className="flex items-center gap-1.5"><Calendar className="h-3.5 w-3.5" />{formatPKTDate(t.starts_at)}</span><span className="flex items-center gap-1.5"><Users className="h-3.5 w-3.5" />{t.max_participants ?? "∞"} {t.type === "team" ? "Teams" : "Players"}</span></div>
                  {user ? <Button asChild className="mt-4 w-full gradient-bg glow-primary font-display font-bold uppercase tracking-wider text-primary-foreground"><Link to="/tournaments/$id" params={{ id: t.id }}>{ctaLabel}</Link></Button> : <Button asChild variant="outline" className="mt-4 w-full border-primary/40 text-primary font-display font-bold uppercase tracking-wider"><Link to="/signup"><Lock className="mr-2 h-3.5 w-3.5" /> Profile Required</Link></Button>}
                </div>
              </article>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
