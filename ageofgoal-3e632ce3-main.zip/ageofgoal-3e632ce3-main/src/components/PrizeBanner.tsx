import { Trophy } from "lucide-react";

export function PrizeBanner({ pointsPerWin, championMult, teamSize }: { pointsPerWin: number; championMult: number; teamSize: number }) {
  const championBonus = championMult * teamSize;
  return (
    <div className="rounded-lg border border-primary/30 bg-gradient-to-r from-primary/15 via-card to-card p-3">
      <div className="flex items-center gap-2 text-sm">
        <Trophy className="h-4 w-4 text-primary" />
        <span className="font-display font-bold uppercase tracking-wider text-foreground">
          Win {pointsPerWin} AOG / match · Champion bonus {championBonus} pts
        </span>
      </div>
      <p className="mt-1 text-xs text-muted-foreground">Register your team now and climb the leaderboard.</p>
    </div>
  );
}
