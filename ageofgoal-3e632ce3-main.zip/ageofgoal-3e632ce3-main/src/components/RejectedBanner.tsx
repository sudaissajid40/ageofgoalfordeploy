import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { AlertTriangle, Pencil, X } from "lucide-react";

const DISMISS_KEY = "aog_rejected_banner_dismissed_until";

export function RejectedBanner() {
  const { profile } = useAuth();
  const [dismissed, setDismissed] = useState(true);

  useEffect(() => {
    const until = parseInt(localStorage.getItem(DISMISS_KEY) || "0", 10);
    setDismissed(Date.now() < until);
  }, [profile?.id, profile?.verification_status]);

  if (!profile || profile.verification_status !== "rejected" || dismissed) return null;

  const dismiss = () => {
    localStorage.setItem(DISMISS_KEY, String(Date.now() + 24 * 60 * 60 * 1000));
    setDismissed(true);
  };

  return (
    <div className="sticky top-0 z-30 border-b border-destructive/40 bg-destructive/15 px-4 py-3 backdrop-blur">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3">
        <div className="flex items-start gap-2 text-sm">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
          <div>
            <span className="font-display font-bold uppercase tracking-wider text-destructive">Verification rejected.</span>{" "}
            <span className="text-foreground">
              {profile.rejection_reason ?? "Update your details and resubmit for review."}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Link
            to="/profile/edit"
            className="inline-flex items-center gap-2 rounded-md border border-destructive/50 bg-destructive px-3 py-1.5 text-xs font-bold uppercase tracking-wider text-destructive-foreground hover:opacity-90"
          >
            <Pencil className="h-3.5 w-3.5" /> Edit & resubmit
          </Link>
          <button
            type="button"
            onClick={dismiss}
            aria-label="Dismiss"
            className="rounded p-1 text-destructive/80 hover:text-destructive"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
