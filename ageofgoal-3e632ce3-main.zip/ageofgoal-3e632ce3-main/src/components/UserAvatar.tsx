import { cn } from "@/lib/utils";
import avatarMale from "@/assets/characters/avatar-male.jpg";
import avatarFemale from "@/assets/characters/avatar-female.jpg";

interface Props {
  username?: string | null;
  gender?: string | null;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}

const SIZES = {
  sm: "h-9 w-9 text-sm",
  md: "h-11 w-11 text-base",
  lg: "h-16 w-16 text-xl",
  xl: "h-20 w-20 text-3xl",
} as const;

export function UserAvatar({ username, gender, size = "md", className }: Props) {
  const cls = cn("relative shrink-0 overflow-hidden rounded-full border border-primary/30 bg-primary/10", SIZES[size], className);
  if (gender === "male") {
    return <img src={avatarMale} alt={username ?? "Player"} className={cls + " object-cover"} loading="lazy" width={128} height={128} />;
  }
  if (gender === "female") {
    return <img src={avatarFemale} alt={username ?? "Player"} className={cls + " object-cover"} loading="lazy" width={128} height={128} />;
  }
  return (
    <div className={cn(cls, "flex items-center justify-center font-display font-black gradient-bg text-primary-foreground glow-primary")}>
      {username?.[0]?.toUpperCase() ?? "?"}
    </div>
  );
}
