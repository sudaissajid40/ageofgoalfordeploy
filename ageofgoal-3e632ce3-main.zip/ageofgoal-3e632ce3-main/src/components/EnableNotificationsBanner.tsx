import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Bell, X } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { pushSupported, subscribeToPush } from "@/lib/push";
import { toast } from "sonner";

const DISMISS_KEY = "aog_notif_dismissed_until";

export function EnableNotificationsBanner() {
  const { user, isVerified } = useAuth();
  const [hidden, setHidden] = useState(true);

  useEffect(() => {
    if (!user || !isVerified) return;
    if (!pushSupported()) return;
    if (Notification.permission !== "default") return;
    const until = parseInt(localStorage.getItem(DISMISS_KEY) || "0", 10);
    if (Date.now() < until) return;
    setHidden(false);
  }, [user?.id, isVerified]);

  if (hidden || !user) return null;

  const enable = async () => {
    const ok = await subscribeToPush(user.id);
    if (ok) toast.success("Notifications enabled");
    else toast.error("Could not enable notifications");
    setHidden(true);
  };
  const dismiss = () => {
    localStorage.setItem(DISMISS_KEY, String(Date.now() + 3 * 24 * 60 * 60 * 1000));
    setHidden(true);
  };

  return (
    <div className="fixed inset-x-3 bottom-20 z-40 mx-auto max-w-md rounded-lg border border-primary/40 bg-card/95 p-3 shadow-xl backdrop-blur">
      <div className="flex items-center gap-3">
        <Bell className="h-5 w-5 shrink-0 text-primary" />
        <div className="min-w-0 flex-1 text-sm">
          <div className="font-display font-bold uppercase tracking-wider">Enable notifications</div>
          <div className="text-xs text-muted-foreground">Get alerts for tournaments, invites, and match rooms.</div>
        </div>
        <Button size="sm" onClick={enable} className="gradient-bg glow-primary">Allow</Button>
        <button onClick={dismiss} aria-label="Dismiss" className="rounded p-1 text-muted-foreground hover:text-foreground">
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
