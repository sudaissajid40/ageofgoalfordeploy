import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Receipt, CheckCircle2, Clock, XCircle, Upload } from "lucide-react";

type PaymentRow = {
  id: string;
  status: "pending" | "approved" | "rejected";
  amount: number;
  receipt_url: string;
  admin_note: string | null;
};

export function PaymentReceiptUpload({
  tournamentId,
  entryFee,
  accountLabel,
  accountNumber,
  instructions,
}: {
  tournamentId: string;
  entryFee: number;
  accountLabel: string | null;
  accountNumber: string | null;
  instructions: string | null;
}) {
  const { user } = useAuth();
  const [submission, setSubmission] = useState<PaymentRow | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  const load = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from("payment_submissions")
      .select("id, status, amount, receipt_url, admin_note")
      .eq("tournament_id", tournamentId)
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    setSubmission((data as PaymentRow | null) ?? null);
  }, [tournamentId, user?.id]);

  useEffect(() => { void load(); }, [load]);

  const upload = async () => {
    if (!user || !file) return toast.error("Pick a receipt image first");
    setUploading(true);
    try {
      const ext = file.name.split(".").pop() ?? "jpg";
      const path = `${user.id}/${tournamentId}/${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("payment-receipts").upload(path, file, { upsert: false });
      if (upErr) throw upErr;
      const { error: insErr } = await supabase.from("payment_submissions").insert({
        tournament_id: tournamentId,
        user_id: user.id,
        amount: entryFee,
        receipt_url: path,
        status: "pending",
      });
      if (insErr) throw insErr;
      toast.success("Receipt submitted — admin will review shortly");
      setFile(null);
      await load();
    } catch (e: any) {
      toast.error(e.message ?? "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="rounded-xl border border-warning/30 bg-warning/5 p-5">
      <div className="flex items-center gap-2">
        <Receipt className="h-4 w-4 text-warning" />
        <h2 className="font-display font-bold uppercase tracking-wide text-foreground">
          Entry fee · PKR {entryFee}
        </h2>
      </div>
      <div className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
        <div><span className="text-muted-foreground">Send to:</span> <span className="font-mono text-foreground">{accountLabel ?? "—"}</span></div>
        <div><span className="text-muted-foreground">Account:</span> <span className="font-mono text-foreground">{accountNumber ?? "—"}</span></div>
      </div>
      {instructions && <p className="mt-2 whitespace-pre-wrap text-xs text-muted-foreground">{instructions}</p>}

      {submission ? (
        <div className="mt-4 rounded-lg border border-border bg-card p-3 text-sm">
          {submission.status === "pending" && (
            <div className="flex items-center gap-2 text-warning"><Clock className="h-4 w-4" /> Receipt under review</div>
          )}
          {submission.status === "approved" && (
            <div className="flex items-center gap-2 text-success"><CheckCircle2 className="h-4 w-4" /> Payment approved — you can register now</div>
          )}
          {submission.status === "rejected" && (
            <div>
              <div className="flex items-center gap-2 text-destructive"><XCircle className="h-4 w-4" /> Receipt rejected</div>
              {submission.admin_note && <p className="mt-1 text-xs text-muted-foreground">{submission.admin_note}</p>}
              <Button size="sm" variant="outline" className="mt-2" onClick={() => setSubmission(null)}>Submit a new receipt</Button>
            </div>
          )}
        </div>
      ) : (
        <div className="mt-4 space-y-2">
          <Label className="font-display text-xs font-bold uppercase tracking-widest">Upload receipt screenshot</Label>
          <Input type="file" accept="image/*,application/pdf" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
          <Button onClick={upload} disabled={!file || uploading} className="gradient-bg glow-primary">
            <Upload className="mr-2 h-4 w-4" /> {uploading ? "Uploading…" : "Submit receipt"}
          </Button>
        </div>
      )}
    </div>
  );
}
