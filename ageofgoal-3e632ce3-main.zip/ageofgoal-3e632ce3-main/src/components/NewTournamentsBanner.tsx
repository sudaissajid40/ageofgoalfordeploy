import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { Trophy, Sparkles, ArrowRight, Coins } from "lucide-react";
import { formatPKTDate } from "@/lib/time";

interface T {
  id: string;
  name: string;
  type: string;
  starts_at: string;
  entry_fee: number;
  points_per_match_win: number;
  champion_points_multiplier: number;
  match_team_size: number;
  thumbnail_url: string | null;
  registration_ends_at: string | null;
}

export function NewTournamentsBanner() {
  const [items, setItems] = useState<T[]>([]);

  useEffect(() => {
    void (async () => {
      const nowIso = new Date().toISOString();
      const { data } = await supabase
        .from("tournaments")
        .select("id,name,type,starts_at,entry_fee,points_per_match_win,champion_points_multiplier,match_team_size,thumbnail_url,registration_ends_at")
        .in("status", ["upcoming", "live"])
        .gt("registration_ends_at", nowIso)
        .order("starts_at", { ascending: true })
        .limit(3);
      setItems((data ?? []) as T[]);
    })();
  }, []);

  if (items.length === 0) return null;

  return (
    <section className="relative overflow-hidden rounded-2xl border-2 border-primary/40 bg-gradient-to-br from-primary/20 via-card to-card p-5 shadow-[0_10px_40px_-10px_hsl(var(--primary)/0.5)]">
      <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-primary/30 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-10 -left-10 h-40 w-40 rounded-full bg-warning/20 blur-3xl" />

      <div className="relative flex items-center gap-2">
        <Sparkles className="h-5 w-5 text-warning animate-pulse" />
        <h2 className="font-display text-xl font-black uppercase tracking-wider sm:text-2xl">
          New <span className="gradient-text">Tournaments</span> · Win Big
        </h2>
      </div>
      <p className="relative mt-1 text-xs text-muted-foreground">Register now, climb the leaderboard, take the crown.</p>

      <div className="relative mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((t) => {
          const championBonus = t.champion_points_multiplier * t.match_team_size;
          return (
            <Link
              key={t.id}
              to="/tournaments/$id"
              params={{ id: t.id }}
              className="group relative flex flex-col gap-2 overflow-hidden rounded-xl border border-primary/30 bg-background/60 p-3 transition hover:border-primary hover:bg-background"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="font-display text-sm font-black uppercase tracking-wide text-foreground truncate">{t.name}</div>
                  <div className="font-mono text-[10px] uppercase text-muted-foreground">{t.type} · {formatPKTDate(t.starts_at)}</div>
                </div>
                <Trophy className="h-5 w-5 shrink-0 text-warning" />
              </div>
              <div className="flex flex-wrap gap-1.5">
                <span className="inline-flex items-center gap-1 rounded-md bg-primary/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-primary">
                  <Coins className="h-3 w-3" /> {t.points_per_match_win} AOG / win
                </span>
                <span className="inline-flex items-center gap-1 rounded-md bg-warning/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-warning">
                  👑 +{championBonus} champion
                </span>
                {t.entry_fee > 0 && (
                  <span className="inline-flex items-center rounded-md bg-muted px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                    Fee {t.entry_fee}
                  </span>
                )}
              </div>
              <div className="mt-1 inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-primary group-hover:gap-2 transition-all">
                Register <ArrowRight className="h-3 w-3" />
              </div>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
