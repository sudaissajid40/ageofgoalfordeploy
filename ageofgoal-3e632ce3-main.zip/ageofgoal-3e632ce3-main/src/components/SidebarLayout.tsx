import { Link, useNavigate } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { useAuth } from "@/lib/auth-context";
import { Trophy, Users, User as UserIcon, Crown, Shield, LogOut, Menu, X, Mail, CalendarDays, Award, Info } from "lucide-react";
import { cn } from "@/lib/utils";
import { UserAvatar } from "@/components/UserAvatar";

interface NavItemDef {
  to: string;
  label: string;
  icon: typeof Trophy;
  exact?: boolean;
}

const STATIC_NAV: NavItemDef[] = [
  { to: "/profile", label: "Profile", icon: UserIcon },
];

const POST_TEAM_NAV: NavItemDef[] = [
  { to: "/tournaments", label: "Tournaments", icon: Trophy },
  { to: "/schedule", label: "Schedule", icon: CalendarDays },
  { to: "/results", label: "Results", icon: Award },
  { to: "/leaderboard", label: "Ranking", icon: Crown },
  { to: "/mailbox", label: "Mailbox", icon: Mail },
  { to: "/about", label: "About", icon: Info },
];

const NAV_LINK_CLS = "group relative flex items-center gap-3 rounded-md px-4 py-3 text-sm font-semibold uppercase tracking-wider text-muted-foreground transition-colors hover:bg-accent/50 hover:text-foreground";
const NAV_ACTIVE = { className: "bg-primary/15 text-primary border-l-2 border-primary text-glow" };

export function SidebarLayout({ children }: { children: ReactNode }) {
  const { profile, isAdmin, myTeamId, signOut } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate({ to: "/" });
  };

  const close = () => setOpen(false);
  const username = profile?.username ?? "Player";
  const uid = profile?.ff_uid ?? profile?.id?.replace(/-/g, "").slice(0, 9) ?? "—";

  return (
    <div className="flex min-h-screen">
      <button
        onClick={() => setOpen((v) => !v)}
        className="fixed left-3 top-3 z-50 flex h-10 w-10 items-center justify-center rounded-md border border-primary/40 bg-card/95 shadow-lg md:hidden"
        aria-label="Toggle menu"
      >
        {open ? <X className="h-5 w-5 text-primary" /> : <Menu className="h-5 w-5 text-primary" />}
      </button>

      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-primary/20 bg-card/90 backdrop-blur-xl transition-transform md:sticky md:top-0 md:h-screen md:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="border-b border-border px-5 py-5">
          <Link to="/profile" className="flex items-baseline gap-0.5" onClick={close}>
            <span className="font-display text-3xl font-black tracking-wider text-foreground">AOG</span>
            <span className="font-display text-3xl font-black text-primary text-glow">.</span>
          </Link>
          <p className="mt-1 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Competitive command center</p>
        </div>

        <nav className="flex-1 space-y-1 px-3 py-4">
          {STATIC_NAV.map(({ to, label, icon: Icon, exact }) => (
            <Link key={to} to={to} activeOptions={{ exact }} onClick={close} className={NAV_LINK_CLS} activeProps={NAV_ACTIVE}>
              <Icon className="h-5 w-5" />
              <span>{label}</span>
            </Link>
          ))}
          {myTeamId ? (
            <Link to="/teams/$teamId" params={{ teamId: myTeamId }} onClick={close} className={NAV_LINK_CLS} activeProps={NAV_ACTIVE}>
              <Users className="h-5 w-5" />
              <span>My Team</span>
            </Link>
          ) : (
            <Link to="/teams" onClick={close} className={NAV_LINK_CLS} activeProps={NAV_ACTIVE}>
              <Users className="h-5 w-5" />
              <span>My Team</span>
            </Link>
          )}
          {POST_TEAM_NAV.map(({ to, label, icon: Icon, exact }) => (
            <Link key={to} to={to} activeOptions={{ exact }} onClick={close} className={NAV_LINK_CLS} activeProps={NAV_ACTIVE}>
              <Icon className="h-5 w-5" />
              <span>{label}</span>
            </Link>
          ))}
          {isAdmin && (
            <Link to="/admin" onClick={close} className={NAV_LINK_CLS} activeProps={NAV_ACTIVE}>
              <Shield className="h-5 w-5" />
              <span>Admin</span>
            </Link>
          )}
        </nav>

        <div className="space-y-3 border-t border-border p-4">
          {profile && (
            <Link to="/profile" onClick={() => setOpen(false)} className="flex items-center gap-3 rounded-lg border border-border bg-background/50 p-3 transition-colors hover:border-primary/40">
              <UserAvatar username={username} gender={(profile as any).gender} size="sm" />
              <div className="min-w-0 flex-1">
                <div className="truncate font-display text-sm font-bold text-foreground">{username}</div>
                <div className="truncate font-mono text-[10px] uppercase text-muted-foreground">UID: {uid}</div>
              </div>
            </Link>
          )}
          <button
            onClick={handleSignOut}
            className="flex w-full items-center justify-center gap-2 rounded-md border border-border bg-card px-3 py-2.5 text-sm font-semibold uppercase tracking-wider text-foreground transition-all hover:border-primary/50 hover:bg-accent"
          >
            <LogOut className="h-4 w-4" />
            Log Out
          </button>
        </div>
      </aside>

      {open && <div onClick={() => setOpen(false)} className="fixed inset-0 z-30 bg-background/80 backdrop-blur-sm md:hidden" />}

      <main className="flex-1 min-w-0 px-4 py-16 md:px-8 md:py-8">
        {children}
      </main>
    </div>
  );
}
