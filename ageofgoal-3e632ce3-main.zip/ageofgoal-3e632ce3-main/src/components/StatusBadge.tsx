import { cn } from "@/lib/utils";
import type { Database } from "@/integrations/supabase/types";

type Status = Database["public"]["Enums"]["verification_status"];

const config: Record<Status, { label: string; className: string }> = {
  approved: {
    label: "VERIFIED",
    className: "bg-success/15 text-success border-success/40 shadow-[0_0_12px_-2px_oklch(0.7_0.18_150/0.5)]",
  },
  pending: {
    label: "PENDING",
    className: "bg-warning/15 text-warning border-warning/40 shadow-[0_0_12px_-2px_oklch(0.82_0.17_90/0.5)]",
  },
  rejected: {
    label: "REJECTED",
    className: "bg-destructive/15 text-destructive border-destructive/40 shadow-[0_0_12px_-2px_oklch(0.62_0.24_25/0.5)]",
  },
};

export function StatusBadge({ status, className }: { status: Status; className?: string }) {
  const c = config[status];
  return (
    <span
      className={cn(
        "inline-flex items-center rounded border px-2 py-0.5 font-display text-[10px] font-bold uppercase tracking-widest",
        c.className,
        className,
      )}
    >
      {c.label}
    </span>
  );
}
