import ffUidCard from "@/assets/ff-uid-card.png";
import { Copy, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { FF_FRIEND_UID } from "@/lib/region";

export function FFUidCard() {
  const copy = () => {
    navigator.clipboard.writeText(FF_FRIEND_UID);
    toast.success("UID copied!");
  };
  return (
    <div className="rounded-xl border-2 border-primary/40 bg-gradient-to-br from-primary/10 via-card to-background p-4 card-glow">
      <div className="flex items-start gap-2 text-sm">
        <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
        <div className="font-display font-bold uppercase tracking-wider text-foreground">
          Required Step — Send Friend Request
        </div>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">
        To get verified, send a Free Fire friend request to the AOG admin account below.
      </p>
      <img
        src={ffUidCard}
        alt={`Free Fire UID ${FF_FRIEND_UID}`}
        className="mx-auto mt-3 h-auto w-full max-w-sm"
        loading="lazy"
        width={1264}
        height={848}
      />
      <button
        type="button"
        onClick={copy}
        className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg border border-primary/40 bg-primary/10 px-4 py-2.5 font-display text-sm font-bold uppercase tracking-wider text-primary hover:bg-primary/20 transition-colors"
      >
        <Copy className="h-4 w-4" />
        <span className="font-mono">{FF_FRIEND_UID}</span>
      </button>
    </div>
  );
}
