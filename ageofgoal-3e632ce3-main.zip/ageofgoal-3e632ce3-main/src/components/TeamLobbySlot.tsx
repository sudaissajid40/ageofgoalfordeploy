import { Crown, Plus, ArrowRightLeft, UserMinus, Snowflake, Sun, ShieldCheck, ShieldOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import maleA from "@/assets/characters/character-male-1.jpg";
import maleB from "@/assets/characters/character-male-2.jpg";
import maleC from "@/assets/characters/character-male-3.jpg";
import maleD from "@/assets/characters/character-male-4.jpg";
import maleE from "@/assets/characters/character-male-5.jpg";
import maleF from "@/assets/characters/character-male-6.jpg";
import femA from "@/assets/characters/character-female-1.jpg";
import femB from "@/assets/characters/character-female-2.jpg";
import femC from "@/assets/characters/character-female-3.jpg";
import femD from "@/assets/characters/character-female-4.jpg";
import femE from "@/assets/characters/character-female-5.jpg";
import femF from "@/assets/characters/character-female-6.jpg";

const MALE = [maleA, maleB, maleC, maleD, maleE, maleF];
const FEMALE = [femA, femB, femC, femD, femE, femF];

export function pickCharacter(gender: string | null | undefined, slot: number) {
  const i = slot % 6;
  if (gender === "female") return FEMALE[i];
  return MALE[i];
}

interface MemberSlotProps {
  slot: number;
  username: string;
  level?: number | null;
  gender?: string | null;
  isOwner?: boolean;
  canTransfer?: boolean;
  onTransfer?: () => void;
  canKick?: boolean;
  onKick?: () => void;
  canFreeze?: boolean;
  isFrozen?: boolean;
  onToggleFreeze?: () => void;
  canToggleRegister?: boolean;
  isRegistrar?: boolean;
  onToggleRegister?: () => void;
}

export function MemberSlot({ slot, username, level, gender, isOwner, canTransfer, onTransfer, canKick, onKick, canFreeze, isFrozen, onToggleFreeze, canToggleRegister, isRegistrar, onToggleRegister }: MemberSlotProps) {
  const src = pickCharacter(gender, slot);
  return (
    <div className="group relative overflow-hidden rounded-xl border border-primary/30 bg-gradient-to-b from-card via-card to-background card-glow">
      {isOwner && (
        <div className="absolute right-2 top-2 z-10 rounded-md border border-warning/50 bg-warning/15 px-2 py-1 backdrop-blur-sm">
          <Crown className="h-3.5 w-3.5 text-warning" />
        </div>
      )}
      {isFrozen && !isOwner && (
        <div className="absolute left-2 top-2 z-10 rounded-md border border-accent bg-accent/30 px-2 py-1 backdrop-blur-sm" title="Invites frozen">
          <Snowflake className="h-3.5 w-3.5 text-accent-foreground" />
        </div>
      )}
      <div className="aspect-[3/4] w-full overflow-hidden bg-gradient-to-b from-primary/10 to-background">
        <img src={src} alt={username} className="h-full w-full object-cover object-top transition-transform group-hover:scale-105" loading="lazy" width={512} height={768} />
      </div>
      <div className="border-t border-primary/20 bg-card/95 p-3">
        <div className="truncate font-display text-sm font-bold uppercase tracking-wide text-foreground">{username}</div>
        <div className="mt-0.5 font-mono text-[10px] uppercase text-muted-foreground">Lv {level ?? "?"} · Slot {slot + 1}</div>
        {canTransfer && (
          <Button size="sm" variant="outline" className="mt-2 h-7 w-full text-[10px]" onClick={onTransfer}>
            <ArrowRightLeft className="mr-1 h-3 w-3" /> Transfer
          </Button>
        )}
        {canFreeze && (
          <Button size="sm" variant="outline" className="mt-2 h-7 w-full text-[10px]" onClick={onToggleFreeze}>
            {isFrozen ? <><Sun className="mr-1 h-3 w-3" /> Unfreeze invites</> : <><Snowflake className="mr-1 h-3 w-3" /> Freeze invites</>}
          </Button>
        )}
        {canToggleRegister && (
          <Button size="sm" variant="outline" className="mt-2 h-7 w-full text-[10px]" onClick={onToggleRegister}>
            {isRegistrar ? <><ShieldOff className="mr-1 h-3 w-3" /> Revoke register</> : <><ShieldCheck className="mr-1 h-3 w-3" /> Allow register</>}
          </Button>
        )}
        {(isOwner || isRegistrar) && (
          <div className="mt-2 inline-flex items-center gap-1 rounded border border-primary/30 bg-primary/10 px-2 py-0.5 text-[9px] uppercase text-primary">
            <ShieldCheck className="h-3 w-3" /> {isOwner ? "Owner" : "Registrar"}
          </div>
        )}
        {canKick && (
          <Button size="sm" variant="destructive" className="mt-2 h-7 w-full text-[10px]" onClick={onKick}>
            <UserMinus className="mr-1 h-3 w-3" /> Kick
          </Button>
        )}
      </div>
    </div>
  );
}

export function EmptySlot({ slot, onClick, label = "Empty" }: { slot: number; onClick?: () => void; label?: string }) {
  const Inner = (
    <>
      <div className="flex aspect-[3/4] w-full items-center justify-center bg-gradient-to-b from-muted/20 to-background">
        <div className="flex h-14 w-14 items-center justify-center rounded-full border-2 border-dashed border-muted-foreground/40 text-muted-foreground/60">
          <Plus className="h-6 w-6" />
        </div>
      </div>
      <div className="border-t border-dashed border-border bg-card/40 p-3">
        <div className="truncate font-display text-sm font-bold uppercase tracking-wide text-muted-foreground">{label}</div>
        <div className="mt-0.5 font-mono text-[10px] uppercase text-muted-foreground/70">Slot {slot + 1}</div>
      </div>
    </>
  );
  if (onClick) {
    return (
      <button onClick={onClick} className="overflow-hidden rounded-xl border border-dashed border-border bg-card/40 text-left transition-colors hover:border-primary/50 hover:bg-primary/5">
        {Inner}
      </button>
    );
  }
  return <div className="overflow-hidden rounded-xl border border-dashed border-border bg-card/40">{Inner}</div>;
}
