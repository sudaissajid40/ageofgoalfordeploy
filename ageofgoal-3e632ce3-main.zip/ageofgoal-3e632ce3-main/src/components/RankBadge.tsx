import { Shield, Medal, Star, Gem, Flame, Crown } from "lucide-react";
import { getTier, type RankTier } from "@/lib/rank";
import { cn } from "@/lib/utils";

const ICONS: Record<RankTier["icon"], typeof Shield> = {
  shield: Shield,
  medal: Medal,
  star: Star,
  gem: Gem,
  flame: Flame,
  crown: Crown,
};

interface Props {
  points: number;
  size?: "sm" | "md" | "lg";
  showPoints?: boolean;
  className?: string;
}

export function RankBadge({ points, size = "md", showPoints = true, className }: Props) {
  const tier = getTier(points);
  const Icon = ICONS[tier.icon];

  const sizes = {
    sm: { wrap: "px-2 py-1 gap-1.5 text-[10px]", icon: "h-3 w-3", pts: "text-[10px]" },
    md: { wrap: "px-3 py-1.5 gap-2 text-xs", icon: "h-4 w-4", pts: "text-[11px]" },
    lg: { wrap: "px-4 py-2 gap-2.5 text-sm", icon: "h-5 w-5", pts: "text-xs" },
  }[size];

  return (
    <div
      className={cn(
        "inline-flex items-center rounded-md border font-display font-bold uppercase tracking-wider",
        sizes.wrap,
        className,
      )}
      style={{
        color: tier.hex,
        borderColor: `${tier.hex}55`,
        background: `linear-gradient(135deg, ${tier.hex}10, transparent)`,
        boxShadow: `0 0 16px -4px ${tier.hex}55, inset 0 0 12px -4px ${tier.hex}30`,
      }}
    >
      <Icon className={sizes.icon} style={{ color: tier.hex }} />
      <span>{tier.name}</span>
      {showPoints && (
        <span className={cn("font-mono opacity-80", sizes.pts)}>{points} pts</span>
      )}
    </div>
  );
}
