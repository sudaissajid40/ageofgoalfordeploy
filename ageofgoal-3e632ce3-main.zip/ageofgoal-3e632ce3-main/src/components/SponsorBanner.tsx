import { ExternalLink, Megaphone } from "lucide-react";

export interface SponsorInfo {
  sponsor_name: string | null;
  sponsor_hook: string | null;
  sponsor_cta_label: string | null;
  sponsor_cta_url: string | null;
  sponsor_banner_url: string | null;
}

function safeUrl(u: string | null): string | null {
  if (!u) return null;
  try {
    const parsed = new URL(u);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return null;
    return parsed.toString();
  } catch { return null; }
}

export function SponsorBanner({ s }: { s: SponsorInfo }) {
  if (!s.sponsor_name && !s.sponsor_banner_url) return null;
  const url = safeUrl(s.sponsor_cta_url);
  return (
    <div className="overflow-hidden rounded-xl border border-primary/30 bg-card">
      {s.sponsor_banner_url && (
        <img src={s.sponsor_banner_url} alt={s.sponsor_name ?? "Sponsor"} className="max-h-44 w-full object-cover" loading="lazy" />
      )}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4">
        <div className="min-w-0">
          <div className="flex items-center gap-1 text-[10px] uppercase tracking-widest text-muted-foreground">
            <Megaphone className="h-3 w-3" /> Sponsored by
          </div>
          <div className="font-display text-lg font-bold text-foreground">{s.sponsor_name ?? "Brand"}</div>
          {s.sponsor_hook && <p className="mt-1 text-sm text-muted-foreground">{s.sponsor_hook}</p>}
        </div>
        {url && (
          <a href={url} target="_blank" rel="noopener noreferrer"
            className="inline-flex items-center gap-1 rounded-md border border-primary/40 bg-primary/10 px-3 py-2 text-sm font-bold uppercase tracking-wider text-primary hover:bg-primary/20">
            {s.sponsor_cta_label ?? "Learn more"} <ExternalLink className="h-3.5 w-3.5" />
          </a>
        )}
      </div>
    </div>
  );
}
