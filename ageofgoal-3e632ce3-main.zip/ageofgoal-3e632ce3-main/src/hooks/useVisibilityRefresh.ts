import { useEffect, useRef } from "react";

/**
 * Calls `fn` when the tab becomes visible again or the window regains focus,
 * throttled so we don't refetch on every tiny focus blip. Default minimum gap
 * between refreshes is 15 seconds — keeps the app feeling fast and avoids the
 * "every tab switch causes a full reload" feeling.
 */
export function useVisibilityRefresh(
  fn: () => void | Promise<void>,
  deps: unknown[] = [],
  minIntervalMs = 15_000,
) {
  const lastRunRef = useRef(0);
  useEffect(() => {
    const handler = () => {
      if (document.visibilityState !== "visible") return;
      const now = Date.now();
      if (now - lastRunRef.current < minIntervalMs) return;
      lastRunRef.current = now;
      void fn();
    };
    document.addEventListener("visibilitychange", handler);
    window.addEventListener("focus", handler);
    return () => {
      document.removeEventListener("visibilitychange", handler);
      window.removeEventListener("focus", handler);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
}
