import { useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";

/**
 * Subscribe to postgres changes on a list of tables and call `reload`
 * whenever any of them changes. Throttled so a burst of updates doesn't
 * trigger a flood of refetches.
 */
export function useRealtimeRefresh(
  tables: string[],
  reload: () => void | Promise<void>,
  throttleMs = 800,
) {
  const lastRunRef = useRef(0);
  const pendingRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (tables.length === 0) return;

    const trigger = () => {
      const now = Date.now();
      const elapsed = now - lastRunRef.current;
      if (elapsed >= throttleMs) {
        lastRunRef.current = now;
        void reload();
      } else if (!pendingRef.current) {
        pendingRef.current = setTimeout(() => {
          pendingRef.current = null;
          lastRunRef.current = Date.now();
          void reload();
        }, throttleMs - elapsed);
      }
    };

    const channelName = `live-${tables.join("-")}-${Math.random().toString(36).slice(2, 7)}`;
    let channel = supabase.channel(channelName);

    for (const table of tables) {
      // supabase-js postgres_changes typing is loose; cast to any for the filter
      channel = (channel as any).on(
        "postgres_changes",
        { event: "*", schema: "public", table },
        trigger,
      );
    }

    channel.subscribe();

    return () => {
      if (pendingRef.current) {
        clearTimeout(pendingRef.current);
        pendingRef.current = null;
      }
      void supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tables.join("|")]);
}
