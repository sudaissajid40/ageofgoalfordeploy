import { useEffect } from "react";

/**
 * Auto-closes the "Edit with Lovable" badge on published deployments.
 * Repeatedly looks for the badge in the DOM and removes it as soon as it appears.
 */
export function useAutoCloseBadge() {
  useEffect(() => {
    const SELECTORS = [
      "#lovable-badge",
      "[data-lovable-badge]",
      'a[href*="lovable.dev"][target="_blank"]',
      'a[href*="lovable.app"][target="_blank"]',
    ];

    const removeBadge = () => {
      for (const sel of SELECTORS) {
        document.querySelectorAll(sel).forEach((el) => {
          const node = el as HTMLElement;
          // Walk up to a reasonable container (badge is often wrapped)
          const container = node.closest("[id*='lovable'], [class*='lovable']") as HTMLElement | null;
          (container ?? node).remove();
        });
      }
    };

    removeBadge();

    const observer = new MutationObserver(() => removeBadge());
    observer.observe(document.body, { childList: true, subtree: true });

    const interval = window.setInterval(removeBadge, 1000);

    return () => {
      observer.disconnect();
      window.clearInterval(interval);
    };
  }, []);
}
