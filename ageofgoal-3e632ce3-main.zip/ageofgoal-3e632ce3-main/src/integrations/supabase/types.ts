export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      match_players: {
        Row: {
          id: string
          joined_at: string | null
          match_id: string
          team_id: string
          user_id: string
        }
        Insert: {
          id?: string
          joined_at?: string | null
          match_id: string
          team_id: string
          user_id: string
        }
        Update: {
          id?: string
          joined_at?: string | null
          match_id?: string
          team_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "match_players_match_id_fkey"
            columns: ["match_id"]
            isOneToOne: false
            referencedRelation: "tournament_matches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "match_players_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          action_url: string | null
          actor_id: string | null
          created_at: string
          id: string
          message: string
          metadata: Json
          read_at: string | null
          recipient_id: string
          status: Database["public"]["Enums"]["notification_status"]
          title: string
          type: Database["public"]["Enums"]["notification_type"]
        }
        Insert: {
          action_url?: string | null
          actor_id?: string | null
          created_at?: string
          id?: string
          message: string
          metadata?: Json
          read_at?: string | null
          recipient_id: string
          status?: Database["public"]["Enums"]["notification_status"]
          title: string
          type?: Database["public"]["Enums"]["notification_type"]
        }
        Update: {
          action_url?: string | null
          actor_id?: string | null
          created_at?: string
          id?: string
          message?: string
          metadata?: Json
          read_at?: string | null
          recipient_id?: string
          status?: Database["public"]["Enums"]["notification_status"]
          title?: string
          type?: Database["public"]["Enums"]["notification_type"]
        }
        Relationships: []
      }
      payment_submissions: {
        Row: {
          admin_note: string | null
          amount: number
          created_at: string
          id: string
          receipt_url: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: Database["public"]["Enums"]["payment_status"]
          team_id: string | null
          tournament_id: string
          user_id: string
        }
        Insert: {
          admin_note?: string | null
          amount?: number
          created_at?: string
          id?: string
          receipt_url: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: Database["public"]["Enums"]["payment_status"]
          team_id?: string | null
          tournament_id: string
          user_id: string
        }
        Update: {
          admin_note?: string | null
          amount?: number
          created_at?: string
          id?: string
          receipt_url?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: Database["public"]["Enums"]["payment_status"]
          team_id?: string | null
          tournament_id?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          age: number | null
          aog_points: number
          city: string | null
          created_at: string
          edit_count: number
          ff_uid: string | null
          ff_username: string | null
          gender: Database["public"]["Enums"]["gender"] | null
          id: string
          last_edit_at: string | null
          level: number | null
          onboarding_step: number
          play_style: string | null
          preferred_mode: string | null
          profile_completed: boolean
          profile_note: string | null
          region: Database["public"]["Enums"]["region"] | null
          rejection_reason: string | null
          updated_at: string
          username: string | null
          verification_status: Database["public"]["Enums"]["verification_status"]
        }
        Insert: {
          age?: number | null
          aog_points?: number
          city?: string | null
          created_at?: string
          edit_count?: number
          ff_uid?: string | null
          ff_username?: string | null
          gender?: Database["public"]["Enums"]["gender"] | null
          id: string
          last_edit_at?: string | null
          level?: number | null
          onboarding_step?: number
          play_style?: string | null
          preferred_mode?: string | null
          profile_completed?: boolean
          profile_note?: string | null
          region?: Database["public"]["Enums"]["region"] | null
          rejection_reason?: string | null
          updated_at?: string
          username?: string | null
          verification_status?: Database["public"]["Enums"]["verification_status"]
        }
        Update: {
          age?: number | null
          aog_points?: number
          city?: string | null
          created_at?: string
          edit_count?: number
          ff_uid?: string | null
          ff_username?: string | null
          gender?: Database["public"]["Enums"]["gender"] | null
          id?: string
          last_edit_at?: string | null
          level?: number | null
          onboarding_step?: number
          play_style?: string | null
          preferred_mode?: string | null
          profile_completed?: boolean
          profile_note?: string | null
          region?: Database["public"]["Enums"]["region"] | null
          rejection_reason?: string | null
          updated_at?: string
          username?: string | null
          verification_status?: Database["public"]["Enums"]["verification_status"]
        }
        Relationships: []
      }
      push_subscriptions: {
        Row: {
          auth: string
          created_at: string
          endpoint: string
          id: string
          p256dh: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          auth: string
          created_at?: string
          endpoint: string
          id?: string
          p256dh: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          auth?: string
          created_at?: string
          endpoint?: string
          id?: string
          p256dh?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      team_invitations: {
        Row: {
          created_at: string
          id: string
          invited_by: string
          invited_user_id: string
          message: string | null
          responded_at: string | null
          status: Database["public"]["Enums"]["invitation_status"]
          team_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          invited_by: string
          invited_user_id: string
          message?: string | null
          responded_at?: string | null
          status?: Database["public"]["Enums"]["invitation_status"]
          team_id: string
        }
        Update: {
          created_at?: string
          id?: string
          invited_by?: string
          invited_user_id?: string
          message?: string | null
          responded_at?: string | null
          status?: Database["public"]["Enums"]["invitation_status"]
          team_id?: string
        }
        Relationships: []
      }
      team_join_requests: {
        Row: {
          created_at: string
          id: string
          status: Database["public"]["Enums"]["join_request_status"]
          team_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          status?: Database["public"]["Enums"]["join_request_status"]
          team_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          status?: Database["public"]["Enums"]["join_request_status"]
          team_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "team_join_requests_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
        ]
      }
      team_members: {
        Row: {
          can_register: boolean
          id: string
          invite_frozen: boolean
          joined_at: string
          team_id: string
          user_id: string
        }
        Insert: {
          can_register?: boolean
          id?: string
          invite_frozen?: boolean
          joined_at?: string
          team_id: string
          user_id: string
        }
        Update: {
          can_register?: boolean
          id?: string
          invite_frozen?: boolean
          joined_at?: string
          team_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "team_members_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
        ]
      }
      team_ownership_transfers: {
        Row: {
          created_at: string
          current_owner_id: string
          id: string
          proposed_owner_id: string
          responded_at: string | null
          status: Database["public"]["Enums"]["ownership_transfer_status"]
          team_id: string
        }
        Insert: {
          created_at?: string
          current_owner_id: string
          id?: string
          proposed_owner_id: string
          responded_at?: string | null
          status?: Database["public"]["Enums"]["ownership_transfer_status"]
          team_id: string
        }
        Update: {
          created_at?: string
          current_owner_id?: string
          id?: string
          proposed_owner_id?: string
          responded_at?: string | null
          status?: Database["public"]["Enums"]["ownership_transfer_status"]
          team_id?: string
        }
        Relationships: []
      }
      teams: {
        Row: {
          aog_points: number
          created_at: string
          id: string
          join_code: string
          name: string
          owner_id: string
          region: Database["public"]["Enums"]["region"] | null
          team_level: number
        }
        Insert: {
          aog_points?: number
          created_at?: string
          id?: string
          join_code: string
          name: string
          owner_id: string
          region?: Database["public"]["Enums"]["region"] | null
          team_level?: number
        }
        Update: {
          aog_points?: number
          created_at?: string
          id?: string
          join_code?: string
          name?: string
          owner_id?: string
          region?: Database["public"]["Enums"]["region"] | null
          team_level?: number
        }
        Relationships: []
      }
      tournament_matches: {
        Row: {
          created_at: string
          id: string
          match_number: number
          room_id: string | null
          room_password: string | null
          round: Database["public"]["Enums"]["match_round"]
          scheduled_at: string
          spectator_link: string | null
          status: Database["public"]["Enums"]["match_status"]
          team_a_id: string | null
          team_b_id: string | null
          tournament_id: string
          updated_at: string
          winner_team_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          match_number: number
          room_id?: string | null
          room_password?: string | null
          round?: Database["public"]["Enums"]["match_round"]
          scheduled_at: string
          spectator_link?: string | null
          status?: Database["public"]["Enums"]["match_status"]
          team_a_id?: string | null
          team_b_id?: string | null
          tournament_id: string
          updated_at?: string
          winner_team_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          match_number?: number
          room_id?: string | null
          room_password?: string | null
          round?: Database["public"]["Enums"]["match_round"]
          scheduled_at?: string
          spectator_link?: string | null
          status?: Database["public"]["Enums"]["match_status"]
          team_a_id?: string | null
          team_b_id?: string | null
          tournament_id?: string
          updated_at?: string
          winner_team_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tournament_matches_team_a_id_fkey"
            columns: ["team_a_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tournament_matches_team_b_id_fkey"
            columns: ["team_b_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tournament_matches_tournament_id_fkey"
            columns: ["tournament_id"]
            isOneToOne: false
            referencedRelation: "tournaments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tournament_matches_winner_team_id_fkey"
            columns: ["winner_team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
        ]
      }
      tournament_registrations: {
        Row: {
          created_at: string
          id: string
          participant_id: string
          participant_type: Database["public"]["Enums"]["participant_type"]
          placement: number | null
          points_awarded: number | null
          registered_by: string
          tournament_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          participant_id: string
          participant_type: Database["public"]["Enums"]["participant_type"]
          placement?: number | null
          points_awarded?: number | null
          registered_by: string
          tournament_id: string
        }
        Update: {
          created_at?: string
          id?: string
          participant_id?: string
          participant_type?: Database["public"]["Enums"]["participant_type"]
          placement?: number | null
          points_awarded?: number | null
          registered_by?: string
          tournament_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tournament_registrations_tournament_id_fkey"
            columns: ["tournament_id"]
            isOneToOne: false
            referencedRelation: "tournaments"
            referencedColumns: ["id"]
          },
        ]
      }
      tournament_schedule_proposals: {
        Row: {
          created_at: string
          description: string | null
          id: string
          label: string
          matches: Json
          tournament_id: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          label: string
          matches: Json
          tournament_id: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          label?: string
          matches?: Json
          tournament_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tournament_schedule_proposals_tournament_id_fkey"
            columns: ["tournament_id"]
            isOneToOne: false
            referencedRelation: "tournaments"
            referencedColumns: ["id"]
          },
        ]
      }
      tournaments: {
        Row: {
          bracket_size: number | null
          champion_points_multiplier: number
          created_at: string
          created_by: string
          description: string | null
          entry_fee: number
          id: string
          match_team_size: number
          max_participants: number | null
          max_team_members: number
          min_team_members: number
          name: string
          payment_account_label: string | null
          payment_account_number: string | null
          payment_instructions: string | null
          point_payouts: Json
          points_per_match_win: number
          registration_ends_at: string | null
          rules: string | null
          selected_schedule_id: string | null
          sponsor_banner_url: string | null
          sponsor_cta_label: string | null
          sponsor_cta_url: string | null
          sponsor_hook: string | null
          sponsor_name: string | null
          starts_at: string
          status: Database["public"]["Enums"]["tournament_status"]
          thumbnail_url: string | null
          type: Database["public"]["Enums"]["tournament_type"]
        }
        Insert: {
          bracket_size?: number | null
          champion_points_multiplier?: number
          created_at?: string
          created_by: string
          description?: string | null
          entry_fee?: number
          id?: string
          match_team_size?: number
          max_participants?: number | null
          max_team_members?: number
          min_team_members?: number
          name: string
          payment_account_label?: string | null
          payment_account_number?: string | null
          payment_instructions?: string | null
          point_payouts?: Json
          points_per_match_win?: number
          registration_ends_at?: string | null
          rules?: string | null
          selected_schedule_id?: string | null
          sponsor_banner_url?: string | null
          sponsor_cta_label?: string | null
          sponsor_cta_url?: string | null
          sponsor_hook?: string | null
          sponsor_name?: string | null
          starts_at: string
          status?: Database["public"]["Enums"]["tournament_status"]
          thumbnail_url?: string | null
          type: Database["public"]["Enums"]["tournament_type"]
        }
        Update: {
          bracket_size?: number | null
          champion_points_multiplier?: number
          created_at?: string
          created_by?: string
          description?: string | null
          entry_fee?: number
          id?: string
          match_team_size?: number
          max_participants?: number | null
          max_team_members?: number
          min_team_members?: number
          name?: string
          payment_account_label?: string | null
          payment_account_number?: string | null
          payment_instructions?: string | null
          point_payouts?: Json
          points_per_match_win?: number
          registration_ends_at?: string | null
          rules?: string | null
          selected_schedule_id?: string | null
          sponsor_banner_url?: string | null
          sponsor_cta_label?: string | null
          sponsor_cta_url?: string | null
          sponsor_hook?: string | null
          sponsor_name?: string | null
          starts_at?: string
          status?: Database["public"]["Enums"]["tournament_status"]
          thumbnail_url?: string | null
          type?: Database["public"]["Enums"]["tournament_type"]
        }
        Relationships: [
          {
            foreignKeyName: "tournaments_selected_schedule_fk"
            columns: ["selected_schedule_id"]
            isOneToOne: false
            referencedRelation: "tournament_schedule_proposals"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      analytics_age_buckets: {
        Args: never
        Returns: {
          bucket: string
          count: number
        }[]
      }
      analytics_gender_breakdown: {
        Args: never
        Returns: {
          count: number
          gender: string
        }[]
      }
      analytics_level_buckets: {
        Args: never
        Returns: {
          bucket: string
          count: number
        }[]
      }
      analytics_participation_rate: {
        Args: never
        Returns: {
          participants: number
          rate: number
          verified_users: number
        }[]
      }
      analytics_play_style_breakdown: {
        Args: never
        Returns: {
          count: number
          style: string
        }[]
      }
      analytics_region_breakdown: {
        Args: never
        Returns: {
          count: number
          region: string
          total_points: number
        }[]
      }
      analytics_signups_by_day: {
        Args: { _days?: number }
        Returns: {
          day: string
          signups: number
        }[]
      }
      analytics_team_size_distribution: {
        Args: never
        Returns: {
          size: number
          team_count: number
        }[]
      }
      analytics_verification_breakdown: {
        Args: never
        Returns: {
          count: number
          status: string
        }[]
      }
      award_match_win: {
        Args: { _match_id: string; _winner_team_id: string }
        Returns: undefined
      }
      award_tournament_points: {
        Args: { _tournament_id: string }
        Returns: undefined
      }
      can_join_match: {
        Args: { _match_id: string; _user_id: string }
        Returns: boolean
      }
      can_view_match_room: { Args: { _match_id: string }; Returns: boolean }
      create_notification: {
        Args: {
          _action_url?: string
          _actor_id: string
          _message: string
          _metadata?: Json
          _recipient_id: string
          _title: string
          _type: Database["public"]["Enums"]["notification_type"]
        }
        Returns: string
      }
      crown_tournament_champion: {
        Args: { _tournament_id: string; _winner_team_id: string }
        Returns: undefined
      }
      get_match_room: {
        Args: { _match_id: string }
        Returns: {
          room_id: string
          room_password: string
        }[]
      }
      get_tournament_standings: {
        Args: { _tournament_id: string }
        Returns: {
          points: number
          team_id: string
          team_name: string
          wins: number
        }[]
      }
      get_user_email: { Args: { _user_id: string }; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_verified: { Args: { _user_id: string }; Returns: boolean }
      recompute_team_level: { Args: { _team_id: string }; Returns: undefined }
      replace_tournament_schedule: {
        Args: { _proposal_id: string; _tournament_id: string }
        Returns: undefined
      }
      seed_knockout_bracket: {
        Args: { _tournament_id: string }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "admin" | "user"
      gender: "male" | "female" | "other" | "prefer_not_to_say"
      invitation_status: "pending" | "accepted" | "rejected" | "cancelled"
      join_request_status: "pending" | "approved" | "rejected"
      match_round: "group" | "quarter" | "semi" | "final"
      match_status: "scheduled" | "live" | "completed" | "cancelled"
      notification_status: "unread" | "read" | "archived"
      notification_type:
        | "team_invite"
        | "team_request"
        | "request_decision"
        | "ownership_transfer"
        | "tournament"
        | "admin_broadcast"
        | "verification"
        | "match_update"
        | "system"
      ownership_transfer_status:
        | "pending"
        | "accepted"
        | "rejected"
        | "cancelled"
      participant_type: "user" | "team"
      payment_status: "pending" | "approved" | "rejected"
      region: "punjab" | "sindh" | "balochistan" | "kpk"
      tournament_status: "upcoming" | "live" | "completed"
      tournament_type: "solo" | "team"
      verification_status: "pending" | "approved" | "rejected"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
      gender: ["male", "female", "other", "prefer_not_to_say"],
      invitation_status: ["pending", "accepted", "rejected", "cancelled"],
      join_request_status: ["pending", "approved", "rejected"],
      match_round: ["group", "quarter", "semi", "final"],
      match_status: ["scheduled", "live", "completed", "cancelled"],
      notification_status: ["unread", "read", "archived"],
      notification_type: [
        "team_invite",
        "team_request",
        "request_decision",
        "ownership_transfer",
        "tournament",
        "admin_broadcast",
        "verification",
        "match_update",
        "system",
      ],
      ownership_transfer_status: [
        "pending",
        "accepted",
        "rejected",
        "cancelled",
      ],
      participant_type: ["user", "team"],
      payment_status: ["pending", "approved", "rejected"],
      region: ["punjab", "sindh", "balochistan", "kpk"],
      tournament_status: ["upcoming", "live", "completed"],
      tournament_type: ["solo", "team"],
      verification_status: ["pending", "approved", "rejected"],
    },
  },
} as const
