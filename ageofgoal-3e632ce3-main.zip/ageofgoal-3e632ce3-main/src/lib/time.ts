// All times are stored in UTC in the database, but the AOG league operates
// from Lahore (Asia/Karachi). These helpers ensure every player and admin
// sees the same local clock, no matter where they are.

const TZ = "Asia/Karachi";
const LOCALE = "en-PK";

const dtf = (opts: Intl.DateTimeFormatOptions) =>
  new Intl.DateTimeFormat(LOCALE, { timeZone: TZ, ...opts });

export function formatPKTDateTime(input: string | number | Date | null | undefined): string {
  if (!input) return "—";
  const d = typeof input === "string" || typeof input === "number" ? new Date(input) : input;
  if (isNaN(d.getTime())) return "—";
  return dtf({
    year: "numeric", month: "short", day: "2-digit",
    hour: "2-digit", minute: "2-digit", hour12: true,
  }).format(d) + " PKT";
}

export function formatPKTDate(input: string | number | Date | null | undefined): string {
  if (!input) return "—";
  const d = typeof input === "string" || typeof input === "number" ? new Date(input) : input;
  if (isNaN(d.getTime())) return "—";
  return dtf({ year: "numeric", month: "short", day: "2-digit" }).format(d);
}

export function formatPKTTime(input: string | number | Date | null | undefined): string {
  if (!input) return "—";
  const d = typeof input === "string" || typeof input === "number" ? new Date(input) : input;
  if (isNaN(d.getTime())) return "—";
  return dtf({ hour: "2-digit", minute: "2-digit", hour12: true }).format(d) + " PKT";
}

/**
 * Convert a local PKT date (yyyy-mm-dd) + time (HH:mm) entered by an admin
 * into a UTC ISO string for storage. Asia/Karachi is a fixed +05:00 offset
 * (no DST), so we can append it directly.
 */
export function pktToUtcIso(dateStr: string, timeStr: string): string {
  if (!dateStr || !timeStr) return "";
  // dateStr: "2026-05-20", timeStr: "18:30"
  const iso = `${dateStr}T${timeStr}:00+05:00`;
  return new Date(iso).toISOString();
}

/** "yyyy-mm-dd" of today in PKT — handy default for date pickers. */
export function todayPKT(): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: TZ }).format(new Date());
}
