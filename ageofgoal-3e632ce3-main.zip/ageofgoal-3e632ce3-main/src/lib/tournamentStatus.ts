import type { Database } from "@/integrations/supabase/types";

type Tournament = Database["public"]["Tables"]["tournaments"]["Row"];

export type TStatusKind = "live" | "open" | "closed" | "completed";

export interface DisplayStatus {
  kind: TStatusKind;
  label: string;
  badgeClass: string;
  cta: string;
}

export function getTournamentDisplayStatus(t: Pick<Tournament, "status" | "registration_ends_at">): DisplayStatus {
  const now = Date.now();
  const regOpen = !t.registration_ends_at || Date.parse(t.registration_ends_at) > now;
  if (t.status === "live") {
    return { kind: "live", label: "Live now", badgeClass: "border-success/30 bg-success/10 text-success", cta: "Watch live" };
  }
  if (t.status === "completed") {
    return { kind: "completed", label: "Completed", badgeClass: "border-muted bg-muted text-muted-foreground", cta: "View results" };
  }
  if (regOpen) {
    return { kind: "open", label: "Registration open", badgeClass: "border-primary/30 bg-primary/10 text-primary", cta: "Join now" };
  }
  return { kind: "closed", label: "Registration closed", badgeClass: "border-warning/30 bg-warning/10 text-warning", cta: "View bracket" };
}
