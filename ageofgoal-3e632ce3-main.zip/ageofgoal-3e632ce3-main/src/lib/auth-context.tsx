import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type Profile = Database["public"]["Tables"]["profiles"]["Row"];
export type AppRole = Database["public"]["Enums"]["app_role"];

interface AuthContextValue {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  roles: AppRole[];
  isAdmin: boolean;
  isVerified: boolean;
  myTeamId: string | null;
  loading: boolean;
  refreshProfile: () => Promise<void>;
  refreshTeam: () => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [roles, setRoles] = useState<AppRole[]>([]);
  const [myTeamId, setMyTeamId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const loadProfileAndRoles = async (userId: string) => {
    const [{ data: prof }, { data: roleRows }, { data: tm }] = await Promise.all([
      supabase.from("profiles").select("*").eq("id", userId).maybeSingle(),
      supabase.from("user_roles").select("role").eq("user_id", userId),
      supabase.from("team_members").select("team_id").eq("user_id", userId).maybeSingle(),
    ]);
    setProfile(prof ?? null);
    setRoles((roleRows ?? []).map((r) => r.role));
    setMyTeamId((tm as { team_id: string } | null)?.team_id ?? null);
  };

  const refreshProfile = async () => {
    if (user) await loadProfileAndRoles(user.id);
  };

  const refreshTeam = async () => {
    if (!user) { setMyTeamId(null); return; }
    const { data } = await supabase.from("team_members").select("team_id").eq("user_id", user.id).maybeSingle();
    setMyTeamId((data as { team_id: string } | null)?.team_id ?? null);
  };

  useEffect(() => {
    let lastUserId: string | null = null;

    // Set listener BEFORE getSession (per Supabase guidance)
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
      setUser(newSession?.user ?? null);
      const newId = newSession?.user?.id ?? null;
      if (newId && newId !== lastUserId) {
        lastUserId = newId;
        // Defer to avoid deadlock
        setTimeout(() => {
          void loadProfileAndRoles(newId);
        }, 0);
      } else if (!newId) {
        lastUserId = null;
        setProfile(null);
        setRoles([]);
        setMyTeamId(null);
      }
    });

    void supabase.auth.getSession().then(({ data: { session: s } }) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) {
        lastUserId = s.user.id;
        void loadProfileAndRoles(s.user.id).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  const value: AuthContextValue = {
    user,
    session,
    profile,
    roles,
    isAdmin: roles.includes("admin"),
    isVerified: profile?.verification_status === "approved",
    myTeamId,
    loading,
    refreshProfile,
    refreshTeam,
    signOut,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
