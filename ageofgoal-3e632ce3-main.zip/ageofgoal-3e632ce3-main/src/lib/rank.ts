// Rank tier system based on AOG points
export type RankTier = {
  name: string;
  min: number;
  color: string;       // tailwind text color class fallback
  glow: string;        // box-shadow color (oklch)
  hex: string;         // CSS color
  icon: "shield" | "medal" | "star" | "gem" | "flame" | "crown";
};

export const TIERS: RankTier[] = [
  { name: "Rookie",      min: 0,     color: "text-zinc-400",   glow: "oklch(0.7 0.02 240)",  hex: "#a1a1aa", icon: "shield" },
  { name: "Bronze",      min: 100,   color: "text-orange-700", glow: "oklch(0.55 0.15 40)",  hex: "#c2660d", icon: "shield" },
  { name: "Silver",      min: 500,   color: "text-zinc-300",   glow: "oklch(0.85 0.01 240)", hex: "#d4d4d8", icon: "shield" },
  { name: "Gold",        min: 1500,  color: "text-yellow-400", glow: "oklch(0.85 0.18 90)",  hex: "#facc15", icon: "medal" },
  { name: "Platinum",    min: 3000,  color: "text-cyan-300",   glow: "oklch(0.85 0.15 195)", hex: "#67e8f9", icon: "star" },
  { name: "Diamond",     min: 5000,  color: "text-purple-300", glow: "oklch(0.7 0.2 295)",   hex: "#d8b4fe", icon: "gem" },
  { name: "Heroic",      min: 7500,  color: "text-orange-400", glow: "oklch(0.72 0.21 45)",  hex: "#fb923c", icon: "flame" },
  { name: "Grandmaster", min: 12000, color: "text-rose-400",   glow: "oklch(0.7 0.24 25)",   hex: "#fb7185", icon: "crown" },
];

export function getTier(points: number): RankTier {
  let current = TIERS[0];
  for (const t of TIERS) {
    if (points >= t.min) current = t;
  }
  return current;
}

export function getNextTier(points: number): RankTier | null {
  for (const t of TIERS) {
    if (points < t.min) return t;
  }
  return null;
}

export function getTierProgress(points: number): { pct: number; remaining: number; next: RankTier | null } {
  const current = getTier(points);
  const next = getNextTier(points);
  if (!next) return { pct: 100, remaining: 0, next: null };
  const span = next.min - current.min;
  const into = points - current.min;
  return { pct: Math.min(100, Math.round((into / span) * 100)), remaining: next.min - points, next };
}
