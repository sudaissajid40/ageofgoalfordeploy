export const REGIONS = ["punjab", "sindh", "balochistan", "kpk"] as const;
export type Region = typeof REGIONS[number];

export const REGION_LABEL: Record<Region, string> = {
  punjab: "Punjab",
  sindh: "Sindh",
  balochistan: "Balochistan",
  kpk: "KPK",
};

export const FF_FRIEND_UID = "15568897940";
export const FF_FRIEND_USERNAME = "age_of_goal";
