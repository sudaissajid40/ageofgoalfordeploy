
-- Faster admin loads of a tournament's matches in chronological order
CREATE INDEX IF NOT EXISTS idx_tournament_matches_t_sched
  ON public.tournament_matches(tournament_id, scheduled_at);

-- Admin RPC: replace all matches for a tournament from a chosen proposal
CREATE OR REPLACE FUNCTION public.replace_tournament_schedule(
  _tournament_id uuid,
  _proposal_id uuid
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  prop RECORD;
  m jsonb;
  v_round text;
  v_match_number int;
  v_team_a uuid;
  v_team_b uuid;
  v_scheduled timestamptz;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admins can apply a schedule';
  END IF;

  SELECT * INTO prop
  FROM public.tournament_schedule_proposals
  WHERE id = _proposal_id AND tournament_id = _tournament_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Proposal not found for this tournament';
  END IF;

  -- Wipe existing matches for this tournament (cascade-style replace)
  DELETE FROM public.tournament_matches WHERE tournament_id = _tournament_id;

  -- Insert each match from the proposal JSON
  FOR m IN SELECT * FROM jsonb_array_elements(prop.matches)
  LOOP
    v_round := COALESCE(NULLIF(m->>'round',''), 'group');
    v_match_number := COALESCE((m->>'match_number')::int, 1);
    v_team_a := NULLIF(m->>'team_a_id','')::uuid;
    v_team_b := NULLIF(m->>'team_b_id','')::uuid;
    v_scheduled := COALESCE((m->>'scheduled_at')::timestamptz, now() + interval '1 day');

    INSERT INTO public.tournament_matches (
      tournament_id, round, match_number, team_a_id, team_b_id, scheduled_at, status
    ) VALUES (
      _tournament_id, v_round::match_round, v_match_number, v_team_a, v_team_b, v_scheduled, 'scheduled'
    );
  END LOOP;

  UPDATE public.tournaments
  SET selected_schedule_id = _proposal_id
  WHERE id = _tournament_id;
END;
$$;
