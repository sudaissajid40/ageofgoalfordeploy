-- Allow team creation for users who don't have a team yet (even unverified during onboarding)
DROP POLICY IF EXISTS "Verified users create teams" ON public.teams;

CREATE POLICY "Users create teams"
ON public.teams
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = owner_id
  AND NOT EXISTS (
    SELECT 1 FROM public.team_members WHERE user_id = auth.uid()
  )
);

-- Update the team_members trigger to skip verification check for the team owner's auto-insert
CREATE OR REPLACE FUNCTION public.team_members_before_insert()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  member_count int;
  is_owner boolean;
BEGIN
  -- Check if this user is the team owner (auto-added on team creation)
  SELECT EXISTS(SELECT 1 FROM public.teams WHERE id = NEW.team_id AND owner_id = NEW.user_id) INTO is_owner;

  -- Verification only required for non-owners joining
  IF NOT is_owner AND NOT public.is_verified(NEW.user_id) THEN
    RAISE EXCEPTION 'User must be verified to join a team';
  END IF;

  IF EXISTS (SELECT 1 FROM public.team_members WHERE user_id = NEW.user_id) THEN
    RAISE EXCEPTION 'Player can only be in one team at a time';
  END IF;

  SELECT COUNT(*) INTO member_count FROM public.team_members WHERE team_id = NEW.team_id;
  IF member_count >= 6 THEN
    RAISE EXCEPTION 'Team is full (max 6 players)';
  END IF;

  IF NOT is_owner THEN
    IF NOT EXISTS (
      SELECT 1 FROM public.team_invitations
      WHERE team_id = NEW.team_id AND invited_user_id = NEW.user_id AND status = 'accepted'
    ) AND NOT EXISTS (
      SELECT 1 FROM public.team_join_requests
      WHERE team_id = NEW.team_id AND user_id = NEW.user_id AND status = 'approved'
    ) THEN
      RAISE EXCEPTION 'Team membership requires an accepted invite or approved request';
    END IF;
  END IF;

  RETURN NEW;
END;
$function$;

-- Update team_members INSERT RLS so owner auto-add works without verified check
DROP POLICY IF EXISTS "Members inserted by accepted flow" ON public.team_members;

CREATE POLICY "Members inserted by accepted flow"
ON public.team_members
FOR INSERT
TO authenticated
WITH CHECK (
  (
    EXISTS (
      SELECT 1 FROM public.teams
      WHERE teams.id = team_members.team_id
        AND teams.owner_id = team_members.user_id
        AND auth.uid() = team_members.user_id
    )
  )
  OR (
    is_verified(user_id) AND (
      EXISTS (
        SELECT 1 FROM public.team_invitations ti
        WHERE ti.team_id = team_members.team_id
          AND ti.invited_user_id = team_members.user_id
          AND ti.status = 'accepted'
      )
      OR EXISTS (
        SELECT 1 FROM public.team_join_requests tjr
        WHERE tjr.team_id = team_members.team_id
          AND tjr.user_id = team_members.user_id
          AND tjr.status = 'approved'
      )
      OR has_role(auth.uid(), 'admin'::app_role)
    )
  )
);