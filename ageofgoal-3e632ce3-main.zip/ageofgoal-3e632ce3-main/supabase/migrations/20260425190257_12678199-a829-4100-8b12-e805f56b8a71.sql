-- 1) Add invite_frozen flag on team_members
ALTER TABLE public.team_members
  ADD COLUMN IF NOT EXISTS invite_frozen boolean NOT NULL DEFAULT false;

-- 2) Replace team_invitations INSERT policy: any non-frozen member can invite verified users
DROP POLICY IF EXISTS "Owners create invites" ON public.team_invitations;

CREATE POLICY "Members create invites"
ON public.team_invitations
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = invited_by
  AND is_verified(invited_user_id)
  AND EXISTS (
    SELECT 1 FROM public.team_members tm
    WHERE tm.team_id = team_invitations.team_id
      AND tm.user_id = auth.uid()
      AND tm.invite_frozen = false
  )
);

-- 3) Allow team owner to kick (delete) other members; keep existing self-leave + admin rules
DROP POLICY IF EXISTS "Members leave after lock period" ON public.team_members;

CREATE POLICY "Members leave or get kicked"
ON public.team_members
FOR DELETE
TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR (auth.uid() = user_id AND joined_at <= (now() - interval '3 days'))
  OR EXISTS (
    SELECT 1 FROM public.teams t
    WHERE t.id = team_members.team_id
      AND t.owner_id = auth.uid()
      AND team_members.user_id <> t.owner_id
  )
);

-- 4) Update before-delete trigger: allow owner kicks to bypass the 3-day lock
CREATE OR REPLACE FUNCTION public.team_members_before_delete()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  team_owner uuid;
  is_owner_kick boolean := false;
BEGIN
  IF EXISTS (SELECT 1 FROM public.teams WHERE id = OLD.team_id AND owner_id = OLD.user_id) THEN
    RAISE EXCEPTION 'Team owner must transfer ownership before leaving';
  END IF;

  SELECT owner_id INTO team_owner FROM public.teams WHERE id = OLD.team_id;
  is_owner_kick := (auth.uid() = team_owner AND auth.uid() <> OLD.user_id);

  -- Self-leave (non-owner): enforce 3-day lock. Owner kicks and admin removes bypass it.
  IF NOT is_owner_kick
     AND NOT public.has_role(auth.uid(), 'admin'::app_role)
     AND OLD.joined_at > now() - interval '3 days' THEN
    RAISE EXCEPTION 'Team members cannot leave within 3 days of joining';
  END IF;

  RETURN OLD;
END;
$function$;