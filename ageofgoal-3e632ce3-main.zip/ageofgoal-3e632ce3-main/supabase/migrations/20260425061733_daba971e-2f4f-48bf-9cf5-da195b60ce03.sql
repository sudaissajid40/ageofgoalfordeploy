-- Admin-only function: fetch a user's email from auth.users
CREATE OR REPLACE FUNCTION public.get_user_email(_user_id uuid)
RETURNS text
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email text;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Admin only';
  END IF;
  SELECT email INTO v_email FROM auth.users WHERE id = _user_id;
  RETURN v_email;
END;
$$;

-- Admin analytics: signups per day for the last N days
CREATE OR REPLACE FUNCTION public.analytics_signups_by_day(_days int DEFAULT 30)
RETURNS TABLE(day date, signups bigint)
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN RAISE EXCEPTION 'Admin only'; END IF;
  RETURN QUERY
  SELECT date_trunc('day', created_at)::date AS day, COUNT(*)::bigint AS signups
  FROM public.profiles
  WHERE created_at >= now() - make_interval(days => _days)
  GROUP BY 1 ORDER BY 1;
END;
$$;

-- Verification status counts
CREATE OR REPLACE FUNCTION public.analytics_verification_breakdown()
RETURNS TABLE(status text, count bigint)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN RAISE EXCEPTION 'Admin only'; END IF;
  RETURN QUERY SELECT verification_status::text, COUNT(*)::bigint FROM public.profiles GROUP BY 1;
END;
$$;

-- Region distribution
CREATE OR REPLACE FUNCTION public.analytics_region_breakdown()
RETURNS TABLE(region text, count bigint, total_points bigint)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN RAISE EXCEPTION 'Admin only'; END IF;
  RETURN QUERY SELECT COALESCE(region::text, 'unknown'), COUNT(*)::bigint, COALESCE(SUM(aog_points),0)::bigint
  FROM public.profiles GROUP BY 1 ORDER BY 2 DESC;
END;
$$;

-- Gender distribution
CREATE OR REPLACE FUNCTION public.analytics_gender_breakdown()
RETURNS TABLE(gender text, count bigint)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN RAISE EXCEPTION 'Admin only'; END IF;
  RETURN QUERY SELECT COALESCE(gender::text, 'unknown'), COUNT(*)::bigint FROM public.profiles GROUP BY 1;
END;
$$;

-- Age buckets
CREATE OR REPLACE FUNCTION public.analytics_age_buckets()
RETURNS TABLE(bucket text, count bigint)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN RAISE EXCEPTION 'Admin only'; END IF;
  RETURN QUERY
  SELECT CASE
    WHEN age IS NULL THEN 'unknown'
    WHEN age < 16 THEN '10-15'
    WHEN age < 19 THEN '16-18'
    WHEN age < 23 THEN '19-22'
    WHEN age < 31 THEN '23-30'
    ELSE '31+'
  END AS bucket, COUNT(*)::bigint
  FROM public.profiles GROUP BY 1 ORDER BY 1;
END;
$$;

-- Level distribution (10-level buckets)
CREATE OR REPLACE FUNCTION public.analytics_level_buckets()
RETURNS TABLE(bucket text, count bigint)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN RAISE EXCEPTION 'Admin only'; END IF;
  RETURN QUERY
  SELECT CASE
    WHEN level IS NULL THEN 'unknown'
    WHEN level < 11 THEN '1-10'
    WHEN level < 21 THEN '11-20'
    WHEN level < 31 THEN '21-30'
    WHEN level < 41 THEN '31-40'
    WHEN level < 51 THEN '41-50'
    WHEN level < 61 THEN '51-60'
    WHEN level < 71 THEN '61-70'
    ELSE '71+'
  END AS bucket, COUNT(*)::bigint
  FROM public.profiles GROUP BY 1 ORDER BY 1;
END;
$$;

-- Team size distribution
CREATE OR REPLACE FUNCTION public.analytics_team_size_distribution()
RETURNS TABLE(size int, team_count bigint)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN RAISE EXCEPTION 'Admin only'; END IF;
  RETURN QUERY
  WITH sizes AS (
    SELECT team_id, COUNT(*)::int AS sz FROM public.team_members GROUP BY team_id
  )
  SELECT sz, COUNT(*)::bigint FROM sizes GROUP BY sz ORDER BY sz;
END;
$$;

-- Play-style distribution
CREATE OR REPLACE FUNCTION public.analytics_play_style_breakdown()
RETURNS TABLE(style text, count bigint)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN RAISE EXCEPTION 'Admin only'; END IF;
  RETURN QUERY SELECT COALESCE(play_style, 'unknown'), COUNT(*)::bigint FROM public.profiles GROUP BY 1 ORDER BY 2 DESC;
END;
$$;

-- Tournament participation: % of verified users who joined ≥1 tournament
CREATE OR REPLACE FUNCTION public.analytics_participation_rate()
RETURNS TABLE(verified_users bigint, participants bigint, rate numeric)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_total bigint; v_part bigint;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN RAISE EXCEPTION 'Admin only'; END IF;
  SELECT COUNT(*) INTO v_total FROM public.profiles WHERE verification_status = 'approved';
  SELECT COUNT(DISTINCT registered_by) INTO v_part FROM public.tournament_registrations
    WHERE registered_by IN (SELECT id FROM public.profiles WHERE verification_status = 'approved');
  RETURN QUERY SELECT v_total, v_part, CASE WHEN v_total = 0 THEN 0 ELSE ROUND(v_part::numeric * 100 / v_total, 1) END;
END;
$$;