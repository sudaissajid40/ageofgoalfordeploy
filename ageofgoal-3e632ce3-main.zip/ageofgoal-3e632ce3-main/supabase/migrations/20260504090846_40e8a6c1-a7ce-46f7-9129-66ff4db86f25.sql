
-- 1) Restrict room_id / room_password column access on tournament_matches
REVOKE SELECT (room_id, room_password) ON public.tournament_matches FROM anon, authenticated;

CREATE OR REPLACE FUNCTION public.can_view_match_room(_match_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT
    public.has_role(auth.uid(), 'admin')
    OR EXISTS (SELECT 1 FROM public.match_players mp
               WHERE mp.match_id = _match_id AND mp.user_id = auth.uid())
    OR EXISTS (
      SELECT 1 FROM public.tournament_matches tm
      JOIN public.teams t ON t.id = tm.team_a_id OR t.id = tm.team_b_id
      WHERE tm.id = _match_id AND t.owner_id = auth.uid()
    );
$$;

CREATE OR REPLACE FUNCTION public.get_match_room(_match_id uuid)
RETURNS TABLE(room_id text, room_password text)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT public.can_view_match_room(_match_id) THEN
    RAISE EXCEPTION 'Not authorized to view match room credentials';
  END IF;
  RETURN QUERY SELECT tm.room_id, tm.room_password FROM public.tournament_matches tm WHERE tm.id = _match_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.can_view_match_room(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_match_room(uuid) TO authenticated;

-- 2) Guard create_notification against direct caller misuse
CREATE OR REPLACE FUNCTION public.create_notification(_recipient_id uuid, _actor_id uuid, _type notification_type, _title text, _message text, _action_url text DEFAULT NULL::text, _metadata jsonb DEFAULT '{}'::jsonb)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  nid uuid;
BEGIN
  -- Only admins (or trigger / system contexts where auth.uid() is null) may invoke directly
  IF auth.uid() IS NOT NULL AND NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Permission denied';
  END IF;
  INSERT INTO public.notifications (recipient_id, actor_id, type, title, message, action_url, metadata)
  VALUES (_recipient_id, _actor_id, _type, _title, _message, _action_url, COALESCE(_metadata, '{}'::jsonb))
  RETURNING id INTO nid;
  RETURN nid;
END;
$function$;

-- 3) Tighten team_members INSERT to require auth.uid() = user_id in non-owner branches
DROP POLICY IF EXISTS "Members inserted by accepted flow" ON public.team_members;
CREATE POLICY "Members inserted by accepted flow"
ON public.team_members FOR INSERT TO authenticated
WITH CHECK (
  -- Owner self-insert (team creation flow)
  (EXISTS (
    SELECT 1 FROM public.teams
    WHERE teams.id = team_members.team_id
      AND teams.owner_id = team_members.user_id
      AND auth.uid() = team_members.user_id
  ))
  OR
  -- Self-join via accepted invitation or approved request
  (
    auth.uid() = team_members.user_id
    AND public.is_verified(team_members.user_id)
    AND (
      EXISTS (SELECT 1 FROM public.team_invitations ti
              WHERE ti.team_id = team_members.team_id
                AND ti.invited_user_id = team_members.user_id
                AND ti.status = 'accepted')
      OR EXISTS (SELECT 1 FROM public.team_join_requests tjr
              WHERE tjr.team_id = team_members.team_id
                AND tjr.user_id = team_members.user_id
                AND tjr.status = 'approved')
    )
  )
  OR public.has_role(auth.uid(), 'admin')
);
