
-- =======================================================
-- 1. push_subscriptions
-- =======================================================
CREATE TABLE IF NOT EXISTS public.push_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  endpoint text NOT NULL UNIQUE,
  p256dh text NOT NULL,
  auth text NOT NULL,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_push_sub_user ON public.push_subscriptions(user_id);
ALTER TABLE public.push_subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own push subs"
ON public.push_subscriptions FOR ALL
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins read push subs"
ON public.push_subscriptions FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- =======================================================
-- 2. payment_submissions
-- =======================================================
DO $$ BEGIN
  CREATE TYPE public.payment_status AS ENUM ('pending', 'approved', 'rejected');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.payment_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tournament_id uuid NOT NULL,
  user_id uuid NOT NULL,
  team_id uuid,
  amount numeric NOT NULL DEFAULT 0,
  receipt_url text NOT NULL,
  status public.payment_status NOT NULL DEFAULT 'pending',
  admin_note text,
  reviewed_by uuid,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_payment_user ON public.payment_submissions(user_id);
CREATE INDEX IF NOT EXISTS idx_payment_tournament ON public.payment_submissions(tournament_id);
ALTER TABLE public.payment_submissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own payments"
ON public.payment_submissions FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users create own payments"
ON public.payment_submissions FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users delete own pending payments"
ON public.payment_submissions FOR DELETE
TO authenticated
USING ((auth.uid() = user_id AND status = 'pending') OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins update payments"
ON public.payment_submissions FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- =======================================================
-- 3. tournaments: sponsor + payment columns
-- =======================================================
ALTER TABLE public.tournaments
  ADD COLUMN IF NOT EXISTS sponsor_name text,
  ADD COLUMN IF NOT EXISTS sponsor_hook text,
  ADD COLUMN IF NOT EXISTS sponsor_cta_label text,
  ADD COLUMN IF NOT EXISTS sponsor_cta_url text,
  ADD COLUMN IF NOT EXISTS sponsor_banner_url text,
  ADD COLUMN IF NOT EXISTS entry_fee numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS payment_account_label text,
  ADD COLUMN IF NOT EXISTS payment_account_number text,
  ADD COLUMN IF NOT EXISTS payment_instructions text;

-- =======================================================
-- 4. profiles: edit cooldown columns
-- =======================================================
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS edit_count int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_edit_at timestamptz;

-- =======================================================
-- 5. payment-receipts storage bucket
-- =======================================================
INSERT INTO storage.buckets (id, name, public)
VALUES ('payment-receipts', 'payment-receipts', false)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Users upload own receipts"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'payment-receipts' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users read own receipts"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'payment-receipts'
  AND (auth.uid()::text = (storage.foldername(name))[1] OR public.has_role(auth.uid(), 'admin'))
);

CREATE POLICY "Users delete own receipts"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'payment-receipts' AND auth.uid()::text = (storage.foldername(name))[1]);

-- =======================================================
-- 6. profile edit cooldown trigger + force re-verify
-- =======================================================
CREATE OR REPLACE FUNCTION public.profiles_before_update_cooldown()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  changed boolean := false;
  required_days int;
  v_days_since numeric;
BEGIN
  -- Skip enforcement when an admin makes the change
  IF public.has_role(auth.uid(), 'admin') THEN
    RETURN NEW;
  END IF;

  -- Detect meaningful field changes
  IF (NEW.username IS DISTINCT FROM OLD.username)
     OR (NEW.city IS DISTINCT FROM OLD.city)
     OR (NEW.region IS DISTINCT FROM OLD.region)
     OR (NEW.ff_uid IS DISTINCT FROM OLD.ff_uid)
     OR (NEW.ff_username IS DISTINCT FROM OLD.ff_username)
     OR (NEW.level IS DISTINCT FROM OLD.level)
     OR (NEW.age IS DISTINCT FROM OLD.age)
     OR (NEW.gender IS DISTINCT FROM OLD.gender)
     OR (NEW.play_style IS DISTINCT FROM OLD.play_style)
     OR (NEW.preferred_mode IS DISTINCT FROM OLD.preferred_mode)
  THEN
    changed := true;
  END IF;

  IF NOT changed THEN
    RETURN NEW;
  END IF;

  -- During first profile completion (profile_completed flips false->true), let it through
  IF OLD.profile_completed = false THEN
    RETURN NEW;
  END IF;

  -- Allow rejected resubmit any time
  IF OLD.verification_status = 'rejected' THEN
    NEW.verification_status := 'pending';
    NEW.rejection_reason := NULL;
    NEW.last_edit_at := now();
    NEW.edit_count := COALESCE(OLD.edit_count, 0) + 1;
    RETURN NEW;
  END IF;

  -- Cooldown ladder: edits already taken => required wait for next edit
  -- 0 prior edits => allow now (1st edit). 1 => 3 days. 2 => 7 days. 3+ => 30 days.
  IF COALESCE(OLD.edit_count, 0) = 0 THEN
    required_days := 0;
  ELSIF OLD.edit_count = 1 THEN
    required_days := 3;
  ELSIF OLD.edit_count = 2 THEN
    required_days := 7;
  ELSE
    required_days := 30;
  END IF;

  IF required_days > 0 AND OLD.last_edit_at IS NOT NULL THEN
    v_days_since := EXTRACT(EPOCH FROM (now() - OLD.last_edit_at)) / 86400.0;
    IF v_days_since < required_days THEN
      RAISE EXCEPTION 'You can next edit your profile in % day(s)', CEIL(required_days - v_days_since);
    END IF;
  END IF;

  NEW.edit_count := COALESCE(OLD.edit_count, 0) + 1;
  NEW.last_edit_at := now();
  NEW.verification_status := 'pending';
  NEW.rejection_reason := NULL;
  NEW.profile_note := COALESCE(NEW.profile_note, OLD.profile_note);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profiles_before_update_cooldown ON public.profiles;
CREATE TRIGGER profiles_before_update_cooldown
BEFORE UPDATE ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.profiles_before_update_cooldown();

-- Loosen RLS WITH CHECK so cooldown trigger output (status flip to pending) is allowed
DROP POLICY IF EXISTS "Users update own profile (with resubmit)" ON public.profiles;
CREATE POLICY "Users update own profile (with resubmit)"
ON public.profiles FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (
  auth.uid() = id
  AND aog_points = (SELECT p.aog_points FROM public.profiles p WHERE p.id = auth.uid())
);

-- =======================================================
-- 7. Replace tournament_registrations_before_insert to gate paid tournaments
-- =======================================================
CREATE OR REPLACE FUNCTION public.tournament_registrations_before_insert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_min_members int;
  v_verified_count int;
  v_is_owner boolean;
  v_can_register boolean;
  v_entry_fee numeric;
  v_paid_ok boolean;
BEGIN
  IF NOT public.is_verified(NEW.registered_by) THEN
    RAISE EXCEPTION 'You must be verified to register';
  END IF;

  IF NEW.participant_type = 'user' AND NEW.participant_id <> NEW.registered_by THEN
    RAISE EXCEPTION 'Solo registration must be for yourself';
  END IF;

  SELECT COALESCE(entry_fee, 0) INTO v_entry_fee
  FROM public.tournaments WHERE id = NEW.tournament_id;

  IF NEW.participant_type = 'team' THEN
    SELECT (owner_id = NEW.registered_by) INTO v_is_owner
    FROM public.teams WHERE id = NEW.participant_id;
    IF v_is_owner IS NULL THEN RAISE EXCEPTION 'Team not found'; END IF;

    IF NOT v_is_owner THEN
      SELECT COALESCE(can_register, false) INTO v_can_register
      FROM public.team_members
      WHERE team_id = NEW.participant_id AND user_id = NEW.registered_by;
      IF v_can_register IS NOT TRUE THEN
        RAISE EXCEPTION 'Only the team owner or a delegated member can register the team';
      END IF;
    END IF;

    SELECT COALESCE(min_team_members, 1) INTO v_min_members
    FROM public.tournaments WHERE id = NEW.tournament_id;

    SELECT COUNT(*) INTO v_verified_count
    FROM public.team_members tm
    JOIN public.profiles p ON p.id = tm.user_id
    WHERE tm.team_id = NEW.participant_id
      AND p.verification_status = 'approved';

    IF v_verified_count < v_min_members THEN
      RAISE EXCEPTION 'Team needs at least % verified members to register (currently %)', v_min_members, v_verified_count;
    END IF;
  END IF;

  -- Paid tournament gating
  IF v_entry_fee > 0 THEN
    SELECT EXISTS (
      SELECT 1 FROM public.payment_submissions ps
      WHERE ps.tournament_id = NEW.tournament_id
        AND ps.user_id = NEW.registered_by
        AND ps.status = 'approved'
    ) INTO v_paid_ok;
    IF NOT v_paid_ok THEN
      RAISE EXCEPTION 'Entry fee payment must be approved by an admin before registering';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

-- =======================================================
-- 8. notifications_after_insert -> webpush via pg_net
-- =======================================================
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

CREATE OR REPLACE FUNCTION public.notifications_after_insert_push()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_url text;
  v_anon text;
BEGIN
  v_url := 'https://oulgpjtmniycgxmrojkj.supabase.co/functions/v1/send-push';
  v_anon := 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im91bGdwanRtbml5Y2d4bXJvamtqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY0MDQwMzAsImV4cCI6MjA5MTk4MDAzMH0.Xj-NgulTa4kBmW1kQqAxVJQf3eux8NLQSaHLWX40h5M';

  PERFORM extensions.http_post(
    url := v_url,
    headers := jsonb_build_object('Content-Type','application/json','Authorization','Bearer '||v_anon),
    body := jsonb_build_object(
      'user_ids', jsonb_build_array(NEW.recipient_id),
      'title', NEW.title,
      'body', NEW.message,
      'url', COALESCE(NEW.action_url, '/mailbox')
    )
  );
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Never block notification insert on push delivery failure
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS notifications_after_insert_push ON public.notifications;
CREATE TRIGGER notifications_after_insert_push
AFTER INSERT ON public.notifications
FOR EACH ROW
EXECUTE FUNCTION public.notifications_after_insert_push();

-- =======================================================
-- 9. Realtime publish new tables
-- =======================================================
DO $$ BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.payment_submissions;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
