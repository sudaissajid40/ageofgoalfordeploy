-- Remove duplicate team owner auto-add triggers that caused team creation to fail.
DROP TRIGGER IF EXISTS teams_add_owner ON public.teams;
DROP TRIGGER IF EXISTS teams_add_owner_member ON public.teams;
DROP TRIGGER IF EXISTS trg_teams_after_insert ON public.teams;

-- Recreate a single canonical owner auto-add trigger.
CREATE TRIGGER trg_teams_after_insert
AFTER INSERT ON public.teams
FOR EACH ROW
EXECUTE FUNCTION public.teams_after_insert();

-- Remove duplicate team region triggers and keep one canonical trigger.
DROP TRIGGER IF EXISTS teams_set_region_before_insert ON public.teams;
DROP TRIGGER IF EXISTS trg_set_team_region ON public.teams;
DROP TRIGGER IF EXISTS trg_teams_before_insert_region ON public.teams;

CREATE TRIGGER trg_teams_before_insert_region
BEFORE INSERT ON public.teams
FOR EACH ROW
EXECUTE FUNCTION public.set_team_region();

-- Remove duplicate team member validation triggers and keep one canonical insert validator.
DROP TRIGGER IF EXISTS team_members_validate ON public.team_members;
DROP TRIGGER IF EXISTS team_members_validate_before_insert ON public.team_members;
DROP TRIGGER IF EXISTS trg_team_members_before_insert ON public.team_members;

CREATE TRIGGER trg_team_members_before_insert
BEFORE INSERT ON public.team_members
FOR EACH ROW
EXECUTE FUNCTION public.team_members_before_insert();

-- Remove duplicate single-team insert triggers; team_members_before_insert already enforces this on insert.
DROP TRIGGER IF EXISTS trg_single_team_check ON public.team_members;
DROP TRIGGER IF EXISTS team_members_enforce_single_team ON public.team_members;

-- Keep single-team protection for admin/user-id update scenarios only.
CREATE TRIGGER team_members_enforce_single_team
BEFORE UPDATE OF user_id, team_id ON public.team_members
FOR EACH ROW
EXECUTE FUNCTION public.enforce_single_team();

-- Remove duplicate team level recompute triggers and keep one canonical trigger.
DROP TRIGGER IF EXISTS team_members_change ON public.team_members;
DROP TRIGGER IF EXISTS team_members_recompute_level ON public.team_members;
DROP TRIGGER IF EXISTS trg_team_members_after_change ON public.team_members;

CREATE TRIGGER trg_team_members_after_change
AFTER INSERT OR DELETE OR UPDATE ON public.team_members
FOR EACH ROW
EXECUTE FUNCTION public.team_members_after_change();