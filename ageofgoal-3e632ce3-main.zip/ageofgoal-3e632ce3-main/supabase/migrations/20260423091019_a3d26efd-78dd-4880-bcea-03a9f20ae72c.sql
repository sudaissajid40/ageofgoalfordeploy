
-- ============= 1. WIPE TEST DATA =============
DELETE FROM public.tournament_registrations;
DELETE FROM public.tournaments;
DELETE FROM public.team_join_requests;
DELETE FROM public.team_members;
DELETE FROM public.teams;
-- Reset all profiles back to "needs to complete profile" state
UPDATE public.profiles SET 
  profile_completed = false,
  verification_status = 'pending',
  username = NULL,
  level = NULL,
  city = NULL,
  aog_points = 0,
  rejection_reason = NULL;

-- ============= 2. ENUMS =============
CREATE TYPE public.region AS ENUM ('punjab', 'sindh', 'balochistan', 'kpk');
CREATE TYPE public.match_round AS ENUM ('group', 'quarter', 'semi', 'final');
CREATE TYPE public.match_status AS ENUM ('scheduled', 'live', 'completed', 'cancelled');

-- ============= 3. PROFILES additions =============
ALTER TABLE public.profiles
  ADD COLUMN ff_uid TEXT,
  ADD COLUMN region public.region;

-- ============= 4. TEAMS additions =============
ALTER TABLE public.teams
  ADD COLUMN region public.region,
  ADD COLUMN aog_points INTEGER NOT NULL DEFAULT 0;

-- ============= 5. SINGLE TEAM PER PLAYER =============
CREATE UNIQUE INDEX team_members_user_unique ON public.team_members(user_id);

-- ============= 6. TOURNAMENTS additions =============
ALTER TABLE public.tournaments
  ADD COLUMN registration_ends_at TIMESTAMPTZ,
  ADD COLUMN match_team_size INTEGER NOT NULL DEFAULT 4 CHECK (match_team_size IN (1,2,4)),
  ADD COLUMN min_team_members INTEGER NOT NULL DEFAULT 4,
  ADD COLUMN max_team_members INTEGER NOT NULL DEFAULT 6,
  ADD COLUMN points_per_match_win INTEGER NOT NULL DEFAULT 1,
  ADD COLUMN champion_points_multiplier INTEGER NOT NULL DEFAULT 2,
  ADD COLUMN selected_schedule_id UUID;

-- ============= 7. TOURNAMENT MATCHES =============
CREATE TABLE public.tournament_matches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tournament_id UUID NOT NULL REFERENCES public.tournaments(id) ON DELETE CASCADE,
  round public.match_round NOT NULL DEFAULT 'group',
  match_number INTEGER NOT NULL,
  team_a_id UUID REFERENCES public.teams(id) ON DELETE SET NULL,
  team_b_id UUID REFERENCES public.teams(id) ON DELETE SET NULL,
  scheduled_at TIMESTAMPTZ NOT NULL,
  room_id TEXT,
  room_password TEXT,
  spectator_link TEXT,
  winner_team_id UUID REFERENCES public.teams(id) ON DELETE SET NULL,
  status public.match_status NOT NULL DEFAULT 'scheduled',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_matches_tournament ON public.tournament_matches(tournament_id);
CREATE INDEX idx_matches_teams ON public.tournament_matches(team_a_id, team_b_id);

-- ============= 8. MATCH PLAYERS (locked roster) =============
CREATE TABLE public.match_players (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id UUID NOT NULL REFERENCES public.tournament_matches(id) ON DELETE CASCADE,
  team_id UUID NOT NULL REFERENCES public.teams(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  joined_at TIMESTAMPTZ,
  UNIQUE(match_id, user_id)
);
CREATE INDEX idx_match_players_match ON public.match_players(match_id);
CREATE INDEX idx_match_players_user ON public.match_players(user_id);

-- ============= 9. SCHEDULE PROPOSALS (AI generated) =============
CREATE TABLE public.tournament_schedule_proposals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tournament_id UUID NOT NULL REFERENCES public.tournaments(id) ON DELETE CASCADE,
  label TEXT NOT NULL,
  description TEXT,
  matches JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_schedule_proposals_tournament ON public.tournament_schedule_proposals(tournament_id);

ALTER TABLE public.tournaments
  ADD CONSTRAINT tournaments_selected_schedule_fk
  FOREIGN KEY (selected_schedule_id)
  REFERENCES public.tournament_schedule_proposals(id) ON DELETE SET NULL;

-- ============= 10. ENABLE RLS =============
ALTER TABLE public.tournament_matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.match_players ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tournament_schedule_proposals ENABLE ROW LEVEL SECURITY;

-- ============= 11. RLS: tournament_matches =============
CREATE POLICY "Matches viewable by authenticated"
  ON public.tournament_matches FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "Admins manage matches"
  ON public.tournament_matches FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- ============= 12. RLS: match_players =============
CREATE POLICY "Match players viewable by authenticated"
  ON public.match_players FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "Admins manage match players"
  ON public.match_players FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Players self-join their match slot"
  ON public.match_players FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- ============= 13. RLS: schedule proposals =============
CREATE POLICY "Proposals viewable by admins"
  ON public.tournament_schedule_proposals FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins manage proposals"
  ON public.tournament_schedule_proposals FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- ============= 14. TRIGGER: enforce single team per player =============
CREATE OR REPLACE FUNCTION public.enforce_single_team()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM public.team_members WHERE user_id = NEW.user_id AND (TG_OP = 'INSERT' OR id <> NEW.id)) THEN
    RAISE EXCEPTION 'Player can only be in one team at a time';
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_single_team_check
  BEFORE INSERT ON public.team_members
  FOR EACH ROW EXECUTE FUNCTION public.enforce_single_team();

-- ============= 15. TRIGGER: set team region from owner =============
CREATE OR REPLACE FUNCTION public.set_team_region()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.region IS NULL THEN
    SELECT region INTO NEW.region FROM public.profiles WHERE id = NEW.owner_id;
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_set_team_region
  BEFORE INSERT ON public.teams
  FOR EACH ROW EXECUTE FUNCTION public.set_team_region();

-- ============= 16. FUNCTION: award match win =============
CREATE OR REPLACE FUNCTION public.award_match_win(_match_id UUID, _winner_team_id UUID)
RETURNS VOID LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  m RECORD;
  pts INT;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admins can record match results';
  END IF;
  
  SELECT tm.*, t.points_per_match_win INTO m
  FROM public.tournament_matches tm
  JOIN public.tournaments t ON t.id = tm.tournament_id
  WHERE tm.id = _match_id;
  
  IF NOT FOUND THEN RAISE EXCEPTION 'Match not found'; END IF;
  IF _winner_team_id NOT IN (m.team_a_id, m.team_b_id) THEN
    RAISE EXCEPTION 'Winner must be one of the two teams in this match';
  END IF;
  
  pts := m.points_per_match_win;
  
  -- Award to team
  UPDATE public.teams SET aog_points = aog_points + pts WHERE id = _winner_team_id;
  -- Award to each member of winning team
  UPDATE public.profiles SET aog_points = aog_points + pts
  WHERE id IN (SELECT user_id FROM public.team_members WHERE team_id = _winner_team_id);
  
  UPDATE public.tournament_matches SET 
    winner_team_id = _winner_team_id,
    status = 'completed',
    updated_at = now()
  WHERE id = _match_id;
END;
$$;

-- ============= 17. FUNCTION: crown tournament champion =============
CREATE OR REPLACE FUNCTION public.crown_tournament_champion(_tournament_id UUID, _winner_team_id UUID)
RETURNS VOID LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  t RECORD;
  member_count INT;
  bonus INT;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admins can crown a champion';
  END IF;
  
  SELECT * INTO t FROM public.tournaments WHERE id = _tournament_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Tournament not found'; END IF;
  
  SELECT COUNT(*) INTO member_count FROM public.team_members WHERE team_id = _winner_team_id;
  bonus := t.champion_points_multiplier * member_count;
  
  UPDATE public.teams SET aog_points = aog_points + bonus WHERE id = _winner_team_id;
  UPDATE public.profiles SET aog_points = aog_points + bonus
  WHERE id IN (SELECT user_id FROM public.team_members WHERE team_id = _winner_team_id);
  
  UPDATE public.tournaments SET status = 'completed' WHERE id = _tournament_id;
END;
$$;

-- ============= 18. FUNCTION: get top N teams by points (for finals seeding) =============
CREATE OR REPLACE FUNCTION public.get_tournament_standings(_tournament_id UUID)
RETURNS TABLE(team_id UUID, team_name TEXT, wins BIGINT, points INTEGER)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT 
    t.id,
    t.name,
    COUNT(tm.id) FILTER (WHERE tm.winner_team_id = t.id) AS wins,
    t.aog_points
  FROM public.teams t
  JOIN public.tournament_matches tm ON (tm.team_a_id = t.id OR tm.team_b_id = t.id)
  WHERE tm.tournament_id = _tournament_id
  GROUP BY t.id, t.name, t.aog_points
  ORDER BY wins DESC, t.aog_points DESC;
$$;

-- ============= 19. FUNCTION: check if user can join match =============
CREATE OR REPLACE FUNCTION public.can_join_match(_match_id UUID, _user_id UUID)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.match_players
    WHERE match_id = _match_id AND user_id = _user_id
  );
$$;

-- ============= 20. updated_at trigger for matches =============
CREATE TRIGGER update_matches_updated_at
  BEFORE UPDATE ON public.tournament_matches
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
