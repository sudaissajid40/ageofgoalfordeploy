
-- ============ ENUMS ============
CREATE TYPE public.app_role AS ENUM ('admin', 'user');
CREATE TYPE public.verification_status AS ENUM ('pending', 'approved', 'rejected');
CREATE TYPE public.tournament_type AS ENUM ('solo', 'team');
CREATE TYPE public.tournament_status AS ENUM ('upcoming', 'live', 'completed');
CREATE TYPE public.participant_type AS ENUM ('user', 'team');
CREATE TYPE public.join_request_status AS ENUM ('pending', 'approved', 'rejected');

-- ============ PROFILES ============
CREATE TABLE public.profiles (
  id UUID NOT NULL PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT UNIQUE,
  level INT CHECK (level >= 1 AND level <= 100),
  city TEXT,
  verification_status public.verification_status NOT NULL DEFAULT 'pending',
  rejection_reason TEXT,
  aog_points INT NOT NULL DEFAULT 0,
  profile_completed BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- ============ USER ROLES ============
CREATE TABLE public.user_roles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- ============ SECURITY DEFINER FUNCTIONS ============
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE OR REPLACE FUNCTION public.is_verified(_user_id UUID)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = _user_id AND verification_status = 'approved'
  )
$$;

-- ============ TEAMS ============
CREATE TABLE public.teams (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  owner_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  team_level INT NOT NULL DEFAULT 0,
  join_code TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.teams ENABLE ROW LEVEL SECURITY;

-- ============ TEAM MEMBERS ============
CREATE TABLE public.team_members (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  team_id UUID NOT NULL REFERENCES public.teams(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (team_id, user_id)
);

ALTER TABLE public.team_members ENABLE ROW LEVEL SECURITY;

-- A user can only be on one team at a time
CREATE UNIQUE INDEX idx_team_members_unique_user ON public.team_members(user_id);

-- ============ TEAM JOIN REQUESTS ============
CREATE TABLE public.team_join_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  team_id UUID NOT NULL REFERENCES public.teams(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  status public.join_request_status NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (team_id, user_id)
);

ALTER TABLE public.team_join_requests ENABLE ROW LEVEL SECURITY;

-- ============ TOURNAMENTS ============
CREATE TABLE public.tournaments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  type public.tournament_type NOT NULL,
  rules TEXT,
  starts_at TIMESTAMPTZ NOT NULL,
  status public.tournament_status NOT NULL DEFAULT 'upcoming',
  point_payouts JSONB NOT NULL DEFAULT '{}'::jsonb,
  max_participants INT,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.tournaments ENABLE ROW LEVEL SECURITY;

-- ============ TOURNAMENT REGISTRATIONS ============
CREATE TABLE public.tournament_registrations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tournament_id UUID NOT NULL REFERENCES public.tournaments(id) ON DELETE CASCADE,
  participant_id UUID NOT NULL,
  participant_type public.participant_type NOT NULL,
  registered_by UUID NOT NULL REFERENCES auth.users(id),
  placement INT,
  points_awarded INT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tournament_id, participant_id)
);

ALTER TABLE public.tournament_registrations ENABLE ROW LEVEL SECURITY;

-- ============ TIMESTAMP TRIGGER ============
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- ============ AUTO-CREATE PROFILE ON SIGNUP ============
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id) VALUES (NEW.id);
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user');
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============ TEAM LEVEL AUTO-RECOMPUTE ============
CREATE OR REPLACE FUNCTION public.recompute_team_level(_team_id UUID)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.teams
  SET team_level = COALESCE((
    SELECT SUM(p.level)
    FROM public.team_members tm
    JOIN public.profiles p ON p.id = tm.user_id
    WHERE tm.team_id = _team_id
  ), 0)
  WHERE id = _team_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.team_members_after_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    PERFORM public.recompute_team_level(OLD.team_id);
    RETURN OLD;
  ELSE
    PERFORM public.recompute_team_level(NEW.team_id);
    RETURN NEW;
  END IF;
END;
$$;

CREATE TRIGGER team_members_change
  AFTER INSERT OR UPDATE OR DELETE ON public.team_members
  FOR EACH ROW
  EXECUTE FUNCTION public.team_members_after_change();

-- ============ TEAM MEMBER GUARD: max 6, verified, owner auto-added ============
CREATE OR REPLACE FUNCTION public.team_members_before_insert()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  member_count INT;
BEGIN
  -- Must be verified
  IF NOT public.is_verified(NEW.user_id) THEN
    RAISE EXCEPTION 'User must be verified to join a team';
  END IF;

  -- Max 6 members
  SELECT COUNT(*) INTO member_count FROM public.team_members WHERE team_id = NEW.team_id;
  IF member_count >= 6 THEN
    RAISE EXCEPTION 'Team is full (max 6 players)';
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER team_members_validate
  BEFORE INSERT ON public.team_members
  FOR EACH ROW
  EXECUTE FUNCTION public.team_members_before_insert();

-- Auto-add owner as a member when team is created
CREATE OR REPLACE FUNCTION public.teams_after_insert()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.team_members (team_id, user_id) VALUES (NEW.id, NEW.owner_id);
  RETURN NEW;
END;
$$;

CREATE TRIGGER teams_add_owner
  AFTER INSERT ON public.teams
  FOR EACH ROW
  EXECUTE FUNCTION public.teams_after_insert();

-- ============ TOURNAMENT REGISTRATION GUARD ============
CREATE OR REPLACE FUNCTION public.tournament_registrations_before_insert()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Registering user must be verified
  IF NOT public.is_verified(NEW.registered_by) THEN
    RAISE EXCEPTION 'You must be verified to register';
  END IF;

  -- For team tournaments, registered_by must be the team owner
  IF NEW.participant_type = 'team' THEN
    IF NOT EXISTS (
      SELECT 1 FROM public.teams
      WHERE id = NEW.participant_id AND owner_id = NEW.registered_by
    ) THEN
      RAISE EXCEPTION 'Only the team owner can register the team';
    END IF;
  END IF;

  -- For solo, participant_id must equal registered_by
  IF NEW.participant_type = 'user' AND NEW.participant_id <> NEW.registered_by THEN
    RAISE EXCEPTION 'Solo registration must be for yourself';
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER tournament_registrations_validate
  BEFORE INSERT ON public.tournament_registrations
  FOR EACH ROW
  EXECUTE FUNCTION public.tournament_registrations_before_insert();

-- ============ AWARD POINTS FUNCTION ============
CREATE OR REPLACE FUNCTION public.award_tournament_points(_tournament_id UUID)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  t_record RECORD;
  reg RECORD;
  pts INT;
BEGIN
  -- Only admins
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admins can award points';
  END IF;

  SELECT * INTO t_record FROM public.tournaments WHERE id = _tournament_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Tournament not found';
  END IF;

  -- Reset previously-awarded points for this tournament
  FOR reg IN
    SELECT * FROM public.tournament_registrations
    WHERE tournament_id = _tournament_id AND points_awarded IS NOT NULL
  LOOP
    IF reg.participant_type = 'user' THEN
      UPDATE public.profiles SET aog_points = aog_points - reg.points_awarded WHERE id = reg.participant_id;
    ELSE
      UPDATE public.profiles SET aog_points = aog_points - reg.points_awarded
      WHERE id IN (SELECT user_id FROM public.team_members WHERE team_id = reg.participant_id);
    END IF;
    UPDATE public.tournament_registrations SET points_awarded = NULL WHERE id = reg.id;
  END LOOP;

  -- Award based on placement and payout map
  FOR reg IN
    SELECT * FROM public.tournament_registrations
    WHERE tournament_id = _tournament_id AND placement IS NOT NULL
  LOOP
    pts := COALESCE((t_record.point_payouts ->> reg.placement::text)::int, 0);
    IF pts > 0 THEN
      IF reg.participant_type = 'user' THEN
        UPDATE public.profiles SET aog_points = aog_points + pts WHERE id = reg.participant_id;
      ELSE
        UPDATE public.profiles SET aog_points = aog_points + pts
        WHERE id IN (SELECT user_id FROM public.team_members WHERE team_id = reg.participant_id);
      END IF;
      UPDATE public.tournament_registrations SET points_awarded = pts WHERE id = reg.id;
    END IF;
  END LOOP;

  UPDATE public.tournaments SET status = 'completed' WHERE id = _tournament_id;
END;
$$;

-- ============ RLS POLICIES ============

-- profiles
CREATE POLICY "Profiles viewable by authenticated"
  ON public.profiles FOR SELECT TO authenticated USING (true);

CREATE POLICY "Users update own profile (no status change)"
  ON public.profiles FOR UPDATE TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (
    auth.uid() = id
    AND verification_status = (SELECT verification_status FROM public.profiles WHERE id = auth.uid())
    AND aog_points = (SELECT aog_points FROM public.profiles WHERE id = auth.uid())
  );

CREATE POLICY "Admins update any profile"
  ON public.profiles FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- user_roles
CREATE POLICY "Users view own roles"
  ON public.user_roles FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins manage roles"
  ON public.user_roles FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- teams
CREATE POLICY "Teams viewable by authenticated"
  ON public.teams FOR SELECT TO authenticated USING (true);

CREATE POLICY "Verified users create teams"
  ON public.teams FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = owner_id AND public.is_verified(auth.uid()));

CREATE POLICY "Owner updates team"
  ON public.teams FOR UPDATE TO authenticated USING (auth.uid() = owner_id);

CREATE POLICY "Owner or admin deletes team"
  ON public.teams FOR DELETE TO authenticated
  USING (auth.uid() = owner_id OR public.has_role(auth.uid(), 'admin'));

-- team_members
CREATE POLICY "Team members viewable by authenticated"
  ON public.team_members FOR SELECT TO authenticated USING (true);

CREATE POLICY "Owner adds members; user joins via code"
  ON public.team_members FOR INSERT TO authenticated
  WITH CHECK (
    public.is_verified(user_id) AND (
      auth.uid() = user_id  -- self-join (via code)
      OR EXISTS (SELECT 1 FROM public.teams WHERE id = team_id AND owner_id = auth.uid())
    )
  );

CREATE POLICY "Owner removes members or self leaves"
  ON public.team_members FOR DELETE TO authenticated
  USING (
    auth.uid() = user_id
    OR EXISTS (SELECT 1 FROM public.teams WHERE id = team_id AND owner_id = auth.uid())
  );

-- team_join_requests
CREATE POLICY "Requests viewable by user or team owner"
  ON public.team_join_requests FOR SELECT TO authenticated
  USING (
    auth.uid() = user_id
    OR EXISTS (SELECT 1 FROM public.teams WHERE id = team_id AND owner_id = auth.uid())
  );

CREATE POLICY "Verified users create join requests"
  ON public.team_join_requests FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id AND public.is_verified(auth.uid()));

CREATE POLICY "Owner updates request status"
  ON public.team_join_requests FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.teams WHERE id = team_id AND owner_id = auth.uid()));

CREATE POLICY "User cancels own request"
  ON public.team_join_requests FOR DELETE TO authenticated
  USING (auth.uid() = user_id OR EXISTS (SELECT 1 FROM public.teams WHERE id = team_id AND owner_id = auth.uid()));

-- tournaments
CREATE POLICY "Tournaments viewable by authenticated"
  ON public.tournaments FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins manage tournaments"
  ON public.tournaments FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- tournament_registrations
CREATE POLICY "Registrations viewable by authenticated"
  ON public.tournament_registrations FOR SELECT TO authenticated USING (true);

CREATE POLICY "Verified users register"
  ON public.tournament_registrations FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = registered_by AND public.is_verified(auth.uid()));

CREATE POLICY "Admins update placements"
  ON public.tournament_registrations FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "User unregisters or admin removes"
  ON public.tournament_registrations FOR DELETE TO authenticated
  USING (auth.uid() = registered_by OR public.has_role(auth.uid(), 'admin'));
