-- =========================================================
-- 1. New columns
-- =========================================================
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS ff_username text;

ALTER TABLE public.team_members
  ADD COLUMN IF NOT EXISTS can_register boolean NOT NULL DEFAULT false;

ALTER TABLE public.tournaments
  ADD COLUMN IF NOT EXISTS thumbnail_url text,
  ADD COLUMN IF NOT EXISTS bracket_size  int;

-- =========================================================
-- 2. Storage bucket for tournament thumbnails
-- =========================================================
INSERT INTO storage.buckets (id, name, public)
VALUES ('tournament-thumbnails', 'tournament-thumbnails', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "Tournament thumbnails public read" ON storage.objects;
CREATE POLICY "Tournament thumbnails public read"
ON storage.objects
FOR SELECT
USING (bucket_id = 'tournament-thumbnails');

DROP POLICY IF EXISTS "Admins upload tournament thumbnails" ON storage.objects;
CREATE POLICY "Admins upload tournament thumbnails"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'tournament-thumbnails' AND public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins update tournament thumbnails" ON storage.objects;
CREATE POLICY "Admins update tournament thumbnails"
ON storage.objects
FOR UPDATE
TO authenticated
USING (bucket_id = 'tournament-thumbnails' AND public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins delete tournament thumbnails" ON storage.objects;
CREATE POLICY "Admins delete tournament thumbnails"
ON storage.objects
FOR DELETE
TO authenticated
USING (bucket_id = 'tournament-thumbnails' AND public.has_role(auth.uid(), 'admin'));

-- =========================================================
-- 3. Allow rejected users to re-submit (rejected -> pending only)
-- =========================================================
DROP POLICY IF EXISTS "Users update own profile (no status change)" ON public.profiles;
DROP POLICY IF EXISTS "Users update own profile (with resubmit)" ON public.profiles;

CREATE POLICY "Users update own profile (with resubmit)"
ON public.profiles
FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (
  auth.uid() = id
  AND aog_points = (SELECT p.aog_points FROM public.profiles p WHERE p.id = auth.uid())
  AND (
    -- normal case: keep verification_status the same
    verification_status = (SELECT p.verification_status FROM public.profiles p WHERE p.id = auth.uid())
    -- OR re-submit case: rejected -> pending
    OR (
      (SELECT p.verification_status FROM public.profiles p WHERE p.id = auth.uid()) = 'rejected'
      AND verification_status = 'pending'
    )
  )
);

-- Allow members to update their own can_register toggle? No: only owner can grant.
-- Add a policy for team_members UPDATE so the owner can toggle can_register.
DROP POLICY IF EXISTS "Owner toggles member can_register" ON public.team_members;
CREATE POLICY "Owner toggles member can_register"
ON public.team_members
FOR UPDATE
TO authenticated
USING (EXISTS (SELECT 1 FROM public.teams t WHERE t.id = team_id AND t.owner_id = auth.uid()))
WITH CHECK (EXISTS (SELECT 1 FROM public.teams t WHERE t.id = team_id AND t.owner_id = auth.uid()));

-- =========================================================
-- 4. Stronger BEFORE INSERT trigger for tournament_registrations
--    - Either team owner OR a member with can_register can register
--    - Team must have >= tournaments.min_team_members VERIFIED members
-- =========================================================
CREATE OR REPLACE FUNCTION public.tournament_registrations_before_insert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_min_members int;
  v_verified_count int;
  v_is_owner boolean;
  v_can_register boolean;
BEGIN
  IF NOT public.is_verified(NEW.registered_by) THEN
    RAISE EXCEPTION 'You must be verified to register';
  END IF;

  IF NEW.participant_type = 'user' AND NEW.participant_id <> NEW.registered_by THEN
    RAISE EXCEPTION 'Solo registration must be for yourself';
  END IF;

  IF NEW.participant_type = 'team' THEN
    SELECT (owner_id = NEW.registered_by) INTO v_is_owner
    FROM public.teams WHERE id = NEW.participant_id;

    IF v_is_owner IS NULL THEN
      RAISE EXCEPTION 'Team not found';
    END IF;

    IF NOT v_is_owner THEN
      SELECT COALESCE(can_register, false) INTO v_can_register
      FROM public.team_members
      WHERE team_id = NEW.participant_id AND user_id = NEW.registered_by;

      IF v_can_register IS NOT TRUE THEN
        RAISE EXCEPTION 'Only the team owner or a delegated member can register the team';
      END IF;
    END IF;

    SELECT COALESCE(min_team_members, 1) INTO v_min_members
    FROM public.tournaments WHERE id = NEW.tournament_id;

    SELECT COUNT(*) INTO v_verified_count
    FROM public.team_members tm
    JOIN public.profiles p ON p.id = tm.user_id
    WHERE tm.team_id = NEW.participant_id
      AND p.verification_status = 'approved';

    IF v_verified_count < v_min_members THEN
      RAISE EXCEPTION 'Team needs at least % verified members to register (currently %)', v_min_members, v_verified_count;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

-- Make sure trigger is attached (idempotent)
DROP TRIGGER IF EXISTS tournament_registrations_before_insert_trg ON public.tournament_registrations;
CREATE TRIGGER tournament_registrations_before_insert_trg
BEFORE INSERT ON public.tournament_registrations
FOR EACH ROW EXECUTE FUNCTION public.tournament_registrations_before_insert();

-- =========================================================
-- 5. Auto-seed knockout bracket RPC (admin only)
-- =========================================================
CREATE OR REPLACE FUNCTION public.seed_knockout_bracket(_tournament_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_bracket_size int;
  v_round_label match_round;
  v_start_at timestamptz;
  v_team_count int;
  v_match_no int := 1;
  rec RECORD;
  team_a uuid;
  team_b uuid;
  i int;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admins can seed brackets';
  END IF;

  SELECT COALESCE(bracket_size, 4) INTO v_bracket_size
  FROM public.tournaments WHERE id = _tournament_id;

  IF v_bracket_size NOT IN (2, 4, 8) THEN
    RAISE EXCEPTION 'bracket_size must be 2, 4, or 8 (got %)', v_bracket_size;
  END IF;

  IF v_bracket_size = 8 THEN v_round_label := 'quarter';
  ELSIF v_bracket_size = 4 THEN v_round_label := 'semi';
  ELSE v_round_label := 'final';
  END IF;

  -- Wipe any prior knockout matches at this round (and beyond) for a clean reseed
  DELETE FROM public.tournament_matches
  WHERE tournament_id = _tournament_id
    AND round IN ('quarter','semi','final');

  -- Build temp table of top teams by win rate from group stage
  CREATE TEMP TABLE _top_teams ON COMMIT DROP AS
  WITH played AS (
    SELECT t.id AS team_id, t.name, t.aog_points,
           COUNT(tm.id) AS played,
           COUNT(tm.id) FILTER (WHERE tm.winner_team_id = t.id) AS wins
    FROM public.teams t
    JOIN public.tournament_matches tm
      ON (tm.team_a_id = t.id OR tm.team_b_id = t.id)
     AND tm.tournament_id = _tournament_id
     AND tm.round = 'group'
    GROUP BY t.id, t.name, t.aog_points
  )
  SELECT team_id,
         CASE WHEN played = 0 THEN 0 ELSE wins::numeric / played END AS win_rate,
         wins, played, aog_points
  FROM played
  ORDER BY win_rate DESC, wins DESC, aog_points DESC
  LIMIT v_bracket_size;

  SELECT COUNT(*) INTO v_team_count FROM _top_teams;
  IF v_team_count < 2 THEN
    RAISE EXCEPTION 'Not enough teams have played group matches to seed a bracket';
  END IF;

  -- Pair seed[i] vs seed[N+1-i]
  v_start_at := COALESCE(
    (SELECT MAX(scheduled_at) + interval '1 day' FROM public.tournament_matches WHERE tournament_id = _tournament_id),
    now() + interval '1 day'
  );

  FOR i IN 1..(v_team_count / 2) LOOP
    SELECT team_id INTO team_a FROM _top_teams ORDER BY win_rate DESC, wins DESC, aog_points DESC LIMIT 1 OFFSET (i - 1);
    SELECT team_id INTO team_b FROM _top_teams ORDER BY win_rate DESC, wins DESC, aog_points DESC LIMIT 1 OFFSET (v_team_count - i);
    INSERT INTO public.tournament_matches (
      tournament_id, round, match_number, team_a_id, team_b_id, scheduled_at, status
    ) VALUES (
      _tournament_id, v_round_label, v_match_no, team_a, team_b, v_start_at + ((v_match_no - 1) * interval '90 minutes'), 'scheduled'
    );
    v_match_no := v_match_no + 1;
  END LOOP;

  -- For 8-team bracket, also create empty semi + final placeholders so admin can fill in
  IF v_bracket_size = 8 THEN
    v_match_no := 1;
    FOR i IN 1..2 LOOP
      INSERT INTO public.tournament_matches (
        tournament_id, round, match_number, team_a_id, team_b_id, scheduled_at, status
      ) VALUES (
        _tournament_id, 'semi', v_match_no, NULL, NULL, v_start_at + interval '1 day' + ((v_match_no - 1) * interval '90 minutes'), 'scheduled'
      );
      v_match_no := v_match_no + 1;
    END LOOP;
    INSERT INTO public.tournament_matches (
      tournament_id, round, match_number, team_a_id, team_b_id, scheduled_at, status
    ) VALUES (
      _tournament_id, 'final', 1, NULL, NULL, v_start_at + interval '2 days', 'scheduled'
    );
  ELSIF v_bracket_size = 4 THEN
    INSERT INTO public.tournament_matches (
      tournament_id, round, match_number, team_a_id, team_b_id, scheduled_at, status
    ) VALUES (
      _tournament_id, 'final', 1, NULL, NULL, v_start_at + interval '1 day', 'scheduled'
    );
  END IF;
END;
$$;

-- =========================================================
-- 6. Realtime publication for live UI
-- =========================================================
DO $$
DECLARE t text;
BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'tournaments','tournament_matches','tournament_registrations',
    'tournament_schedule_proposals','team_members','team_invitations','team_join_requests'
  ])
  LOOP
    BEGIN
      EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', t);
    EXCEPTION WHEN duplicate_object THEN
      -- already in publication
      NULL;
    END;
  END LOOP;
END $$;

-- Replica identity full so update payloads include all columns (helpful for UI diffing)
ALTER TABLE public.tournaments REPLICA IDENTITY FULL;
ALTER TABLE public.tournament_matches REPLICA IDENTITY FULL;
ALTER TABLE public.tournament_registrations REPLICA IDENTITY FULL;
ALTER TABLE public.team_members REPLICA IDENTITY FULL;