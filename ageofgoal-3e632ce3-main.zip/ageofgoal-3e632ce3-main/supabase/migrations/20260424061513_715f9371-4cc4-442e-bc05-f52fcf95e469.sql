CREATE OR REPLACE FUNCTION public.award_match_win(_match_id uuid, _winner_team_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  m RECORD;
  pts INT;
  old_winner uuid;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admins can record match results';
  END IF;

  SELECT tm.*, t.points_per_match_win INTO m
  FROM public.tournament_matches tm
  JOIN public.tournaments t ON t.id = tm.tournament_id
  WHERE tm.id = _match_id;

  IF NOT FOUND THEN RAISE EXCEPTION 'Match not found'; END IF;
  IF _winner_team_id NOT IN (m.team_a_id, m.team_b_id) THEN
    RAISE EXCEPTION 'Winner must be one of the two teams in this match';
  END IF;

  pts := m.points_per_match_win;
  old_winner := m.winner_team_id;

  IF old_winner IS NOT NULL AND old_winner <> _winner_team_id THEN
    UPDATE public.teams SET aog_points = GREATEST(0, aog_points - pts) WHERE id = old_winner;
    UPDATE public.profiles SET aog_points = GREATEST(0, aog_points - pts)
    WHERE id IN (SELECT user_id FROM public.team_members WHERE team_id = old_winner);
  END IF;

  IF old_winner IS DISTINCT FROM _winner_team_id THEN
    UPDATE public.teams SET aog_points = aog_points + pts WHERE id = _winner_team_id;
    UPDATE public.profiles SET aog_points = aog_points + pts
    WHERE id IN (SELECT user_id FROM public.team_members WHERE team_id = _winner_team_id);
  END IF;

  UPDATE public.tournament_matches
  SET winner_team_id = _winner_team_id,
      status = 'completed',
      updated_at = now()
  WHERE id = _match_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.team_members_after_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    PERFORM public.recompute_team_level(OLD.team_id);
    RETURN OLD;
  ELSE
    PERFORM public.recompute_team_level(NEW.team_id);
    RETURN NEW;
  END IF;
END;
$$;

CREATE TRIGGER team_members_enforce_single_team
BEFORE INSERT OR UPDATE ON public.team_members
FOR EACH ROW EXECUTE FUNCTION public.enforce_single_team();

CREATE TRIGGER team_members_validate_before_insert
BEFORE INSERT ON public.team_members
FOR EACH ROW EXECUTE FUNCTION public.team_members_before_insert();

CREATE TRIGGER team_members_recompute_level
AFTER INSERT OR UPDATE OR DELETE ON public.team_members
FOR EACH ROW EXECUTE FUNCTION public.team_members_after_change();

CREATE TRIGGER teams_add_owner_member
AFTER INSERT ON public.teams
FOR EACH ROW EXECUTE FUNCTION public.teams_after_insert();

CREATE TRIGGER teams_set_region_before_insert
BEFORE INSERT ON public.teams
FOR EACH ROW EXECUTE FUNCTION public.set_team_region();

CREATE TRIGGER tournament_registrations_validate_before_insert
BEFORE INSERT ON public.tournament_registrations
FOR EACH ROW EXECUTE FUNCTION public.tournament_registrations_before_insert();

CREATE TRIGGER tournament_matches_touch_updated_at
BEFORE UPDATE ON public.tournament_matches
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();