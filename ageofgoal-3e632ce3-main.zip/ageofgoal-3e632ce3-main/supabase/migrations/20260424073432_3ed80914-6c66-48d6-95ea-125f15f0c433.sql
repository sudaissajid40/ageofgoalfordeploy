DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'gender') THEN
    CREATE TYPE public.gender AS ENUM ('male', 'female', 'other', 'prefer_not_to_say');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'notification_type') THEN
    CREATE TYPE public.notification_type AS ENUM ('team_invite', 'team_request', 'request_decision', 'ownership_transfer', 'tournament', 'admin_broadcast', 'verification', 'match_update', 'system');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'notification_status') THEN
    CREATE TYPE public.notification_status AS ENUM ('unread', 'read', 'archived');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'invitation_status') THEN
    CREATE TYPE public.invitation_status AS ENUM ('pending', 'accepted', 'rejected', 'cancelled');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'ownership_transfer_status') THEN
    CREATE TYPE public.ownership_transfer_status AS ENUM ('pending', 'accepted', 'rejected', 'cancelled');
  END IF;
END $$;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS gender public.gender,
  ADD COLUMN IF NOT EXISTS age integer,
  ADD COLUMN IF NOT EXISTS play_style text,
  ADD COLUMN IF NOT EXISTS preferred_mode text,
  ADD COLUMN IF NOT EXISTS onboarding_step integer NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS profile_note text;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'profiles_age_range') THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_age_range CHECK (age IS NULL OR (age BETWEEN 10 AND 80));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'profiles_level_range') THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_level_range CHECK (level IS NULL OR (level BETWEEN 1 AND 100));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'profiles_onboarding_step_range') THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_onboarding_step_range CHECK (onboarding_step BETWEEN 1 AND 3);
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_id uuid NOT NULL,
  actor_id uuid,
  type public.notification_type NOT NULL DEFAULT 'system',
  status public.notification_status NOT NULL DEFAULT 'unread',
  title text NOT NULL,
  message text NOT NULL,
  action_url text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  read_at timestamptz
);

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users view own notifications" ON public.notifications;
CREATE POLICY "Users view own notifications"
ON public.notifications FOR SELECT TO authenticated
USING (auth.uid() = recipient_id OR public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Users update own notifications" ON public.notifications;
CREATE POLICY "Users update own notifications"
ON public.notifications FOR UPDATE TO authenticated
USING (auth.uid() = recipient_id)
WITH CHECK (auth.uid() = recipient_id);

DROP POLICY IF EXISTS "Admins create notifications" ON public.notifications;
CREATE POLICY "Admins create notifications"
ON public.notifications FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins delete notifications" ON public.notifications;
CREATE POLICY "Admins delete notifications"
ON public.notifications FOR DELETE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE INDEX IF NOT EXISTS idx_notifications_recipient_status ON public.notifications(recipient_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_type ON public.notifications(type);

CREATE TABLE IF NOT EXISTS public.team_invitations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id uuid NOT NULL,
  invited_user_id uuid NOT NULL,
  invited_by uuid NOT NULL,
  status public.invitation_status NOT NULL DEFAULT 'pending',
  message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  responded_at timestamptz,
  UNIQUE(team_id, invited_user_id, status)
);

ALTER TABLE public.team_invitations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Invites viewable by owner or invited user" ON public.team_invitations;
CREATE POLICY "Invites viewable by owner or invited user"
ON public.team_invitations FOR SELECT TO authenticated
USING (
  auth.uid() = invited_user_id OR
  EXISTS (SELECT 1 FROM public.teams WHERE teams.id = team_invitations.team_id AND teams.owner_id = auth.uid()) OR
  public.has_role(auth.uid(), 'admin')
);

DROP POLICY IF EXISTS "Owners create invites" ON public.team_invitations;
CREATE POLICY "Owners create invites"
ON public.team_invitations FOR INSERT TO authenticated
WITH CHECK (
  auth.uid() = invited_by AND
  EXISTS (SELECT 1 FROM public.teams WHERE teams.id = team_id AND teams.owner_id = auth.uid()) AND
  public.is_verified(invited_user_id)
);

DROP POLICY IF EXISTS "Invited users respond to invites" ON public.team_invitations;
CREATE POLICY "Invited users respond to invites"
ON public.team_invitations FOR UPDATE TO authenticated
USING (auth.uid() = invited_user_id OR EXISTS (SELECT 1 FROM public.teams WHERE teams.id = team_invitations.team_id AND teams.owner_id = auth.uid()))
WITH CHECK (auth.uid() = invited_user_id OR EXISTS (SELECT 1 FROM public.teams WHERE teams.id = team_invitations.team_id AND teams.owner_id = auth.uid()));

CREATE INDEX IF NOT EXISTS idx_team_invitations_user_status ON public.team_invitations(invited_user_id, status);
CREATE INDEX IF NOT EXISTS idx_team_invitations_team_status ON public.team_invitations(team_id, status);

CREATE TABLE IF NOT EXISTS public.team_ownership_transfers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id uuid NOT NULL,
  current_owner_id uuid NOT NULL,
  proposed_owner_id uuid NOT NULL,
  status public.ownership_transfer_status NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(),
  responded_at timestamptz,
  UNIQUE(team_id, proposed_owner_id, status)
);

ALTER TABLE public.team_ownership_transfers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Transfers viewable by owner or proposed owner" ON public.team_ownership_transfers;
CREATE POLICY "Transfers viewable by owner or proposed owner"
ON public.team_ownership_transfers FOR SELECT TO authenticated
USING (auth.uid() IN (current_owner_id, proposed_owner_id) OR public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Owners create transfer requests" ON public.team_ownership_transfers;
CREATE POLICY "Owners create transfer requests"
ON public.team_ownership_transfers FOR INSERT TO authenticated
WITH CHECK (
  auth.uid() = current_owner_id AND
  EXISTS (SELECT 1 FROM public.teams WHERE teams.id = team_id AND teams.owner_id = auth.uid()) AND
  EXISTS (SELECT 1 FROM public.team_members WHERE team_members.team_id = team_ownership_transfers.team_id AND team_members.user_id = proposed_owner_id)
);

DROP POLICY IF EXISTS "Proposed owners respond to transfers" ON public.team_ownership_transfers;
CREATE POLICY "Proposed owners respond to transfers"
ON public.team_ownership_transfers FOR UPDATE TO authenticated
USING (auth.uid() IN (current_owner_id, proposed_owner_id))
WITH CHECK (auth.uid() IN (current_owner_id, proposed_owner_id));

CREATE OR REPLACE FUNCTION public.create_notification(_recipient_id uuid, _actor_id uuid, _type public.notification_type, _title text, _message text, _action_url text DEFAULT NULL, _metadata jsonb DEFAULT '{}'::jsonb)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  nid uuid;
BEGIN
  INSERT INTO public.notifications (recipient_id, actor_id, type, title, message, action_url, metadata)
  VALUES (_recipient_id, _actor_id, _type, _title, _message, _action_url, COALESCE(_metadata, '{}'::jsonb))
  RETURNING id INTO nid;
  RETURN nid;
END;
$$;

CREATE OR REPLACE FUNCTION public.team_members_before_insert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  member_count int;
BEGIN
  IF NOT public.is_verified(NEW.user_id) THEN
    RAISE EXCEPTION 'User must be verified to join a team';
  END IF;

  IF EXISTS (SELECT 1 FROM public.team_members WHERE user_id = NEW.user_id) THEN
    RAISE EXCEPTION 'Player can only be in one team at a time';
  END IF;

  SELECT COUNT(*) INTO member_count FROM public.team_members WHERE team_id = NEW.team_id;
  IF member_count >= 6 THEN
    RAISE EXCEPTION 'Team is full (max 6 players)';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.teams WHERE id = NEW.team_id AND owner_id = NEW.user_id) THEN
    IF NOT EXISTS (
      SELECT 1 FROM public.team_invitations
      WHERE team_id = NEW.team_id AND invited_user_id = NEW.user_id AND status = 'accepted'
    ) AND NOT EXISTS (
      SELECT 1 FROM public.team_join_requests
      WHERE team_id = NEW.team_id AND user_id = NEW.user_id AND status = 'approved'
    ) THEN
      RAISE EXCEPTION 'Team membership requires an accepted invite or approved request';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.team_members_before_delete()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM public.teams WHERE id = OLD.team_id AND owner_id = OLD.user_id) THEN
    RAISE EXCEPTION 'Team owner must transfer ownership before leaving';
  END IF;

  IF OLD.joined_at > now() - interval '3 days' THEN
    RAISE EXCEPTION 'Team members cannot leave within 3 days of joining';
  END IF;

  RETURN OLD;
END;
$$;

CREATE OR REPLACE FUNCTION public.teams_before_delete()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  member_count int;
BEGIN
  SELECT COUNT(*) INTO member_count FROM public.team_members WHERE team_id = OLD.id;
  IF member_count > 1 AND NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Transfer ownership before deleting a team with members';
  END IF;
  RETURN OLD;
END;
$$;

CREATE OR REPLACE FUNCTION public.team_invitation_after_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  team_name text;
BEGIN
  SELECT name INTO team_name FROM public.teams WHERE id = NEW.team_id;

  IF TG_OP = 'INSERT' THEN
    PERFORM public.create_notification(NEW.invited_user_id, NEW.invited_by, 'team_invite', 'Team invitation', 'You were invited to join ' || COALESCE(team_name, 'a team') || '.', '/mailbox', jsonb_build_object('team_id', NEW.team_id, 'invitation_id', NEW.id));
  ELSIF NEW.status = 'accepted' AND OLD.status <> 'accepted' THEN
    UPDATE public.team_invitations SET responded_at = now() WHERE id = NEW.id AND responded_at IS NULL;
    INSERT INTO public.team_members (team_id, user_id)
    VALUES (NEW.team_id, NEW.invited_user_id)
    ON CONFLICT DO NOTHING;
  ELSIF NEW.status IN ('rejected', 'cancelled') AND OLD.status <> NEW.status THEN
    UPDATE public.team_invitations SET responded_at = now() WHERE id = NEW.id AND responded_at IS NULL;
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.team_join_request_after_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  owner uuid;
  team_name text;
BEGIN
  SELECT owner_id, name INTO owner, team_name FROM public.teams WHERE id = NEW.team_id;
  IF TG_OP = 'INSERT' THEN
    PERFORM public.create_notification(owner, NEW.user_id, 'team_request', 'Join request', 'A player requested to join ' || COALESCE(team_name, 'your team') || '.', '/teams/' || NEW.team_id::text, jsonb_build_object('team_id', NEW.team_id, 'request_id', NEW.id));
  ELSIF NEW.status = 'approved' AND OLD.status <> 'approved' THEN
    INSERT INTO public.team_members (team_id, user_id)
    VALUES (NEW.team_id, NEW.user_id)
    ON CONFLICT DO NOTHING;
    PERFORM public.create_notification(NEW.user_id, owner, 'request_decision', 'Join request approved', 'Your request to join ' || COALESCE(team_name, 'the team') || ' was approved.', '/teams/' || NEW.team_id::text, jsonb_build_object('team_id', NEW.team_id, 'request_id', NEW.id));
  ELSIF NEW.status = 'rejected' AND OLD.status <> 'rejected' THEN
    PERFORM public.create_notification(NEW.user_id, owner, 'request_decision', 'Join request rejected', 'Your request to join ' || COALESCE(team_name, 'the team') || ' was rejected.', '/mailbox', jsonb_build_object('team_id', NEW.team_id, 'request_id', NEW.id));
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.ownership_transfer_after_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  team_name text;
BEGIN
  SELECT name INTO team_name FROM public.teams WHERE id = NEW.team_id;
  IF TG_OP = 'INSERT' THEN
    PERFORM public.create_notification(NEW.proposed_owner_id, NEW.current_owner_id, 'ownership_transfer', 'Ownership transfer request', 'You were asked to become owner of ' || COALESCE(team_name, 'a team') || '.', '/mailbox', jsonb_build_object('team_id', NEW.team_id, 'transfer_id', NEW.id));
  ELSIF NEW.status = 'accepted' AND OLD.status <> 'accepted' THEN
    UPDATE public.teams SET owner_id = NEW.proposed_owner_id WHERE id = NEW.team_id AND owner_id = NEW.current_owner_id;
    UPDATE public.team_ownership_transfers SET responded_at = now() WHERE id = NEW.id AND responded_at IS NULL;
    PERFORM public.create_notification(NEW.current_owner_id, NEW.proposed_owner_id, 'ownership_transfer', 'Ownership transferred', COALESCE(team_name, 'Team') || ' ownership was accepted.', '/teams/' || NEW.team_id::text, jsonb_build_object('team_id', NEW.team_id, 'transfer_id', NEW.id));
  ELSIF NEW.status IN ('rejected', 'cancelled') AND OLD.status <> NEW.status THEN
    UPDATE public.team_ownership_transfers SET responded_at = now() WHERE id = NEW.id AND responded_at IS NULL;
    PERFORM public.create_notification(NEW.current_owner_id, NEW.proposed_owner_id, 'ownership_transfer', 'Ownership transfer updated', 'The ownership transfer for ' || COALESCE(team_name, 'the team') || ' was ' || NEW.status::text || '.', '/mailbox', jsonb_build_object('team_id', NEW.team_id, 'transfer_id', NEW.id));
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.profile_verification_notify()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.verification_status IS DISTINCT FROM OLD.verification_status THEN
    PERFORM public.create_notification(NEW.id, NULL, 'verification', 'Verification ' || NEW.verification_status::text, CASE WHEN NEW.verification_status = 'approved' THEN 'Your AOG account is verified.' WHEN NEW.verification_status = 'rejected' THEN COALESCE(NEW.rejection_reason, 'Your verification was rejected.') ELSE 'Your account is pending verification.' END, '/mailbox', jsonb_build_object('status', NEW.verification_status));
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.tournament_after_insert_notify()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.notifications (recipient_id, actor_id, type, title, message, action_url, metadata)
  SELECT p.id, NEW.created_by, 'tournament', 'New tournament: ' || NEW.name, COALESCE(NEW.description, 'A new tournament is open.'), '/tournaments/' || NEW.id::text, jsonb_build_object('tournament_id', NEW.id)
  FROM public.profiles p
  WHERE p.verification_status = 'approved';
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_team_members_before_insert ON public.team_members;
CREATE TRIGGER trg_team_members_before_insert BEFORE INSERT ON public.team_members FOR EACH ROW EXECUTE FUNCTION public.team_members_before_insert();

DROP TRIGGER IF EXISTS trg_team_members_before_delete ON public.team_members;
CREATE TRIGGER trg_team_members_before_delete BEFORE DELETE ON public.team_members FOR EACH ROW EXECUTE FUNCTION public.team_members_before_delete();

DROP TRIGGER IF EXISTS trg_team_members_after_change ON public.team_members;
CREATE TRIGGER trg_team_members_after_change AFTER INSERT OR DELETE ON public.team_members FOR EACH ROW EXECUTE FUNCTION public.team_members_after_change();

DROP TRIGGER IF EXISTS trg_teams_after_insert ON public.teams;
CREATE TRIGGER trg_teams_after_insert AFTER INSERT ON public.teams FOR EACH ROW EXECUTE FUNCTION public.teams_after_insert();

DROP TRIGGER IF EXISTS trg_teams_before_insert_region ON public.teams;
CREATE TRIGGER trg_teams_before_insert_region BEFORE INSERT ON public.teams FOR EACH ROW EXECUTE FUNCTION public.set_team_region();

DROP TRIGGER IF EXISTS trg_teams_before_delete ON public.teams;
CREATE TRIGGER trg_teams_before_delete BEFORE DELETE ON public.teams FOR EACH ROW EXECUTE FUNCTION public.teams_before_delete();

DROP TRIGGER IF EXISTS trg_team_invitations_after_change ON public.team_invitations;
CREATE TRIGGER trg_team_invitations_after_change AFTER INSERT OR UPDATE ON public.team_invitations FOR EACH ROW EXECUTE FUNCTION public.team_invitation_after_change();

DROP TRIGGER IF EXISTS trg_team_join_request_after_change ON public.team_join_requests;
CREATE TRIGGER trg_team_join_request_after_change AFTER INSERT OR UPDATE ON public.team_join_requests FOR EACH ROW EXECUTE FUNCTION public.team_join_request_after_change();

DROP TRIGGER IF EXISTS trg_ownership_transfer_after_change ON public.team_ownership_transfers;
CREATE TRIGGER trg_ownership_transfer_after_change AFTER INSERT OR UPDATE ON public.team_ownership_transfers FOR EACH ROW EXECUTE FUNCTION public.ownership_transfer_after_change();

DROP TRIGGER IF EXISTS trg_profile_verification_notify ON public.profiles;
CREATE TRIGGER trg_profile_verification_notify AFTER UPDATE OF verification_status ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.profile_verification_notify();

DROP TRIGGER IF EXISTS trg_tournament_after_insert_notify ON public.tournaments;
CREATE TRIGGER trg_tournament_after_insert_notify AFTER INSERT ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.tournament_after_insert_notify();

DROP POLICY IF EXISTS "Owner adds members; user joins via code" ON public.team_members;
DROP POLICY IF EXISTS "Members inserted by accepted flow" ON public.team_members;
CREATE POLICY "Members inserted by accepted flow"
ON public.team_members FOR INSERT TO authenticated
WITH CHECK (
  public.is_verified(user_id) AND (
    EXISTS (SELECT 1 FROM public.teams WHERE teams.id = team_id AND teams.owner_id = user_id AND auth.uid() = user_id)
    OR EXISTS (SELECT 1 FROM public.team_invitations WHERE team_invitations.team_id = team_id AND team_invitations.invited_user_id = user_id AND team_invitations.status = 'accepted')
    OR EXISTS (SELECT 1 FROM public.team_join_requests WHERE team_join_requests.team_id = team_id AND team_join_requests.user_id = user_id AND team_join_requests.status = 'approved')
    OR public.has_role(auth.uid(), 'admin')
  )
);

DROP POLICY IF EXISTS "Owner removes members or self leaves" ON public.team_members;
DROP POLICY IF EXISTS "Members leave after lock period" ON public.team_members;
CREATE POLICY "Members leave after lock period"
ON public.team_members FOR DELETE TO authenticated
USING (
  (auth.uid() = user_id AND joined_at <= now() - interval '3 days')
  OR public.has_role(auth.uid(), 'admin')
);

DROP POLICY IF EXISTS "Owner or admin deletes team" ON public.teams;
DROP POLICY IF EXISTS "Safe team delete" ON public.teams;
CREATE POLICY "Safe team delete"
ON public.teams FOR DELETE TO authenticated
USING (
  public.has_role(auth.uid(), 'admin') OR (
    auth.uid() = owner_id AND NOT EXISTS (SELECT 1 FROM public.team_members WHERE team_members.team_id = teams.id AND team_members.user_id <> auth.uid())
  )
);
