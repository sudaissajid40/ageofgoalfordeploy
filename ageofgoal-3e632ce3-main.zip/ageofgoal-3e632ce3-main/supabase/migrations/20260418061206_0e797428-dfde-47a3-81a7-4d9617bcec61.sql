INSERT INTO public.user_roles (user_id, role)
VALUES ('7bafb04a-7ace-43b5-a6db-0a1d9ba245fc', 'admin')
ON CONFLICT DO NOTHING;

UPDATE public.profiles
SET verification_status = 'approved', profile_completed = true
WHERE id = '7bafb04a-7ace-43b5-a6db-0a1d9ba245fc';