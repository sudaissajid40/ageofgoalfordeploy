// Generates a sponsor banner image with Lovable AI Gemini and uploads to storage.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const SB_URL = Deno.env.get("SUPABASE_URL")!;
const SB_SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY")!;

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });
  try {
    const { tournament_name, sponsor_name, sponsor_hook } = await req.json();
    if (!sponsor_name) return new Response(JSON.stringify({ error: "sponsor_name required" }), { status: 400, headers: cors });

    const prompt = `High-impact esports tournament sponsor banner, 1024x512 wide. Bold neon-orange and dark theme, dynamic Free Fire battle royale aesthetic. Tournament: "${tournament_name ?? "AOG"}". Sponsor brand name "${sponsor_name}" displayed prominently. Hook text: "${sponsor_hook ?? "Sponsor of champions"}". Include a CTA-style button shape. No extra logos, clean typography.`;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash-image",
        messages: [{ role: "user", content: prompt }],
        modalities: ["image", "text"],
      }),
    });
    if (!res.ok) {
      const t = await res.text();
      return new Response(JSON.stringify({ error: "AI image failed: " + t }), { status: 500, headers: cors });
    }
    const data = await res.json();
    const dataUrl = data?.choices?.[0]?.message?.images?.[0]?.image_url?.url;
    if (!dataUrl) return new Response(JSON.stringify({ error: "No image returned" }), { status: 500, headers: cors });
    const b64 = dataUrl.split(",")[1];
    const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));

    const sb = createClient(SB_URL, SB_SERVICE);
    const path = `sponsors/${crypto.randomUUID()}.png`;
    const { error: upErr } = await sb.storage.from("tournament-thumbnails").upload(path, bytes, {
      contentType: "image/png", upsert: false,
    });
    if (upErr) return new Response(JSON.stringify({ error: upErr.message }), { status: 500, headers: cors });
    const { data: pub } = sb.storage.from("tournament-thumbnails").getPublicUrl(path);
    return new Response(JSON.stringify({ url: pub.publicUrl }), { headers: { ...cors, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 500, headers: cors });
  }
});
