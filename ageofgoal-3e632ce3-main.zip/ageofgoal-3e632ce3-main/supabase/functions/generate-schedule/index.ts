// Generates 3 tournament schedule proposals using Lovable AI Gateway
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface Team {
  id: string;
  name: string;
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const body = await req.json();
    const tournament_id: string = body.tournament_id;
    const days: number = Math.min(Math.max(Number(body.days) || 3, 1), 14);
    const matches_per_day: number = Math.min(Math.max(Number(body.matches_per_day) || 3, 1), 8);
    const start_time: string = (body.start_time as string) || "18:00";
    const slot_minutes: number = Math.min(Math.max(Number(body.slot_minutes) || 90, 15), 240);
    const start_date: string | undefined = body.start_date; // YYYY-MM-DD

    if (!tournament_id) throw new Error("tournament_id required");

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY missing");

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const PUBLISHABLE = Deno.env.get("SUPABASE_PUBLISHABLE_KEY") ?? Deno.env.get("SUPABASE_ANON_KEY")!;
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("Authorization header required");

    // Verify caller is admin
    const userClient = createClient(SUPABASE_URL, PUBLISHABLE, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData } = await userClient.auth.getUser();
    if (!userData?.user) throw new Error("Not authenticated");
    const { data: roleRow } = await userClient
      .from("user_roles").select("role").eq("user_id", userData.user.id).eq("role", "admin").maybeSingle();
    if (!roleRow) throw new Error("Admin only");

    const admin = createClient(SUPABASE_URL, SERVICE_ROLE);

    // Load tournament + registered teams
    const { data: tournament } = await admin.from("tournaments").select("*").eq("id", tournament_id).maybeSingle();
    if (!tournament) throw new Error("Tournament not found");

    const { data: regs } = await admin
      .from("tournament_registrations")
      .select("participant_id, participant_type")
      .eq("tournament_id", tournament_id)
      .eq("participant_type", "team");

    const teamIds = (regs ?? []).map((r) => r.participant_id);
    if (teamIds.length < 2) throw new Error("Need at least 2 registered teams");

    const { data: teams } = await admin.from("teams").select("id, name").in("id", teamIds);
    const teamList = (teams ?? []) as Team[];

    // Default first day = day after registration ends, else tomorrow
    const defaultDate = (() => {
      const base = tournament.registration_ends_at
        ? new Date(tournament.registration_ends_at)
        : new Date();
      base.setUTCDate(base.getUTCDate() + 1);
      return base.toISOString().slice(0, 10);
    })();
    const firstDay = start_date || defaultDate;

    const prompt = `You are scheduling a Free Fire esports tournament called "${tournament.name}".

TEAMS (${teamList.length}):
${teamList.map((t) => `- ${t.id}  ${t.name}`).join("\n")}

PARAMETERS (use these exactly):
- Total days: ${days}
- Matches per day: ${matches_per_day}
- First match each day starts at: ${start_time} (UTC)
- Slot length between matches on the same day: ${slot_minutes} minutes
- First match date (UTC): ${firstDay}
- Match team size: ${tournament.match_team_size}

Build 3 DIFFERENT round-robin schedules where every team plays every other team at least once in the GROUP stage. After the group stage, schedule 2 SEMI-FINAL matches (team_a_id and team_b_id should be null — TBD by standings) and 1 FINAL match (also null teams). Number matches sequentially starting at 1 across the whole tournament. scheduled_at must be ISO 8601 UTC. Use the team UUIDs exactly as given.`;

    // Use tool calling for structured output
    const tools = [{
      type: "function",
      function: {
        name: "submit_schedules",
        description: "Submit 3 tournament schedule proposals.",
        parameters: {
          type: "object",
          properties: {
            schedules: {
              type: "array",
              minItems: 3,
              maxItems: 3,
              items: {
                type: "object",
                properties: {
                  label: { type: "string" },
                  description: { type: "string" },
                  matches: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        match_number: { type: "integer" },
                        round: { type: "string", enum: ["group", "semi", "final"] },
                        team_a_id: { type: ["string", "null"] },
                        team_b_id: { type: ["string", "null"] },
                        scheduled_at: { type: "string" },
                      },
                      required: ["match_number", "round", "team_a_id", "team_b_id", "scheduled_at"],
                      additionalProperties: false,
                    },
                  },
                },
                required: ["label", "description", "matches"],
                additionalProperties: false,
              },
            },
          },
          required: ["schedules"],
          additionalProperties: false,
        },
      },
    }];

    const aiResp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: "You are an esports tournament scheduler. Use the submit_schedules tool. Be precise with UUIDs and timestamps." },
          { role: "user", content: prompt },
        ],
        tools,
        tool_choice: { type: "function", function: { name: "submit_schedules" } },
      }),
    });

    if (aiResp.status === 429) {
      return new Response(JSON.stringify({ error: "AI rate limit hit, please wait a minute and try again." }), {
        status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (aiResp.status === 402) {
      return new Response(JSON.stringify({ error: "AI credits exhausted. Add credits in Settings → Workspace → Usage." }), {
        status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!aiResp.ok) {
      const t = await aiResp.text();
      console.error("Lovable AI error:", aiResp.status, t);
      throw new Error(`AI gateway error ${aiResp.status}`);
    }

    const aiData = await aiResp.json();
    const toolCall = aiData.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall?.function?.arguments) {
      console.error("No tool call returned:", JSON.stringify(aiData).slice(0, 500));
      throw new Error("AI did not return a schedule");
    }

    let parsed: { schedules: Array<{ label: string; description: string; matches: unknown[] }> };
    try {
      parsed = JSON.parse(toolCall.function.arguments);
    } catch (e) {
      console.error("JSON parse failed:", toolCall.function.arguments);
      throw new Error("AI returned malformed JSON");
    }

    if (!parsed.schedules?.length) throw new Error("AI returned no schedules");

    // Replace previous proposals for this tournament
    await admin.from("tournament_schedule_proposals").delete().eq("tournament_id", tournament_id);
    const inserts = parsed.schedules.map((s) => ({
      tournament_id,
      label: s.label,
      description: s.description,
      matches: s.matches,
    }));
    const { data: created, error: insertErr } = await admin
      .from("tournament_schedule_proposals")
      .insert(inserts)
      .select();
    if (insertErr) throw insertErr;

    return new Response(JSON.stringify({ proposals: created }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("generate-schedule error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
