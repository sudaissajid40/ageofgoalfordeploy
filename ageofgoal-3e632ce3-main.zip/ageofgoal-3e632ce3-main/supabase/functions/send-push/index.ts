// Web Push (VAPID) sender — Deno edge function.
// Implements VAPID JWT (ES256) + RFC 8291 aes128gcm payload encryption with WebCrypto only.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const SB_URL = Deno.env.get("SUPABASE_URL")!;
const SB_SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const VAPID_PUBLIC = Deno.env.get("VAPID_PUBLIC_KEY")!;
const VAPID_PRIVATE = Deno.env.get("VAPID_PRIVATE_KEY")!;
const VAPID_SUBJECT = Deno.env.get("VAPID_SUBJECT") ?? "mailto:admin@aog.local";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ---------- helpers ----------
function b64uToBytes(b64: string): Uint8Array {
  const pad = "=".repeat((4 - (b64.length % 4)) % 4);
  const s = (b64 + pad).replace(/-/g, "+").replace(/_/g, "/");
  return Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
}
function bytesToB64u(buf: ArrayBuffer | Uint8Array): string {
  const b = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let s = "";
  for (const v of b) s += String.fromCharCode(v);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function concat(...arrs: Uint8Array[]) {
  const total = arrs.reduce((a, b) => a + b.length, 0);
  const out = new Uint8Array(total);
  let off = 0;
  for (const a of arrs) { out.set(a, off); off += a.length; }
  return out;
}

// Convert a VAPID raw public key (65 bytes uncompressed, base64url) into JWK
function rawPubToJwk(raw: Uint8Array) {
  return { kty: "EC", crv: "P-256", x: bytesToB64u(raw.slice(1, 33)), y: bytesToB64u(raw.slice(33, 65)), ext: true };
}
function rawPrivToJwk(d: Uint8Array, pubRaw: Uint8Array) {
  return { ...rawPubToJwk(pubRaw), d: bytesToB64u(d) };
}

async function importVapidKeys() {
  const pub = b64uToBytes(VAPID_PUBLIC);
  const priv = b64uToBytes(VAPID_PRIVATE);
  const jwk = rawPrivToJwk(priv, pub);
  const signer = await crypto.subtle.importKey(
    "jwk", jwk, { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]
  );
  return { signer, pubRaw: pub };
}

async function vapidHeaders(audience: string) {
  const { signer, pubRaw } = await importVapidKeys();
  const header = bytesToB64u(new TextEncoder().encode(JSON.stringify({ typ: "JWT", alg: "ES256" })));
  const payload = bytesToB64u(new TextEncoder().encode(JSON.stringify({
    aud: audience,
    exp: Math.floor(Date.now() / 1000) + 12 * 60 * 60,
    sub: VAPID_SUBJECT,
  })));
  const data = new TextEncoder().encode(`${header}.${payload}`);
  const sig = await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, signer, data);
  const jwt = `${header}.${payload}.${bytesToB64u(sig)}`;
  return {
    Authorization: `vapid t=${jwt}, k=${bytesToB64u(pubRaw)}`,
  };
}

// ---------- payload encryption (RFC 8291 aes128gcm) ----------
async function hkdf(salt: Uint8Array, ikm: Uint8Array, info: Uint8Array, length: number) {
  const key = await crypto.subtle.importKey("raw", ikm, "HKDF", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "HKDF", hash: "SHA-256", salt, info } as HkdfParams,
    key,
    length * 8
  );
  return new Uint8Array(bits);
}

async function encryptPayload(payload: string, p256dhB64u: string, authB64u: string) {
  const recipientPubRaw = b64uToBytes(p256dhB64u);
  const authSecret = b64uToBytes(authB64u);
  const recipientPub = await crypto.subtle.importKey(
    "raw", recipientPubRaw, { name: "ECDH", namedCurve: "P-256" }, true, []
  );

  const ephem = await crypto.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]);
  const ephemPubRaw = new Uint8Array(await crypto.subtle.exportKey("raw", ephem.publicKey));

  const sharedBits = await crypto.subtle.deriveBits(
    { name: "ECDH", public: recipientPub }, ephem.privateKey, 256
  );
  const ecdhSecret = new Uint8Array(sharedBits);

  const enc = new TextEncoder();
  // PRK_key = HKDF(authSecret, ecdhSecret, "WebPush: info\0" + ua_pub + as_pub, 32)
  const keyInfo = concat(enc.encode("WebPush: info\0"), recipientPubRaw, ephemPubRaw);
  const prkKey = await hkdf(authSecret, ecdhSecret, keyInfo, 32);

  const salt = crypto.getRandomValues(new Uint8Array(16));
  // CEK = HKDF(salt, PRK_key, "Content-Encoding: aes128gcm\0", 16)
  const cek = await hkdf(salt, prkKey, enc.encode("Content-Encoding: aes128gcm\0"), 16);
  // NONCE = HKDF(salt, PRK_key, "Content-Encoding: nonce\0", 12)
  const nonce = await hkdf(salt, prkKey, enc.encode("Content-Encoding: nonce\0"), 12);

  const aesKey = await crypto.subtle.importKey("raw", cek, { name: "AES-GCM" }, false, ["encrypt"]);
  const plaintext = concat(enc.encode(payload), new Uint8Array([0x02])); // padding delim
  const ciphertext = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv: nonce }, aesKey, plaintext));

  // Build aes128gcm header: salt(16) || rs(4 BE = 4096) || idlen(1=65) || keyid(65)
  const rs = new Uint8Array([0, 0, 0x10, 0]); // 4096
  const idlen = new Uint8Array([ephemPubRaw.length]);
  const body = concat(salt, rs, idlen, ephemPubRaw, ciphertext);
  return body;
}

// ---------- main ----------
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });
  try {
    const { user_ids = [], title, body, url } = await req.json() as { user_ids: string[]; title: string; body: string; url?: string };
    if (!Array.isArray(user_ids) || user_ids.length === 0) {
      return new Response(JSON.stringify({ ok: true, sent: 0 }), { headers: { ...cors, "Content-Type": "application/json" } });
    }
    const sb = createClient(SB_URL, SB_SERVICE);
    const { data: subs } = await sb
      .from("push_subscriptions")
      .select("id, endpoint, p256dh, auth")
      .in("user_id", user_ids);
    if (!subs || subs.length === 0) {
      return new Response(JSON.stringify({ ok: true, sent: 0 }), { headers: { ...cors, "Content-Type": "application/json" } });
    }
    const payload = JSON.stringify({ title, body, url: url ?? "/" });
    let sent = 0;
    const stale: string[] = [];
    for (const s of subs) {
      try {
        const audience = new URL(s.endpoint).origin;
        const enc = await encryptPayload(payload, s.p256dh, s.auth);
        const headers = await vapidHeaders(audience);
        const res = await fetch(s.endpoint, {
          method: "POST",
          headers: {
            ...headers,
            "Content-Type": "application/octet-stream",
            "Content-Encoding": "aes128gcm",
            "TTL": "86400",
            "Urgency": "normal",
          },
          body: enc,
        });
        if (res.status === 404 || res.status === 410) stale.push(s.id);
        else if (res.ok || res.status === 201 || res.status === 202) sent++;
        else console.error("push failed", res.status, await res.text());
      } catch (e) {
        console.error("push error", e);
      }
    }
    if (stale.length) await sb.from("push_subscriptions").delete().in("id", stale);
    return new Response(JSON.stringify({ ok: true, sent, pruned: stale.length }), {
      headers: { ...cors, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 500, headers: { ...cors, "Content-Type": "application/json" },
    });
  }
});
