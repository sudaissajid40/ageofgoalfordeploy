## Goal

Address all 10 requests in one implementation pass: trim signup, web-push notifications, sponsors, paid tournaments, fix solo registration display, prominent rejection banner, dynamic tournament status, mark-all-read, profile-edit cooldowns + re-verify, prize banners, installable web app + install/notification prompts,update uid of freefire account to verify account in complete profile creation.

## 1. Trim signup form to email + password only

`src/routes/signup.tsx`: remove `username`, `city`, `level`, `region` fields and the post-signup profile UPDATE. Keep only email + password + confirm. After signup → navigate to `/complete-profile` (already mandatory + has all those fields). Drop the FFUidCard from this page (it stays on `/complete-profile` and `/pending`).

## 2. Web Push notifications (VAPID)

- Migration: add `push_subscriptions` table (`user_id`, `endpoint` unique, `p256dh`, `auth`, `created_at`) with RLS (user can manage own; admins can read for sending).
- Add secrets: `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `VAPID_SUBJECT` (request via add_secret).
- Edge function `send-push`: takes `{user_ids[], title, body, url}`, signs JWT VAPID headers with WebCrypto (no node deps), POSTs to each subscription endpoint, prunes 404/410 subs.
- DB trigger on `notifications` insert → calls `pg_net` to invoke `send-push` with the recipient (so all existing notification flows automatically push).
- Frontend: `public/sw.js` (service worker) handling `push` + `notificationclick`. New `src/lib/push.ts` registers SW, calls `Notification.requestPermission()`, `pushManager.subscribe({ applicationServerKey: VAPID_PUBLIC })`, upserts row in `push_subscriptions`.
- A small "Enable notifications" banner on dashboard + on the install banner (see #11) when permission is `default`.
- **{**  
**"subject": "mailto: <[sudaissajidofficial@gmail.com](mailto:sudaissajidofficial@gmail.com)>",**  
**"publicKey": "BFDCEZ981pSYUzcqx5jn0_KJGN8Lr8E48d9fSyVqcO8mN7_lIDNAZl6mz08_c3jTnxc3XBScIfrFhpERrLTmYBI",**  
**"privateKey": "jVXPoFgnKiJ-nWK12R8o_sGDLKvHTl5fVpwYIkC84jg"**  
**}**

## 3. Sponsored-by-brands

- Migration: add columns to `tournaments`: `sponsor_name text`, `sponsor_cta_label text`, `sponsor_cta_url text`, `sponsor_banner_url text`, `sponsor_hook text`.
- Admin tournament create form: optional sponsor section (name, hook, CTA label/url) + "Generate banner with AI" button → calls new edge function `generate-sponsor-banner` (uses Lovable AI `google/gemini-2.5-flash-image` with prompt built from tournament + sponsor name/hook), uploads PNG to `tournament-thumbnails` bucket under `sponsors/`, stores public URL in `sponsor_banner_url`.
- Tournament detail page (`tournaments.$id.tsx`) and tournament cards: when `sponsor_*` set, render banner + "Sponsored by {name}" + CTA button (target=_blank, rel="noreferrer noopener", validated URL).

## 4. Paid tournaments (manual receipt verification)

- Migration: add to `tournaments`: `entry_fee numeric default 0`, `payment_account_label text`, `payment_account_number text`, `payment_instructions text`. Add table `payment_submissions` (`id`, `tournament_id`, `user_id`, `team_id nullable`, `amount`, `receipt_url`, `status enum(pending,approved,rejected)`, `admin_note`, `reviewed_by`, `reviewed_at`, `created_at`). RLS: user creates/views own; admins manage all. New storage bucket `payment-receipts` (private; user-folder write policy, admin-read policy).
- Update `tournament_registrations_before_insert` trigger: if tournament has `entry_fee > 0`, require an `approved` row in `payment_submissions` for that registrant/team or raise.
- Admin tournament form: optional Entry-fee section (amount, account label, number, instructions).
- Tournament detail: if paid + not yet approved → show "Pay & upload receipt" panel with payment details and a file uploader → inserts row into `payment_submissions` with uploaded receipt URL. Status indicator "Awaiting verification / Approved / Rejected (note)".
- Admin: new sub-page `admin/payments` (list pending receipts → preview image → approve/reject with note). Approving an admin-side flow that also auto-registers the team if requested.

## 5. Fix solo player not showing in registered list

`tournaments.$id.tsx` currently only resolves `team` participants. For `solo` tournaments, also collect `participant_type === "user"` ids → fetch from `profiles(id, username)` → render in a separate "Registered players" list. Use Lahore time helpers already in place.

## 6. Prominent rejection banner + edit access

- `src/components/SidebarLayout.tsx` (or root authenticated layout): if `profile.verification_status === "rejected"`, render a sticky red banner at the top with the admin note + "Edit & Resubmit" button → `/complete-profile`. Visible on every authenticated route.
- Already-existing `/rejected` page stays as the dedicated screen.

## 7. Tournament status auto-updates

Already partly done. Extend: any place still hardcoding "Join Now" (re-audit `tournaments.index.tsx`, `index.tsx`, `tournaments.$id.tsx`, dashboard cards) → use shared helper `getTournamentDisplayStatus(t)` → returns `{label, badgeClass, ctaLabel, ctaTo}`. Add cron-style client refresh via existing `useRealtimeRefresh` + 30 s interval.

## 8. Mark-all-read in notifications

`mailbox.tsx`: add header button "Mark all read" → `supabase.from('notifications').update({status:'read', read_at: now}).eq('recipient_id', user.id).eq('status','unread')`.

## 9. Profile edit cooldowns (3 → 7 → 30 days) + re-verify

- Migration: add to `profiles`: `edit_count int default 0`, `last_edit_at timestamptz`. RLS update policy: allow when status is `rejected` (existing path), OR when `last_edit_at` is null, OR when cooldown elapsed based on `edit_count`.
- DB trigger `profiles_before_update`: when meaningful fields change (username, city, region, ff_uid, ff_username, level, age, gender, play_style, preferred_mode), enforce: 1st edit anytime, 2nd ≥3 d, 3rd ≥7 d, 4th+ ≥30 d; bump `edit_count`, set `last_edit_at`, force `verification_status = 'pending'` and clear `rejection_reason`.
- New page `src/routes/_authenticated/profile.edit.tsx`: re-uses the personal+game schemas from complete-profile, prefills, shows "Next edit available in X days" countdown, on save toasts "Sent for re-verification" and routes to `/pending`.
- Profile page: add "Edit profile" button gated by computed cooldown.

## 10. Prize banners on tournaments

- Already-have field: `point_payouts jsonb` + `champion_points_multiplier`. Add prominent prize banner block on `tournaments.index.tsx` cards and `index.tsx` featured carousel: trophy icon + "Win up to {N} AOG points + champion bonus" + bold "Register your team" CTA when registration is open.
- Reuse sponsor banner area when no sponsor set, so registration page is never empty visually.

## 11. Installable web app + small "install" + "enable notifications" banners

- Add `public/manifest.webmanifest` (name "Age of Goal", short_name "AOG", start_url "/", display "standalone", theme/background colors, icons 192/512 from `/icons/`). Reference manifest in `__root.tsx` `<head>`. Generate two PNG icons via the AI image script and commit them under `public/icons/`.
- New `src/components/InstallAppBanner.tsx`: listens for `beforeinstallprompt`, stores event, renders a slim bottom banner ("Install AOG app") with Install / Dismiss (dismiss persisted in localStorage 7 d). Shown only when not installed (`window.matchMedia('(display-mode: standalone)').matches === false`).
- New `src/components/EnableNotificationsBanner.tsx`: shown when `Notification.permission === 'default'` and user is verified. Click → triggers `requestPermission()` + subscribe flow from #2.
- Mount both banners in `_authenticated.tsx` so they only appear post-login.
- **Do NOT** add `vite-plugin-pwa` or a caching service worker. The `/sw.js` we ship is push-only (no `fetch` handler, no cache) — explicitly safe in Lovable preview.

12.update uid to which user have to send request to verification process new freefire UID:"15568897940" and name "age_of_goal" also update in image ui

## Database migration summary (single file)

- `tournaments` cols: sponsor_*, entry_fee, payment_account_*, payment_instructions
- `profiles` cols: edit_count, last_edit_at + trigger
- new tables: `push_subscriptions`, `payment_submissions`
- new bucket: `payment-receipts` (private, RLS)
- update trigger `tournament_registrations_before_insert` for paid gating
- new trigger `profiles_before_update` for cooldown + force re-verify
- DB trigger on `notifications` insert → http POST to `send-push` (uses `pg_net`)

## Edge functions

- `send-push` (new): VAPID web-push fan-out
- `generate-sponsor-banner` (new): Lovable AI image → uploads to bucket → returns URL

## Files created/edited (summary)

- migrations: 1 new SQL
- secrets requested: `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `VAPID_SUBJECT`
- edited: `src/routes/signup.tsx`, `src/routes/_authenticated.tsx`, `src/routes/__root.tsx`, `src/routes/_authenticated/mailbox.tsx`, `src/routes/_authenticated/profile.tsx`, `src/routes/_authenticated/tournaments.$id.tsx`, `src/routes/_authenticated/tournaments.index.tsx`, `src/routes/index.tsx`, `src/routes/_authenticated/_admin/admin.tournaments.tsx`, `src/components/SidebarLayout.tsx`
- created: `src/lib/push.ts`, `src/lib/tournamentStatus.ts`, `src/components/InstallAppBanner.tsx`, `src/components/EnableNotificationsBanner.tsx`, `src/components/RejectedBanner.tsx`, `src/components/SponsorBanner.tsx`, `src/routes/_authenticated/profile.edit.tsx`, `src/routes/_authenticated/_admin/admin.payments.tsx`, `public/sw.js`, `public/manifest.webmanifest`, `public/icons/icon-192.png`, `public/icons/icon-512.png`, `supabase/functions/send-push/index.ts`, `supabase/functions/generate-sponsor-banner/index.ts`

## Notes / risks

- Web Push needs the user to provide VAPID keys once — we'll generate them via a one-line script and store them in Lovable Cloud secrets when you approve.
- Manual payment verification: admin must approve each receipt before the team can register. The trigger blocks registration without an approved payment only for paid tournaments.
- Profile edit cooldown is enforced server-side by trigger — UI just hides the button.
- Manifest-only PWA (no offline) avoids Lovable's preview-iframe service-worker pitfalls; only the push SW is registered, and only after explicit user permission.